import argparse
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
from uuid import uuid4
import zipfile

NAME = "qaoa-followup-20261116"
MANIFEST_SHA = "8bb4277270563cceb9c08cc91dcd5dc2dcbc994d18ea6421aed2578c42e8c8b5"
REF = "scripts/reference_search.py"
CONF = "../followup/confirmation/confirmation.py"
DEPTH = "../followup/depth/matched_depth.py"
NOISE = "../followup/noise/resume_noise.py"
EARLY = "../followup/earlystop/benchmark.py"


def read(path):
    return json.loads(path.read_bytes())


def stamp():
    return datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid4().hex[:8]


def check_files(package):
    manifest = package / "bundle-manifest.json"
    if hashlib.sha256(manifest.read_bytes()).hexdigest() != MANIFEST_SHA:
        raise ValueError(f"运行包版本不匹配 {package}")
    for name, info in read(manifest)["files"].items():
        if hashlib.sha256((package / name).read_bytes()).hexdigest() != info["sha256"]:
            raise ValueError(f"运行包文件校验失败 {name}")


def unpack(archive, package):
    if not package.exists():
        with tempfile.TemporaryDirectory(prefix=".qaoa-install-", dir=package.parent) as temp:
            stage = Path(temp) / NAME
            with zipfile.ZipFile(archive) as z:

                members = [n for n in z.namelist() if n.startswith(NAME + "/")]
                if not members:
                    raise ValueError("请使用完整的 qaoa_followup.pyz 运行包")
                z.extractall(temp, members)
            check_files(stage)
            try:
                stage.rename(package)
            except OSError:
                if not package.is_dir():
                    raise
    check_files(package)


class Paused(Exception):
    pass


@contextmanager
def lock(path):

    with path.open("a+b") as f:
        try:
            if os.name == "nt":
                import msvcrt
                if f.tell() == 0:
                    f.write(b"0")
                    f.flush()
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as exc:
            raise RuntimeError("已有串行任务正在运行。用 status 看进度。") from exc
        yield f.fileno()


@dataclass(frozen=True)
class Stage:
    key: str
    root: Path
    script: str
    phase: str | None = None


class Queue:
    def __init__(self, package):
        self.package = Path(package).resolve()
        self.runtime = self.package / "runtime"
        result = self.package / "results"
        self.control = result / ".queue"
        self.pause = self.control / "pause"
        self.state = self.control / "state.json"
        self.stages = [Stage(key, result / root, script, phase) for key, root, script, phase in (
            ("targeted", "p3-targeted-v1", REF, None),
            ("stability", "p3-stability-v1", REF, None),
            ("confirmation", "confirmation-v1", CONF, None),
            ("quality", "depth-v1", DEPTH, "quality"),
            ("references", "depth-v1", DEPTH, "references"),
            ("noise", "noise98-v1", NOISE, None),
            ("earlystop", "earlystop-v1", EARLY, None))]
        self.unions = [s.root / "final-v1/union-references" for s in self.stages[:2]]
        self.fd = None
        self.marker = None
        self.env = dict(os.environ, QAOA_RUNTIME=str(self.runtime), PYTHONUNBUFFERED="1",
                        OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1")

    def check_pause(self):
        if self.pause.exists():
            raise Paused()

    def active(self):
        try:
            with lock(self.control / "queue.lock"):
                return False
        except RuntimeError:
            return True

    def note(self, key, operation):
        print(f"[{key}] {operation}", flush=True)
        temp = self.control / "state.tmp"
        temp.write_text(json.dumps({"stage": key, "operation": operation}), encoding="utf-8")
        temp.replace(self.state)

    def invoke(self, script, action, *args, capture=False):
        self.check_pause()
        command = [sys.executable, "-u", "-B", str(script), str(action), *map(str, args)]
        options = {"pass_fds": (self.fd,), "start_new_session": True} if os.name != "nt" and self.fd is not None else {}

        with subprocess.Popen(command, cwd=self.runtime, env=self.env, stdout=subprocess.PIPE if capture else None,
                              text=True, **options) as p:
            while True:
                if self.pause.exists() and self.marker is not None and self.marker.parent.is_dir():
                    self.marker.touch(exist_ok=True)
                try:
                    stdout, _ = p.communicate(timeout=1)
                    break
                except subprocess.TimeoutExpired:
                    continue
        self.check_pause()

        if p.returncode and not (capture and script == REF and action == "status" and p.returncode == 2 and stdout.strip()):
            raise RuntimeError(f"{Path(script).name} {action} 退出码 {p.returncode}。原因见上一条输出。")
        return json.loads(stdout) if capture else None

    def union_args(self, flag):
        return [arg for path in self.unions for arg in (flag, path)]

    def prepare(self, s):
        if s.script == NOISE:
            return
        if s.script == REF:
            ready = "preparation.json"
            args = ["--inputs", f"../followup/reference/{s.key}-inputs.json",
                    "--config", f"configs/p3-reference-{s.key}.json"]
        elif s.script == CONF:
            ready, args = "batch/manifest.json", ["--execute"]
        elif s.script == DEPTH:
            ready, args = "preparation.json", ["--inputs", "../followup/depth/inputs.json",
                                               "--config", "../followup/depth/config.json"]
        else:
            ready, args = "plan.json", ["--inputs", "../followup/earlystop/inputs.json",
                                        *self.union_args("--reference-update")]
        if not s.root.exists():
            temp = s.root.with_name(s.root.name + ".preparing-" + stamp())
            self.note(s.key, "准备")
            self.invoke(s.script, "prepare", "--root", temp, *args)
            read(temp / ready)
            temp.rename(s.root)
        if not (s.root / ready).is_file():
            raise RuntimeError(f"已有目录缺少准备记录，需检查 {s.root}")
        if s.script == EARLY and read(s.root / ready)["reference_update_sets"] != self.union_ids():
            raise RuntimeError(f"已有早停计划使用其他阈值，需检查 {s.root}")

    def union_ids(self):
        return [read(path / "manifest.json")["reference_set_id"] for path in self.unions]

    def summarize(self, s):
        if s.key == "quality":
            return
        if s.script == REF:
            dest, tail = s.root / "final-v1", "summary.json"
        elif s.script == CONF:
            dest, tail = s.root / "analysis-v1", "analysis.json"
        elif s.script == NOISE:
            dest, tail = s.root / "summary.json", ""
        else:
            dest, tail = s.root / "summary-v1.json", ""
        if s.script == DEPTH and dest.exists():
            previous = [x["reference_set_id"] for x in read(dest)["reference_overlays"]]
            if previous != self.union_ids():
                dest = s.root / "summary-both-unions-v1.json"
        def validate(target):
            value = read(target / tail if tail else target)
            if s.script == REF:
                for part in ("union-references", "new-references"):
                    read(target / part / "manifest.json")
                if value["batch_id"] != read(s.root / "preparation.json")["batch_id"]:
                    raise ValueError("参考汇总的批次不匹配")
            elif s.script == CONF:
                read(target / "references/manifest.json")
                if value["input_id"] != read(s.root / "source.json")["input_id"]:
                    raise ValueError("新图汇总的输入不匹配")
            elif s.script == DEPTH and [x["reference_set_id"] for x in value["reference_overlays"]] != self.union_ids():
                raise ValueError("深度汇总缺少本轮参考")
            elif s.script == EARLY and value["plan_id"] != read(s.root / "plan.json")["plan_id"]:
                raise ValueError("早停汇总的计划不匹配")
            elif s.script == NOISE and not value["complete"]:
                raise ValueError("噪声汇总未完成")
        if dest.exists():
            try:
                validate(dest)
                return
            except json.JSONDecodeError:

                if s.script != NOISE:
                    raise
                dest.rename(dest.with_name("summary.interrupted-" + stamp() + ".json"))
        self.note(s.key, "汇总")
        if s.script == NOISE:
            self.invoke(s.script, "summarize", "--root", s.root)
            validate(dest)
        else:
            temp = dest.with_name(dest.name + ".writing-" + stamp())
            flags = self.union_args("--p3-reference-overlay") if s.script == DEPTH else []
            self.invoke(s.script, "summarize", "--root", s.root, "--output", temp, *flags)
            validate(temp)
            temp.rename(dest)

    def progress(self, s):
        value = self.invoke(s.script, "status", "--root", s.root, capture=True)
        return value[s.phase] if s.phase else value

    def process(self, s):
        self.check_pause()
        self.note(s.key, "检查进度")
        self.prepare(s)
        if not self.progress(s)["complete"]:
            flags = ["--backend", "lightning.gpu"] if s.script != NOISE else []
            if s.script in (REF, CONF, DEPTH):
                flags.extend(["--workers", "4"])
            if s.phase:
                flags.extend(["--phase", s.phase])
            self.note(s.key, "运行")
            self.marker = s.root / ("STOP" if s.script == EARLY else "stop.request")
            try:
                self.invoke(s.script, "run", "--root", s.root, *flags, "--execute")
            finally:
                self.marker = None
            self.check_pause()
            if not self.progress(s)["complete"]:
                raise RuntimeError(f"{s.key} 还有未完成任务。保留当前进度，下次从这里续跑。")
        self.check_pause()
        self.summarize(s)
        self.note(s.key, "完成")

    def preflight(self):
        self.note("preflight", "模型与 GPU 检查")

        deps = self.control / "model-deps"
        probe = "import xgboost; assert xgboost.__version__ == '3.4.1'"
        import_path = os.pathsep.join(filter(None, [str(deps), self.env.get("PYTHONPATH")]))
        if deps.exists():
            self.env["PYTHONPATH"] = import_path
        if subprocess.run([sys.executable, "-B", "-c", probe], env=self.env, capture_output=True).returncode:
            if deps.exists():
                raise RuntimeError(f"已有模型依赖目录无法加载，请检查 {deps}")
            self.check_pause()
            target = self.control / ("model-deps-" + stamp())
            print("正在安装模型预检需要的 xgboost-cpu 3.4.1 到本次任务目录", flush=True)
            subprocess.run([sys.executable, "-m", "pip", "install", "--no-deps", "--target", str(target),
                            "xgboost-cpu==3.4.1"], check=True)
            target.rename(deps)
            self.env["PYTHONPATH"] = import_path
        self.invoke(CONF, "preflight")

        env = self.invoke("-c", "import json; from qaoa_study.experiments import environment; "
                          "e=environment('lightning.gpu'); e.pop('device_identity',None); print(json.dumps(e))", capture=True)
        cfg = read(self.package / "followup/depth/config.json")["optimizer"]
        candidates = [self.package / "results/backend-check.json", *self.control.glob("gpu-*.json")]
        for file in candidates:
            if file.exists():
                try:
                    value = read(file)
                    observed = {k:v for k,v in value["environment"].items() if k != "device_identity"}
                    plan = value["plan"]
                    if (value["status"] == "completed" and observed == env and plan["depths"] == [1,2,3]
                            and plan["sizes"] == [4,18] and plan["settings"] == cfg
                            and plan["restart_backends"] == ["lightning.gpu"]
                            and value["source"] == read(self.package / "bundle-manifest.json")["source"]):
                        return
                except (KeyError, ValueError):
                    continue
        base = self.control / ("gpu-" + stamp())
        self.invoke("scripts/verify_backend.py", "--execute", "--backend", "lightning.gpu", "--sizes", "4", "18",
                    "--depths", "1", "2", "3", "--config", "../followup/depth/config.json",
                    "--output", base.with_suffix(".json"), "--attempts-dir", str(base) + "-attempts")
        if read(base.with_suffix(".json"))["status"] != "completed":
            raise RuntimeError("GPU 检查未通过")

    def run(self):
        self.control.mkdir(parents=True, exist_ok=True)
        with lock(self.control / "queue.lock") as fd:
            self.fd = fd
            self.pause.unlink(missing_ok=True)
            def request_pause(*_):
                self.pause.touch()
            old = {sig: signal.signal(sig, request_pause) for sig in (signal.SIGINT, signal.SIGTERM)}
            try:
                if self.state.exists() and read(self.state).get("stage") == "done":
                    print("全部完成", flush=True)
                    return
                for s in self.stages:
                    child_lock = s.root / ("driver.lock" if s.script == NOISE else "writer.lock")
                    if child_lock.is_file():
                        try:
                            with lock(child_lock):
                                pass
                        except RuntimeError as exc:
                            raise RuntimeError(f"{s.key} 仍在手动运行。等该批次保存并退出后再用串行命令。") from exc
                self.preflight()
                for stage in self.stages:
                    self.process(stage)
                self.note("done", "全部完成")
            finally:
                for sig, handler in old.items():
                    signal.signal(sig, handler)
                self.fd = None

    def inspect(self, stop):
        if not self.state.exists():
            print("尚未启动")
            return
        state = read(self.state)
        if state["stage"] == "done":
            print("全部完成")
            return
        if stop:
            self.pause.touch()
        live = self.active()
        print("运行中" if live else "已停止", state["stage"], state["operation"])
        s = next((s for s in self.stages if s.key == state["stage"]), None)
        if stop:
            print("正在暂停，等待当前任务保存。", flush=True)
            while self.active() and self.pause.exists():
                state = read(self.state)
                s = next((s for s in self.stages if s.key == state["stage"]), None)
                if s and state["operation"] == "运行" and s.root.is_dir():
                    if s.script != NOISE or (s.root / "execution.json").is_file():
                        (s.root / ("STOP" if s.script == EARLY else "stop.request")).touch()
                time.sleep(1)
            print("已暂停")
        elif s and s.root.is_dir():
            cmd = [sys.executable,"-B",s.script,"status","--root",str(s.root)]
            p = subprocess.run(cmd, cwd=self.runtime, env=self.env, stdout=subprocess.PIPE, text=True)
            if p.stdout.strip():
                data = json.loads(p.stdout)
                data = data[s.phase] if s.phase else data
                keys = ("complete","valid","planned","completed","valid_pairs","planned_pairs","remaining","unresolved_execution_faults")
                print(json.dumps({k:data[k] for k in keys if k in data}))
        if not stop and self.pause.exists():
            print("已请求暂停")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("run", "status", "stop"), default="run", nargs="?")
    action = parser.parse_args().action
    entry = Path(sys.argv[0]).resolve()
    package = entry.parent / NAME
    q = Queue(package)
    try:
        if action == "run":
            check_files(package)
            q.run()
        else:
            q.inspect(action == "stop")
    except Paused:
        print("已暂停。再次执行原命令即可续跑。")
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.SubprocessError) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import tempfile
import zipfile

from qaoa_study.experiments import (
    _b5_model_summary, _writer_lock, digest, load_attempts, read_b4_fits, read_b4_inputs,
    read_b5_explanations, read_b5_fits, read_b5_inputs, read_batch,
    runtime_files, select_attempts, source_identity,
)
from qaoa_study.records import execution_failed, read_json, read_library, resolve_success_metric


LIBRARY_FILES = ("graphs.parquet", "config.json", "generation.jsonl", "splits.json", "manifest.json")


def _file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def _publish(output, payload, manifest, *, validate_inventory=None):

    output = Path(output)
    if output.exists():
        raise FileExistsError(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=f".{output.name}.",
                                         suffix=".tmp", delete=False) as stream:
            temporary = Path(stream.name)
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, value in sorted(payload.items()):
                if isinstance(value, Path):
                    archive.write(value, name)
                else:
                    archive.writestr(name, value)
            archive.writestr("snapshot.json", json.dumps(manifest, indent=2, allow_nan=False) + "\n")
        with zipfile.ZipFile(temporary) as archive:
            for name, expected in manifest["files"].items():
                with archive.open(name) as stream:
                    if hashlib.file_digest(stream, "sha256").hexdigest() != expected:
                        raise ValueError(f"Files changed while capturing snapshot: {name}")
        with temporary.open("r+b") as stream:
            os.fsync(stream.fileno())
        if validate_inventory is not None:
            validate_inventory()
        os.link(temporary, output)
    finally:
        if temporary is not None:
            temporary.unlink(missing_ok=True)
    return {"snapshot_id": manifest["snapshot_id"], "source_id": manifest["source_id"],
            "library_id": manifest["library_id"], "files": len(payload),
            "archive_sha256": _file_hash(output)}


def _payload_path(root, name):

    relative = PurePosixPath(name)
    if relative.is_absolute() or ".." in relative.parts or "\\" in name or ":" in name:
        raise ValueError(f"Snapshot path must be relative and portable: {name}")
    path = root.joinpath(*relative.parts)
    if not path.resolve().is_relative_to(root.resolve()) or path.is_symlink():
        raise ValueError(f"Snapshot path leaves its selected directory: {name}")
    return path


def create_snapshot(output, library_path, config_path, *, root=None):

    root = Path(root or Path(__file__).resolve().parents[1]).resolve()
    output, library_path, config_path = Path(output), Path(library_path).resolve(), Path(config_path).resolve()
    if output.exists():
        raise FileExistsError(output)
    try:
        config_relative = config_path.relative_to(root).as_posix()
    except ValueError as error:
        raise ValueError("Configuration must be a runtime configs/*.json file inside the source root.") from error
    identity = source_identity(root)
    if config_relative not in identity["files"] or config_path.parent != root / "configs":
        raise ValueError("Configuration must be in the explicit runtime configs/*.json boundary.")
    read_json(config_path)
    library = read_library(library_path)
    payload = {}
    for path in runtime_files(root):
        name = path.relative_to(root).as_posix()
        payload[name] = _payload_path(root, name).read_bytes()
        if hashlib.sha256(payload[name]).hexdigest() != identity["files"][name]:
            raise ValueError("Working files changed while preparing the snapshot; retry after editing stops.")
    for name in LIBRARY_FILES:
        payload[f"data/library/{name}"] = _payload_path(library_path, name).read_bytes()

    library_manifest = json.loads(payload["data/library/manifest.json"])
    if library_manifest["library_metadata"]["library_id"] != library["library_id"]:
        raise ValueError("Frozen library identity changed while preparing the snapshot.")
    for name in LIBRARY_FILES[:-1]:
        if hashlib.sha256(payload[f"data/library/{name}"]).hexdigest() != library_manifest["files"][name]:
            raise ValueError("Frozen library changed while preparing the snapshot.")
    manifest = {"snapshot_version": 1, "source_id": identity["source_id"],
                "source_files": identity["files"], "config_path": config_relative,
                "library_path": "data/library", "library_id": library["library_id"],
                "files": {name: hashlib.sha256(value).hexdigest() for name, value in sorted(payload.items())}}
    manifest["snapshot_id"] = digest(manifest)
    return _publish(output, payload, manifest)


def _tree_files(root, directory):

    directory = _payload_path(root, directory)
    paths = sorted(directory.rglob("*")) if directory.is_dir() else [directory]
    if any(path.is_symlink() for path in paths):
        raise ValueError("Checkpoint inputs cannot contain symlinks.")
    return {path.relative_to(root).as_posix(): path for path in paths
            if path.is_file() and path.name != "writer.lock"}


def _dependencies(value, external_root=None, *, kind="b3"):

    checkpoints, inputs = value["checkpoints"], value["comparison_inputs"]
    roles = ["B1", "B2"] + (["B3"] if kind in ("b4", "b5") else []) + (["B4"] if kind == "b5" else [])
    expected = {"b1_batch", "b1_attempts", "b2_cases"}
    if kind in ("b4", "b5"):
        expected |= {"b3_batch", "b3_attempts"}
    if kind == "b5":
        expected |= {"b4_batch", "b4_attempts"}
    if value.get("dependency_version") != 1 or sorted(row["role"] for row in checkpoints) != roles:
        raise ValueError(f"Checkpoint dependencies require exactly canonical {roles} entries.")
    overlay_keys = {"success_overlay"} if kind == "b4" else {"success_overlay", "b4_success_overlay"} if kind == "b5" else set()
    if not expected <= set(inputs) <= expected | overlay_keys or not inputs["b2_cases"]:
        raise ValueError("Checkpoint comparison inputs do not match the declared stage.")
    analysis_files = value.get("analysis_files", {})
    if set(analysis_files) != {inputs[key] for key in overlay_keys & set(inputs)}:
        raise ValueError("Every analysis overlay must have exactly one declared checksum.")
    paths = [inputs["b1_batch"], inputs["b1_attempts"]]
    if kind in ("b4", "b5"):
        paths.extend([inputs["b3_batch"], inputs["b3_attempts"]])
    if kind == "b5":
        paths.extend([inputs["b4_batch"], inputs["b4_attempts"]])
    for case in inputs["b2_cases"]:
        if len(case) != 2:
            raise ValueError("Each B2 case must give its batch and attempts paths.")
        paths.extend(case)
    for row in checkpoints:
        if len(row["sha256"]) != 64 or any(c not in "0123456789abcdef" for c in row["sha256"]):
            raise ValueError("Canonical checkpoint sha256 is invalid.")
        paths.append(row["path"])
    for name, checksum in analysis_files.items():
        if len(checksum) != 64 or any(c not in "0123456789abcdef" for c in checksum):
            raise ValueError("Analysis overlay sha256 is invalid.")
        paths.append(name)
    for name in paths:
        relative = PurePosixPath(name)
        if relative.is_absolute() or ".." in relative.parts or "\\" in name or ":" in name:
            raise ValueError("External dependency paths must be relative and portable.")
    if external_root is not None:
        base = Path(external_root).resolve()
        for row in checkpoints:
            if _file_hash(_payload_path(base, row["path"])) != row["sha256"]:
                raise ValueError(f"Canonical {row['role']} checkpoint checksum mismatch.")
        for name, checksum in analysis_files.items():
            if _file_hash(_payload_path(base, name)) != checksum:
                raise ValueError("Analysis overlay checksum mismatch.")
    return inputs


def _checkpoint_state(root, manifest, external_root=None, *, dependencies=None):

    if manifest.get("kind") not in ("b3-checkpoint-v1", "b4-checkpoint-v1", "b5-checkpoint-v1"):
        raise ValueError("Unsupported result checkpoint kind.")
    kind = manifest["kind"].split("-")[0]
    batch, library, tasks = read_batch(_payload_path(root, manifest["batch_path"]))
    if batch["config"].get("kind") != kind or batch["source_id"] != manifest["source_id"]:
        raise ValueError(f"Checkpoint requires a {kind.upper()} batch with matching frozen runtime source.")
    if (library["library_id"] != manifest["library_id"] or
            (_payload_path(root, manifest["batch_path"]) / batch["library_path"]).resolve()
            != _payload_path(root, manifest["library_path"]).resolve()):
        raise ValueError("Checkpoint library path or identity disagrees with the batch.")
    config = read_json(_payload_path(root, manifest["config_path"]))
    if config.get("kind") != kind or any(batch["config"].get(key) != value for key, value in config.items()):
        raise ValueError("Checkpoint candidate configuration disagrees with the frozen batch.")
    audit = {}
    attempts, execution = load_attempts(batch, tasks, _payload_path(root, manifest["attempts_path"]),
                                        metadata_only=True, audit=audit)
    summary = read_json(_payload_path(root, manifest["summary_path"]))
    if (execution is None or summary.get("batch_id") != batch["batch_id"] or
            summary.get("execution_id") != execution["execution_id"] or
            summary.get("analysis_source") != batch["source"]):
        raise ValueError("Checkpoint summary, execution or analysis source mismatch.")
    keys = ("preparation_id", "reference_binding_digest") if kind in ("b4", "b5") else (
        "initialization_set_id", "reference_binding_digest")
    if (any(summary.get(key) != batch["config"][kind + "_inputs"][key] for key in keys) or
            summary["input_audits"][kind.upper()]["input_digest"] != digest(audit.get("file_hashes", {}))):
        raise ValueError("Checkpoint summary does not describe the frozen initialization/binding and retained attempts.")
    if kind in ("b4", "b5"):
        if manifest.get("fits_path") not in manifest["result_trees"]:
            raise ValueError(f"{kind.upper()} checkpoint must retain the complete fit tree.")
        prepared, _ = (read_b4_inputs if kind == "b4" else read_b5_inputs)(
            _payload_path(root, manifest["batch_path"]), batch)
        fits = (read_b4_fits if kind == "b4" else read_b5_fits)(_payload_path(root, manifest["fits_path"]))
        fit_manifest = fits["manifest"]
        models = fits["models"] if kind == "b4" else [_b5_model_summary(model) for model in fits["models"]]
        if (fit_manifest != prepared["fit_set_manifest"] or models != prepared["models"]
                or fit_manifest["fit_set_id"] != prepared["fit_set_id"]
                or fit_manifest["fit_set_id"] != summary.get("fit_set_id")
                or fit_manifest["source"] != batch["source"]
                or fit_manifest["library_id"] != library["library_id"]
                or fits["features"]["feature_artifact_id"] != prepared["feature_artifact_id"]
                or fits["training"]["reference_binding"] != prepared["training_binding"]):
            raise ValueError(f"{kind.upper()} checkpoint fitting artifacts disagree with frozen predictions or summary.")
        if kind == "b5":
            explanations = read_b5_explanations(_payload_path(root, manifest["batch_path"]), prepared)
            chosen = select_attempts(attempts)
            if (set(chosen) != {task["task_id"] for task in tasks}
                    or any(not row.get("run_completed") or execution_failed(row) for row in chosen.values())
                    or summary.get("warm_compute_complete") is not True or summary.get("analysis_complete") is not True
                    or summary.get("shap_coverage", {}).get("complete") is not True
                    or summary["shap_coverage"].get("observed_rows") != len(explanations["rows"])
                    or summary["shap_coverage"].get("planned_rows") != len(explanations["rows"])):
                raise ValueError("B5 complete checkpoint requires all valid planned tasks and complete SHAP analysis.")
    if dependencies is None:
        dependencies = read_json(_payload_path(root, "checkpoint/dependencies.json"))
    inputs = _dependencies(dependencies, external_root, kind=kind)
    overlay_methods = {key: method for key, method in
                       (("success_overlay", kind.upper()), ("b4_success_overlay", "B4")) if key in inputs}
    saved_overlays = summary.get("success_prediction_overlays", {})
    if (set(saved_overlays) != set(overlay_methods.values()) or any(
            saved_overlays[method].get("sha256") != dependencies["analysis_files"][inputs[key]]
            for key, method in overlay_methods.items())):
        raise ValueError("Checkpoint analysis overlay differs from the saved summary.")
    if external_root is not None:
        external_root = Path(external_root).resolve()
        baseline, _, _ = read_batch(_payload_path(external_root, inputs["b1_batch"]))
        baseline_execution = read_json(_payload_path(external_root, inputs["b1_attempts"] + "/manifest.json"))
        cases = [(read_batch(_payload_path(external_root, batch_path))[0]["batch_id"],
                  read_json(_payload_path(external_root, attempts_path + "/manifest.json"))["execution_id"])
                 for batch_path, attempts_path in inputs["b2_cases"]]
        if (baseline["batch_id"] != summary["b1_batch_id"] or
                baseline_execution["execution_id"] != summary["b1_execution_id"] or
                sorted(cases) != sorted((row["batch_id"], row["execution_id"]) for row in summary["b2_cases"])):
            raise ValueError("External comparison batches disagree with the saved summary.")
        if kind in ("b4", "b5"):
            b3, _, _ = read_batch(_payload_path(external_root, inputs["b3_batch"]))
            b3_execution = read_json(_payload_path(external_root, inputs["b3_attempts"] + "/manifest.json"))
            if (b3["batch_id"] != summary["b3_batch_id"] or
                    b3_execution["execution_id"] != summary["b3_execution_id"]):
                raise ValueError(f"External B3 comparison disagrees with the saved {kind.upper()} summary.")
        if kind == "b5":
            b4, _, _ = read_batch(_payload_path(external_root, inputs["b4_batch"]))
            b4_execution = read_json(_payload_path(external_root, inputs["b4_attempts"] + "/manifest.json"))
            if (b4["batch_id"] != summary["b4_batch_id"] or
                    b4_execution["execution_id"] != summary["b4_execution_id"]):
                raise ValueError("External B4 comparison disagrees with the saved B5 summary.")
        for key, method in overlay_methods.items():
            from scripts.experiment import _success_prediction_overlay
            baseline_overlay = key == "b4_success_overlay"
            overlay_batch = _payload_path(external_root, inputs["b4_batch"]) if baseline_overlay else _payload_path(root, manifest["batch_path"])
            overlay_manifest = b4 if baseline_overlay else batch
            reader = read_b5_inputs if method == "B5" else read_b4_inputs
            overlay_prepared, _ = reader(overlay_batch, overlay_manifest)
            view = _success_prediction_overlay(_payload_path(external_root, inputs[key]), overlay_batch,
                overlay_manifest, overlay_prepared, resolve_success_metric(summary["settings"]))
            if view["analysis_overlay"]["overlay_id"] != saved_overlays[method].get("overlay_id"):
                raise ValueError("Checkpoint analysis overlay identity differs from the saved summary.")
    return {"batch_id": batch["batch_id"], "retained_completed_attempts": len(attempts),
            "summary_complete": summary.get("complete"), "external_dependencies_verified": external_root is not None}


REPRODUCE_SCRIPT = '''"""Rebuild a saved summary read-only using retained external comparison data."""
import argparse
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from scripts.snapshot import verify_snapshot
from scripts.experiment import summarize_b3_batch, summarize_b4_batch, summarize_b5_batch
from qaoa_study.records import write_once_json

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--external-root", type=Path, required=True)
parser.add_argument("--output", type=Path, required=True)
args = parser.parse_args()
verify_snapshot(root, external_root=args.external_root)
manifest = json.loads((root / "snapshot.json").read_text())
inputs = json.loads((root / "checkpoint/dependencies.json").read_text())["comparison_inputs"]
saved_summary = json.loads((root / manifest["summary_path"]).read_text())
analysis_settings = saved_summary["settings"]
external = args.external_root.resolve()
arguments = [root / manifest["batch_path"], root / manifest["attempts_path"],
    external / inputs["b1_batch"], external / inputs["b1_attempts"],
    [(external / batch, external / attempts) for batch, attempts in inputs["b2_cases"]]]
if manifest["kind"] == "b5-checkpoint-v1":
    summary = summarize_b5_batch(*arguments, external / inputs["b3_batch"], external / inputs["b3_attempts"],
        external / inputs["b4_batch"], external / inputs["b4_attempts"], analysis_settings=analysis_settings,
        success_overlay=external / inputs["success_overlay"] if "success_overlay" in inputs else None,
        b4_success_overlay=external / inputs["b4_success_overlay"] if "b4_success_overlay" in inputs else None)
elif manifest["kind"] == "b4-checkpoint-v1":
    summary = summarize_b4_batch(*arguments, external / inputs["b3_batch"], external / inputs["b3_attempts"],
        analysis_settings=analysis_settings,
        success_overlay=external / inputs["success_overlay"] if "success_overlay" in inputs else None)
else:
    summary = summarize_b3_batch(*arguments, analysis_settings=analysis_settings)
write_once_json(args.output, summary)
print(json.dumps({"complete": summary["complete"], "batch_id": summary["batch_id"]}))
'''


def create_b3_checkpoint(output, library_path, config_path, batch, attempts_directory,
                         summary_path, dependencies_path, *, root=None, external_root=None):


    return _create_checkpoint(output, library_path, config_path, batch, attempts_directory,
                              summary_path, dependencies_path, kind="b3", root=root, external_root=external_root)


def create_b4_checkpoint(output, library_path, config_path, batch, attempts_directory,
                         summary_path, dependencies_path, *, fits_directory, support_paths=(),
                         root=None, external_root=None):


    return _create_checkpoint(output, library_path, config_path, batch, attempts_directory,
                              summary_path, dependencies_path, kind="b4", fits_directory=fits_directory,
                              support_paths=support_paths, root=root, external_root=external_root)


def create_b5_checkpoint(output, library_path, config_path, batch, attempts_directory,
                         summary_path, dependencies_path, *, fits_directory, support_paths=(),
                         root=None, external_root=None):


    return _create_checkpoint(output, library_path, config_path, batch, attempts_directory,
                              summary_path, dependencies_path, kind="b5", fits_directory=fits_directory,
                              support_paths=support_paths, root=root, external_root=external_root)


def _create_checkpoint(output, library_path, config_path, batch, attempts_directory,
                       summary_path, dependencies_path, *, kind, fits_directory=None, support_paths=(),
                       root=None, external_root=None):
    root = Path(root or Path(__file__).resolve().parents[1]).resolve()
    external_root = Path(external_root or root).resolve()
    output = Path(output).resolve()
    if output.exists():
        raise FileExistsError(output)
    locations = {name: Path(path).resolve().relative_to(root).as_posix() for name, path in
                 (("library_path", library_path), ("config_path", config_path), ("batch_path", batch),
                  ("attempts_path", attempts_directory), ("summary_path", summary_path))}
    summary_tree = locations["summary_path"]
    if _payload_path(root, summary_tree).is_dir():
        locations["summary_path"] += "/summary.json"
    trees = [locations["batch_path"], locations["attempts_path"], summary_tree]
    if kind in ("b4", "b5"):
        locations["fits_path"] = Path(fits_directory).resolve().relative_to(root).as_posix()
        trees.append(locations["fits_path"])
        for path in support_paths:
            support = Path(path).resolve()
            name = support.relative_to(root).as_posix()
            if not support.exists():
                raise FileNotFoundError(support)
            trees.append(name)
    elif support_paths:
        raise ValueError("Support paths are only supported for B4/B5 checkpoints.")
    if any(name == "." for name in trees):
        raise ValueError("Select individual result directories, not the whole source root.")
    if any(output.is_relative_to(_payload_path(root, name)) for name in trees):
        raise ValueError("Checkpoint output must be outside its selected input trees.")
    identity = source_identity(root)
    dependencies = read_json(dependencies_path)
    _dependencies(dependencies, kind=kind)
    with _writer_lock(_payload_path(root, locations["attempts_path"])):
        payload = {name: _payload_path(root, name) for name in identity["files"]}
        payload[locations["config_path"]] = _payload_path(root, locations["config_path"])
        payload.update({locations["library_path"] + "/" + name: _payload_path(root, locations["library_path"] + "/" + name)
                        for name in LIBRARY_FILES})
        tree_payload = {name: path for directory in trees for name, path in _tree_files(root, directory).items()}
        payload.update(tree_payload)
        canonical = {_payload_path(external_root, row["path"]).resolve() for row in dependencies["checkpoints"]}
        if any(path.resolve() in canonical for path in payload.values()):
            raise ValueError("Canonical earlier archives must remain external to the checkpoint.")
        payload["checkpoint/dependencies.json"] = (json.dumps(dependencies, indent=2, allow_nan=False) + "\n").encode()
        payload["checkpoint/reproduce.py"] = REPRODUCE_SCRIPT.encode()
        library = read_library(_payload_path(root, locations["library_path"]))
        manifest = {"snapshot_version": 2, "kind": kind + "-checkpoint-v1", **locations,
                    "source_id": identity["source_id"], "source_files": identity["files"],
                    "library_id": library["library_id"], "result_trees": trees,
                    "files": {name: _file_hash(value) if isinstance(value, Path) else hashlib.sha256(value).hexdigest()
                              for name, value in sorted(payload.items())}}
        if any(manifest["files"][name] != value for name, value in identity["files"].items()):
            raise ValueError("Working source changed while preparing checkpoint.")
        state = _checkpoint_state(root, manifest, external_root, dependencies=dependencies)
        if state["summary_complete"] is not True:
            raise ValueError(f"A complete {kind.upper()} checkpoint requires a complete saved summary.")
        def validate_inventory():
            if tree_payload != {name: path for directory in trees for name, path in _tree_files(root, directory).items()}:
                raise ValueError("Result inventory changed while preparing checkpoint.")
        manifest["snapshot_id"] = digest(manifest)
        return _publish(output, payload, manifest, validate_inventory=validate_inventory)


def verify_snapshot(directory, *, external_root=None):


    directory = Path(directory).resolve()
    manifest = read_json(directory / "snapshot.json")
    if manifest.get("snapshot_version") not in (1, 2):
        raise ValueError("Unsupported snapshot version.")
    if digest({key: value for key, value in manifest.items() if key != "snapshot_id"}) != manifest["snapshot_id"]:
        raise ValueError("Snapshot manifest checksum mismatch.")
    expected_runtime = {path.relative_to(directory).as_posix() for path in runtime_files(directory)}
    expected_library = {manifest["library_path"] + "/" + name for name in LIBRARY_FILES}
    expected = expected_runtime | expected_library
    if manifest["snapshot_version"] == 2:
        if manifest.get("kind") not in ("b3-checkpoint-v1", "b4-checkpoint-v1", "b5-checkpoint-v1"):
            raise ValueError("Unsupported result checkpoint kind.")
        expected |= {name for tree in manifest["result_trees"] for name in _tree_files(directory, tree)}
        expected |= {manifest["config_path"], "checkpoint/dependencies.json", "checkpoint/reproduce.py"}
    if set(manifest["files"]) != expected:
        raise ValueError("Snapshot payload does not match the runtime/library boundary.")
    if manifest["snapshot_version"] == 1 and (manifest["config_path"] not in expected_runtime or
            PurePosixPath(manifest["config_path"]).parent != PurePosixPath("configs")):
        raise ValueError("Snapshot config is not inside its runtime boundary.")
    if manifest["snapshot_version"] == 1 and manifest["library_path"] != "data/library":
        raise ValueError("Unexpected frozen library location.")
    for name, expected in manifest["files"].items():
        if _file_hash(_payload_path(directory, name)) != expected:
            raise ValueError(f"Snapshot payload checksum mismatch: {name}")
    actual_source = source_identity(directory)
    if actual_source != {"source_id": manifest["source_id"], "files": manifest["source_files"]}:
        raise ValueError("Snapshot working source identity mismatch.")
    library = read_library(_payload_path(directory, manifest["library_path"]))
    if library["library_id"] != manifest["library_id"]:
        raise ValueError("Snapshot library identity mismatch.")
    result = {"snapshot_id": manifest["snapshot_id"], "source_id": manifest["source_id"],
              "library_id": manifest["library_id"], "files_verified": len(manifest["files"])}
    if manifest["snapshot_version"] == 2:
        result.update(_checkpoint_state(directory, manifest, external_root))
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--library", type=Path)
    parser.add_argument("--config", type=Path)
    parser.add_argument("--verify", type=Path, help="Verify an already extracted snapshot directory.")
    parser.add_argument("--checkpoint", action="store_true", help="Capture complete B3 results and external dependency declarations.")
    parser.add_argument("--checkpoint-b4", action="store_true", help="Capture complete B4 results, fits and dependencies.")
    parser.add_argument("--checkpoint-b5", action="store_true", help="Capture complete B5 native fits, SHAP and dependencies.")
    parser.add_argument("--support", type=Path, action="append", default=[],
                        help="Explicit B4/B5 support file/directory inside the source root; repeat as needed.")
    for name in ("batch", "attempts", "summary", "dependencies", "external-root", "fits"):
        parser.add_argument("--" + name, type=Path)
    args = parser.parse_args(argv)
    if args.verify is not None:
        if args.checkpoint or args.checkpoint_b4 or args.checkpoint_b5 or args.support or any(value is not None for value in
                (args.output, args.library, args.config, args.batch, args.attempts, args.summary, args.dependencies, args.fits)):
            parser.error("--verify is separate from snapshot creation options")
        result = verify_snapshot(args.verify, external_root=args.external_root)
    else:
        if any(value is None for value in (args.output, args.library, args.config)):
            parser.error("snapshot creation requires --output, --library and --config")
        if sum((args.checkpoint, args.checkpoint_b4, args.checkpoint_b5)) > 1:
            parser.error("Select only one checkpoint stage")
        if args.checkpoint or args.checkpoint_b4 or args.checkpoint_b5:
            if any(value is None for value in (args.batch, args.attempts, args.summary, args.dependencies)):
                parser.error("Checkpoint requires --batch, --attempts, --summary and --dependencies")
            if args.checkpoint_b4 or args.checkpoint_b5:
                if args.fits is None:
                    parser.error("B4/B5 checkpoint requires --fits")
                creator = create_b5_checkpoint if args.checkpoint_b5 else create_b4_checkpoint
                result = creator(args.output, args.library, args.config, args.batch, args.attempts,
                    args.summary, args.dependencies, fits_directory=args.fits, support_paths=args.support,
                    external_root=args.external_root)
            else:
                if args.fits is not None or args.support:
                    parser.error("--fits and --support require --checkpoint-b4 or --checkpoint-b5")
                result = create_b3_checkpoint(args.output, args.library, args.config, args.batch, args.attempts,
                                             args.summary, args.dependencies, external_root=args.external_root)
        else:
            if args.support or any(value is not None for value in (args.batch, args.attempts, args.summary, args.dependencies, args.external_root, args.fits)):
                parser.error("Result options require --checkpoint, --checkpoint-b4 or --checkpoint-b5")
            result = create_snapshot(args.output, args.library, args.config)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

import argparse
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import time
import traceback
from uuid import uuid4
import zipfile

sys.dont_write_bytecode = True
SCRIPT = Path(__file__).resolve()
SOURCE = "a11de973a84fab732cb3c5d6d0377c61c66d02d21c15023eae78584896267ee6"
BACKEND = "lightning.gpu"
B1_IDS = {"batch": "a5fb23f92fcae091f522da900648302018fdb9b8cfa38028d54d48885fab0083",
          "execution": "e9ce2219c80db1732921c8626b8a265a2ec37186bd30d5136a1ec7968476f4f1",
          "references": "3015ea731d18491d9208b933d06db7a4534caf2ee0c94c91cb5279ee79ac658f"}
CHECKPOINTS = {
    "B1": {"name": "qaoa-b1-full-compute-complete-20260916-144403-4d268e.tgz",
           "sha256": "d7949478c3a23d9a2ffd76542cf927e26020757b664f3bcd94087fa2cbefd92a"},
    "B2": {"name": "qaoa-b2-full-complete-20260918-194001-d223ca.tgz",
           "sha256": "a907d58b7a129370efba7f7a694c9f14d374840b276ee4a21a8a63bc5af682a5"}}
DESIGN = {"random": (300, 200), "lofo-regular": (224, 50), "lofo-er": (225, 50),
          "lofo-ba": (225, 50), "lofo-sbm": (226, 50)}
INPUT_FILES = ("batch/manifest.json", "library/manifest.json", "references/manifest.json", "attempts/manifest.json")
DEFAULT_ROOT = "data/manual/b3-full-a100-v1"
DEFAULT_B1 = "data/manual/b1-full-a100-v1"
DEFAULT_B2 = "data/manual/b2-full-a100-v1"


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def now():
    return datetime.now(timezone.utc).isoformat()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def file_hash(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def atomic_json(path, value):

    path = Path(path)
    temporary = path.with_name(path.name + ".tmp")
    with temporary.open("w", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def setup(repo):
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[name] = "1"
    os.chdir(repo)
    if str(repo) not in sys.path:
        sys.path.insert(0, str(repo))
    from qaoa_study import experiments as exp
    require(Path(exp.__file__).resolve() == repo / "qaoa_study/experiments.py", "Python imported another checkout.")
    return exp


@contextmanager
def driver_lock(root):
    stream = (root / "driver.lock").open("a+b")
    try:
        if os.name == "nt":
            import msvcrt
            if stream.tell() == 0:
                stream.write(b"0")
                stream.flush()
            stream.seek(0)
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        yield stream
    finally:
        stream.close()


def locked(root):
    if not root.exists():
        return False
    try:
        with driver_lock(root):
            return False
    except OSError:
        return True


def b2_cases(repo, meta):
    base = repo / meta["b2_root"] / "cases"
    return [(base / name / "batch", base / name / "attempts") for name in meta["cases"]]


def initialize(root, repo, b1, b2, checkpoint_paths=None):

    exp = setup(repo)
    from qaoa_study.learning import select_b2_graphs
    from qaoa_study.records import read_library, write_once_json, sync_directory
    require(exp.source_identity(repo)["source_id"] == SOURCE, "Upload the matching B3 runtime before starting.")
    baseline, execution, references = (read(b1 / name) for name in
        ("batch/manifest.json", "attempts/manifest.json", "references/manifest.json"))
    require(not baseline["issues"] and baseline["batch_id"] == B1_IDS["batch"]
            and execution["execution_id"] == B1_IDS["execution"]
            and references["reference_set_id"] == B1_IDS["references"], "Original full B1 identities differ.")
    require(exp.digest({k: baseline[k] for k in ("library_id", "config", "source_id", "tasks_sha256")})
            == baseline["batch_id"], "Invalid B1 batch identity.")
    exp._validate_execution(baseline, execution)
    library_path = (b1 / "batch" / baseline["library_path"]).resolve()
    require(library_path == (b1 / "library").resolve()
            and file_hash(library_path / "manifest.json") == baseline["library_manifest_sha256"], "B1 library layout/hash changed.")
    library = read_library(library_path)
    require(library["library_id"] == baseline["library_id"], "Wrong B1 library.")
    cases, b2_files = {}, {}
    for name, counts in DESIGN.items():
        regime, fold = ("random", None) if name == "random" else ("lofo", name.removeprefix("lofo-"))
        ids = {split: [g["iso_class_id"] for g in select_b2_graphs(library, regime, fold, split)]
               for split in ("training", "evaluation")}
        require(tuple(len(ids[s]) for s in ("training", "evaluation")) == tuple(counts), f"Wrong {name} coverage.")
        folder = b2 / "cases" / name
        warm, _, tasks = exp.read_batch(folder / "batch")
        fit, binding = exp.read_b2_inputs(folder / "batch", warm)
        other_execution = read(folder / "attempts/manifest.json")
        exp._validate_execution(warm, other_execution)
        exp.validate_b1_comparison(warm, baseline, other_execution, execution)
        expected = {(graph, p, variant) for graph in ids["evaluation"] for p in (1, 2)
                    for variant in ("medoid", "aligned_median")}
        require(not warm["issues"] and fit["regime"] == regime and fit["fold"] == fold
                and fit["training_graph_ids"] == ids["training"] and binding["source_batch_id"] == baseline["batch_id"]
                and len(tasks) == len(expected)
                and {(t["iso_class_id"], t["p"], t["variant"]) for t in tasks} == expected, f"Wrong B2 {name} design.")
        cases[name] = {"regime": regime, "fold": fold, **ids, "b2_tasks": len(tasks),
                       "batch_id": warm["batch_id"], "execution_id": other_execution["execution_id"], "fit_id": fit["fit_id"]}
        for entry in ("batch/manifest.json", "batch/tasks.jsonl", "batch/fit.json", "batch/reference_binding.json", "attempts/manifest.json"):
            b2_files[f"cases/{name}/{entry}"] = file_hash(folder / entry)
    config = read(repo / "configs/b3-candidate.json")
    require(config["kind"] == "b3" and config["depths"] == [1, 2] and config["epsilon"] == config["analysis"]["epsilon"] == 0.5
            and config["seed"] == 20260919 and config["analysis"]["bootstrap_seed"] == 20260912
            and config["analysis"]["bootstrap_samples"] == 2000
            and config["comparison_cases"] == [{"regime": row["regime"], "fold": row["fold"]} for row in cases.values()],
            "Unexpected B3 candidate settings.")
    config.update(production_frozen=True, purpose="User-approved full B3, original B1/B2 evaluation graphs and single-run budgets")
    checkpoints = []
    for role, expected in CHECKPOINTS.items():
        path = Path((checkpoint_paths or {}).get(role, repo / expected["name"])).resolve()
        require(path.is_relative_to(repo) and not path.is_relative_to(root) and not path.is_symlink(), "Canonical archives must be separate files inside repo.")
        require(file_hash(path) == expected["sha256"], f"Canonical {role} archive checksum mismatch.")
        if role == "B2":
            with tarfile.open(path, "r:gz") as archive:
                frozen = json.load(archive.extractfile("CHECKPOINT.json"))
            require(frozen["compute_complete"] and frozen["summaries_complete"]
                    and frozen["tasks"] == sum(row["b2_tasks"] for row in cases.values())
                    and all(frozen["files"].get("run/" + name) == value for name, value in b2_files.items()),
                    "Expanded B2 case inputs do not match the canonical checkpoint.")
        checkpoints.append({"role": role, "path": path.relative_to(repo).as_posix(), "sha256": expected["sha256"]})
    meta = {"format": "full-b3-driver-v1", "source_id": SOURCE, "driver_sha256": file_hash(SCRIPT),
            "backend": BACKEND, "config": config, "cases": cases, "tasks": 2 * len(cases["random"]["evaluation"]),
            "b1_root": b1.relative_to(repo).as_posix(), "b2_root": b2.relative_to(repo).as_posix(), "b1_ids": B1_IDS,
            "checkpoints": checkpoints, "b1_files": {name: file_hash(b1 / name) for name in INPUT_FILES}, "b2_files": b2_files}
    if (root / "run.json").exists():
        require(read(root / "run.json") == meta, "Frozen driver/design/dependencies changed; do not overwrite this run.")
    else:
        disposable = {"driver.lock", "logs", "status.json", "status.json.tmp", "stop.json", "stop.json.tmp"}
        require(all(p.name in disposable or (p.name.startswith(".run.json.") and p.name.endswith(".tmp"))
                    for p in root.iterdir()), "Choose an empty B3 output directory.")
        write_once_json(root / "run.json", meta)
    if (root / "config.json").exists():
        require(read(root / "config.json") == config, "Frozen B3 configuration changed.")
    else:
        write_once_json(root / "config.json", config)
    sync_directory(root)
    return meta


def identity(root, repo):
    exp = setup(repo)
    meta = read(root / "run.json")
    require(meta["source_id"] == SOURCE == exp.source_identity(repo)["source_id"], "Runtime source changed.")
    require(meta["driver_sha256"] == file_hash(SCRIPT), "Driver changed; use the frozen script.")
    require(read(root / "config.json") == meta["config"], "Frozen B3 config changed.")
    b1, b2 = repo / meta["b1_root"], repo / meta["b2_root"]
    require(all(file_hash(b1 / name) == value for name, value in meta["b1_files"].items())
            and all(file_hash(b2 / name) == value for name, value in meta["b2_files"].items()), "Original B1/B2 input manifests changed.")
    return meta, b1, b2


def check_environment(root, repo):
    meta, b1, _ = identity(root, repo)
    current = setup(repo).environment(meta["backend"])
    location = current.pop("device_identity")
    baseline = read(b1 / "attempts/manifest.json")["environment"]
    differences = {k: {"B1": baseline.get(k), "current": current.get(k)}
                   for k in baseline.keys() | current.keys() if baseline.get(k) != current.get(k)}
    require(not differences, "B1/B3 environment mismatch: " + json.dumps(differences))
    if meta["backend"] == "lightning.gpu":
        require(not current["gpu"]["unknown"] and "A100" in current["gpu"]["model"], "An identified A100 is required.")
        require(int(os.environ.get("MEM_LIMIT", 8 * 1024**3)) >= 8 * 1024**3, "Select at least 8 GiB host RAM.")
    from qaoa_study.records import write_once_json, sync_directory
    if (root / "environment.json").exists():
        require(read(root / "environment.json") == current, "Environment changed after preparation.")
    else:
        write_once_json(root / "environment.json", current)
    sync_directory(root)
    return location


def staged(parent, name, build, validate):
    target = parent / name
    if target.exists():
        return validate(target)
    temporary = parent / (".stage-" + name + "-" + uuid4().hex)
    build(temporary)
    result = validate(temporary)
    from qaoa_study.records import sync_directory
    for path in temporary.rglob("*"):
        require(not path.is_symlink(), "Scientific stage contains a symlink.")
        if path.is_file():
            with path.open("r+b" if os.name == "nt" else "rb") as stream:
                os.fsync(stream.fileno())
    sync_directory(temporary)
    temporary.rename(target)
    sync_directory(parent)
    return result


def prepare(root, repo):
    meta, b1, _ = identity(root, repo)
    exp = setup(repo)
    check_environment(root, repo)
    initializations = root / "initializations.json"
    if not initializations.exists():
        exp.save_b3_initializations(initializations, b1 / "library", meta["config"], backend=meta["backend"])
    prepared = read(initializations)

    def validate(path):
        manifest, _, tasks = exp.read_batch(path)
        embedded, _ = exp.read_b3_inputs(path, manifest)
        require(embedded == prepared and not manifest["issues"] and len(tasks) == meta["tasks"]
                and {(t["iso_class_id"], t["p"]) for t in tasks} ==
                    {(g, p) for g in meta["cases"]["random"]["evaluation"] for p in (1, 2)}
                and all(manifest["config"].get(k) == v for k, v in meta["config"].items()), "B3 frozen plan scope changed.")
        return manifest

    staged(root, "batch", lambda path: exp.save_b3_batch(path, initializations, b1 / "batch",
        b1 / "references", b1 / "attempts", meta["config"]), validate)
    return audit(root, repo)


def audit(root, repo, graph_ids=None):
    meta, _, _ = identity(root, repo)
    exp = setup(repo)
    from qaoa_study.records import execution_failed, record_temporary
    manifest, _, tasks = exp.read_batch(root / "batch")
    groups = {t["iso_class_id"]: {"n": t["n"], "planned": 2, "valid": 0, "faults": 0, "exhausted": 0}
              for t in tasks if graph_ids is None or t["iso_class_id"] in graph_ids}
    attempts_path = root / "attempts"
    if attempts_path.exists() and not (attempts_path / "manifest.json").exists():
        require(all(p.is_file() and (p.name == "writer.lock" or record_temporary(p.name)) for p in attempts_path.iterdir()),
                "Attempt data exist without their execution manifest.")
        return groups
    for group, attempts, execution in exp.iter_attempt_groups(manifest, tasks, attempts_path,
                                                             metadata_only=True, graph_ids=graph_ids):
        require(execution["environment"] == read(root / "environment.json") and execution["source"]["source_id"] == meta["source_id"]
                and execution["storage_layout"] == exp.PARTITIONED_LAYOUT, "B3 execution provenance changed.")
        selected = exp.select_attempts(attempts)
        faults = Counter(a["task_id"] for a in attempts if execution_failed(a))
        groups[group[0]["iso_class_id"]].update(valid=sum(not execution_failed(a) for a in selected.values()),
            faults=sum(execution_failed(a) for a in selected.values()),
            exhausted=sum(execution_failed(a) and faults[t] >= manifest["config"]["max_attempts"] for t, a in selected.items()))
    return groups


def comparison(root, repo):
    meta, b1, _ = identity(root, repo)
    from scripts.experiment import summarize_b3_batch
    return summarize_b3_batch(root / "batch", root / "attempts", b1 / "batch", b1 / "attempts", b2_cases(repo, meta))


def preflight(root, repo):

    meta, _, _ = identity(root, repo)
    summary = comparison(root, repo)
    require(not summary["batch_issues"] and len(summary["comparisons"]) == 6 * len(meta["cases"]), "Incomplete B3 comparison design.")
    require(summary["graph_qaoa"] and all(row[row["baseline_method"]]["complete"] for row in summary["graph_qaoa"]),
            "B1/B2 baseline pools are missing/faulted; provisional B3 does not excuse missing baselines.")
    from qaoa_study.records import write_once_json
    report = {"checked_utc": now(), "summary_digest": setup(repo).digest(summary), "baseline_pools_complete": True,
              "b3_complete": summary["complete"], "b2_cases": summary["b2_cases"],
              "input_audits": summary["input_audits"], "batch_id": summary["batch_id"]}
    write_once_json(root / "preflight" / (uuid4().hex + ".json"), report)
    return {"baseline_pools_complete": True, "b3_complete": summary["complete"]}


def work_graph(root, repo, graph_id):
    meta, _, _ = identity(root, repo)
    exp = setup(repo)
    check_environment(root, repo)
    groups = audit(root, repo, graph_ids=[graph_id])
    require(graph_id in groups and not groups[graph_id]["exhausted"], "Fixed execution-fault cap exhausted or unknown graph.")
    while True:
        require(shutil.disk_usage(root).free > 2 * 1024**3, "Less than 2 GiB free disk; computation paused.")
        report = exp.run_worker(root / "batch", root / "attempts", backend=meta["backend"], execute=True,
                                partitioned=True, graph_ids=[graph_id], max_tasks=1)
        require(not report["execution_faults"], "Execution fault saved; inspect logs, then manually resume if appropriate.")
        require(not report["issues"], str(report["issues"]))
        if report["valid_completed"] == report["shard_tasks"]:
            return report
        require(report["executed"] > 0, "No progress: fixed execution-fault cap exhausted.")


def summarize(root, repo):
    meta, _, _ = identity(root, repo)
    from scripts.experiment import save_summary
    summary = comparison(root, repo)
    require(summary["complete"] and len(summary["comparisons"]) == 6 * len(meta["cases"]), "Full B3 comparison is incomplete.")

    def validate(path):
        manifest = read(path / "manifest.json")
        require(manifest["summary_id"] == setup(repo).digest(summary) and read(path / "summary.json") == summary
                and set(manifest["files"]) == {"summary.json", "graph_qaoa.parquet", "restarts.parquet", "diagnostics.parquet"}
                and all(file_hash(path / n) == h for n, h in manifest["files"].items()), "Summary differs from frozen input records.")
        return {"complete": True, "summary_id": manifest["summary_id"], "tasks": meta["tasks"]}

    return staged(root, "summary", lambda path: save_summary(path, summary), validate)


def pack(root, repo):
    meta, b1, _ = identity(root, repo)
    result = summarize(root, repo)
    from qaoa_study.records import write_once_json, sync_directory
    from scripts.snapshot import create_b3_checkpoint
    dependencies = {"dependency_version": 1, "checkpoints": meta["checkpoints"], "comparison_inputs": {
        "b1_batch": (b1 / "batch").relative_to(repo).as_posix(), "b1_attempts": (b1 / "attempts").relative_to(repo).as_posix(),
        "b2_cases": [[b.relative_to(repo).as_posix(), a.relative_to(repo).as_posix()] for b, a in b2_cases(repo, meta)]}}
    path = root / "dependencies.json"
    if path.exists():
        require(read(path) == dependencies, "Checkpoint dependencies changed.")
    else:
        write_once_json(path, dependencies)
    files = {name: root / name for name in ("run.json", "config.json", "environment.json", "dependencies.json")}
    files["run_b3_full.py"] = SCRIPT
    for folder in ("validation", "preflight"):
        require((root / folder).is_dir(), f"Missing {folder} evidence.")
        for item in (root / folder).rglob("*"):
            require(not item.is_symlink(), "Evidence symlink is not allowed.")
            if item.is_file() and item.name != "writer.lock":
                files[item.relative_to(root).as_posix()] = item
    hashes = {name: file_hash(path) for name, path in files.items()}


    evidence = root / "summary/evidence"
    evidence.mkdir(exist_ok=True)
    for name, source in files.items():
        target = evidence / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            require(file_hash(target) == hashes[name], "Existing driver/backend evidence changed.")
            continue
        temporary = None
        try:
            with tempfile.NamedTemporaryFile(dir=target.parent, prefix=".evidence-", suffix=".tmp", delete=False) as stream:
                temporary = Path(stream.name)
                with source.open("rb") as original:
                    shutil.copyfileobj(original, stream)
                stream.flush()
                os.fsync(stream.fileno())
            require(file_hash(temporary) == hashes[name], "Evidence source changed while copying.")
            os.link(temporary, target)
            sync_directory(target.parent)
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)
    evidence_manifest = evidence / ("manifest-" + setup(repo).digest(hashes) + ".json")
    if not evidence_manifest.exists():
        write_once_json(evidence_manifest, {"files": hashes, "source_id": SOURCE, "driver_sha256": meta["driver_sha256"]})
    destination = repo / f"qaoa-b3-full-complete-{datetime.now(timezone.utc):%Y%m%d-%H%M%S}-{uuid4().hex[:6]}.zip"
    saved = create_b3_checkpoint(destination, b1 / "library", root / "config.json", root / "batch", root / "attempts",
                                 root / "summary", path, root=repo, external_root=repo)
    with destination.with_suffix(".zip.sha256").open("x", encoding="ascii") as stream:
        stream.write(saved["archive_sha256"] + "  " + destination.name + "\n")
        stream.flush()
        os.fsync(stream.fileno())
    sync_directory(repo)
    result.update(archive=destination.name, sha256=saved["archive_sha256"], snapshot_id=saved["snapshot_id"])
    atomic_json(root / "checkpoint.json", result)
    sync_directory(root)
    return result


def bind_parent(parent_pid):
    if sys.platform == "linux" and parent_pid:
        import ctypes
        require(ctypes.CDLL(None, use_errno=True).prctl(1, signal.SIGTERM, 0, 0, 0) == 0, "Cannot bind child lifetime.")
        require(os.getppid() == parent_pid, "Supervisor exited; refusing orphan computation.")


def stop_child(child):
    if child.poll() is None:
        child.terminate()
        try:
            child.wait(timeout=20)
        except subprocess.TimeoutExpired:
            child.kill()
            child.wait(timeout=20)


def step(root, repo, stage, graph_id=None):
    if stage == "prepare":
        return prepare(root, repo)
    if stage == "preflight":
        return preflight(root, repo)
    if stage == "work":
        return work_graph(root, repo, graph_id)
    if stage == "summary":
        return summarize(root, repo)
    if stage == "pack":
        return pack(root, repo)
    if stage == "verify":
        meta, _, _ = identity(root, repo)
        check_environment(root, repo)
        from scripts.verify_backend import main as verify
        folder = root / "validation" / uuid4().hex
        folder.mkdir(parents=True)
        require(verify(["--execute", "--backend", meta["backend"], "--sizes", "4", "6", "--depths", "1", "2",
                        "--sample-gpu-memory", "--attempts-dir", str(folder / "attempts"),
                        "--output", str(folder / "report.json")]) == 0, "Small backend verification failed.")
        return {"validation": str(folder.relative_to(root))}
    raise ValueError(stage)


def supervise(root, repo, b1, b2, checkpoint_paths=None):
    with driver_lock(root) as lock:
        session = uuid4().hex
        state = {"session": session, "pid": os.getpid(), "state": "running", "phase": "initialize", "started_utc": now()}
        stopping = False
        if os.name == "posix":
            signal.signal(signal.SIGHUP, signal.SIG_IGN)

        def request_stop(*_):
            nonlocal stopping
            stopping = True

        signal.signal(signal.SIGTERM, request_stop)
        signal.signal(signal.SIGINT, request_stop)

        def update(**values):
            state.update(values, updated_utc=now())
            atomic_json(root / "status.json", state)

        def call(stage, graph_id=None):
            nonlocal stopping
            token = uuid4().hex
            if (root / "stop.json").exists() and read(root / "stop.json").get("session") == session:
                stopping = True
            require(not stopping, "Stop requested.")
            update(phase=stage, graph_id=graph_id, child_pid=None)
            print(f"{now()} {stage} {graph_id or ''}", flush=True)
            args = [sys.executable, "-B", "-u", str(SCRIPT), "_step", "--root", str(root),
                    "--stage", stage, "--token", token, "--parent-pid", str(os.getpid())]
            if graph_id:
                args += ["--graph-id", graph_id]
            options = {"pass_fds": (lock.fileno(),)} if os.name == "posix" else {}
            child = subprocess.Popen(args, cwd=repo, stdin=subprocess.DEVNULL, **options)
            try:
                while child.poll() is None:
                    if (root / "stop.json").exists() and read(root / "stop.json").get("session") == session:
                        stopping = True
                    if stopping:
                        raise InterruptedError("Stopped; completed attempts are retained.")
                    update(child_pid=child.pid)
                    time.sleep(2)
                require(child.returncode == 0, f"{stage} exited {child.returncode}; inspect logs. No automatic retry loop.")
                reply = read(root / "step-result.json")
                require(reply["token"] == token, "Stale child reply.")
                return reply["result"]
            finally:
                stop_child(child)
                update(child_pid=None)

        try:
            update()
            if (root / "checkpoint.json").exists():
                meta, original_b1, original_b2 = identity(root, repo)
                require((b1, b2) == (original_b1, original_b2), "Completed run input paths differ.")
                result = read(root / "checkpoint.json")
                archive = repo / result["archive"]
                require(result["complete"] and file_hash(archive) == result["sha256"], "Completed checkpoint changed/missing.")
                with zipfile.ZipFile(archive) as stream:
                    saved = json.loads(stream.read("snapshot.json"))
                evidence = (root / "summary/evidence/run.json").relative_to(repo).as_posix()
                require(saved["files"][evidence] == file_hash(root / "run.json") and saved["snapshot_id"] == result["snapshot_id"]
                        and result["tasks"] == meta["tasks"], "Checkpoint belongs to another frozen run.")
                update(state="complete", phase="complete", planned=meta["tasks"], valid=meta["tasks"], checkpoint=result)
                return 0
            meta = initialize(root, repo, b1, b2, checkpoint_paths)
            update(planned=meta["tasks"], valid=0)
            check_environment(root, repo)
            subprocess.run([sys.executable, "-m", "pip", "check"], check=True, timeout=60)
            groups = call("prepare")
            require(not any(row["exhausted"] for row in groups.values()), "Fixed execution-fault cap exhausted.")
            update(valid=sum(row["valid"] for row in groups.values()))
            call("preflight")
            call("verify")
            for graph_id, row in sorted(groups.items(), key=lambda item: (item[1]["n"], item[0])):
                if row["valid"] == row["planned"]:
                    continue
                result = call("work", graph_id)
                require(result["missing_tasks"] == result["unresolved_execution_faults"] == 0, "Incomplete graph scope.")
                update(valid=state["valid"] + result["valid_completed"] - row["valid"])
            require(state["valid"] == state["planned"], "Full task count not complete.")
            result = call("pack")
            update(state="complete", phase="complete", checkpoint=result)
            print(json.dumps(result, indent=2), flush=True)
            return 0
        except (Exception, KeyboardInterrupt) as error:
            update(state="paused", reason=f"{type(error).__name__}: {error}")
            traceback.print_exc()
            return 2


def show_status(root):
    data = read(root / "status.json") if (root / "status.json").exists() else {}
    print(json.dumps({"active_lock": locked(root), **data}, indent=2), flush=True)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("start", "status", "stop", "_run", "_step"), metavar="{start,status,stop}")
    parser.add_argument("--root", type=Path, default=Path(DEFAULT_ROOT))
    parser.add_argument("--b1-root", type=Path, default=Path(DEFAULT_B1))
    parser.add_argument("--b2-root", type=Path, default=Path(DEFAULT_B2))
    parser.add_argument("--b1-checkpoint", type=Path)
    parser.add_argument("--b2-checkpoint", type=Path)
    parser.add_argument("--watch", type=float, default=0)
    for option in ("stage", "graph-id", "token"):
        parser.add_argument("--" + option, help=argparse.SUPPRESS)
    parser.add_argument("--parent-pid", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    repo = SCRIPT.parent if (SCRIPT.parent / "qaoa_study/experiments.py").is_file() else Path.cwd().resolve()
    require((repo / "qaoa_study/experiments.py").is_file(), "Upload to qaoa/ and run from there.")
    root, b1, b2 = ((repo / path).resolve() for path in (args.root, args.b1_root, args.b2_root))
    require(all(path.is_relative_to(repo / "data") for path in (root, b1, b2))
            and all(not a.is_relative_to(b) and not b.is_relative_to(a) for a, b in ((root, b1), (root, b2), (b1, b2))),
            "Use separate B1/B2/B3 directories under data/.")
    checkpoint_paths = {role: (repo / path).resolve() for role, path in
                        (("B1", args.b1_checkpoint), ("B2", args.b2_checkpoint)) if path is not None}
    if args.command == "status":
        require(args.watch == 0 or args.watch >= 2, "Watch interval must be at least 2 seconds.")
        while True:
            show_status(root)
            if not args.watch:
                return 0
            time.sleep(args.watch)
    if args.command == "stop":
        if locked(root):
            if not (root / "status.json").exists():
                print("Driver is initializing; repeat stop shortly.")
                return 1
            atomic_json(root / "stop.json", {"session": read(root / "status.json")["session"], "requested_utc": now()})
            print("Stop requested. Check status until active_lock is false.")
        else:
            print("Already stopped.")
        return 0
    root.mkdir(parents=True, exist_ok=True)
    (root / "logs").mkdir(exist_ok=True)
    if args.command == "start":
        require(sys.platform == "linux", "Production start requires the Linux A100 session.")
        if locked(root):
            show_status(root)
            return 0
        command = [sys.executable, "-B", "-u", str(SCRIPT), "_run", "--root", str(root),
                   "--b1-root", str(b1), "--b2-root", str(b2)]
        for role, path in checkpoint_paths.items():
            command += ["--" + role.lower() + "-checkpoint", str(path)]
        with (root / "logs/console.log").open("ab", buffering=0) as log:
            child = subprocess.Popen(command, cwd=repo, stdin=subprocess.DEVNULL, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
        print(f"Launch requested (PID {child.pid}). Preflight status/logs: {root / 'logs/console.log'}")
        return 0
    if args.command == "_step":
        bind_parent(args.parent_pid)
        result = step(root, repo, args.stage, args.graph_id)
        atomic_json(root / "step-result.json", {"token": args.token, "result": result})
        return 0
    return supervise(root, repo, b1, b2, checkpoint_paths)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        raise SystemExit(130)

import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from uuid import uuid4
import zipfile

SCRIPT = Path(__file__).resolve()
REPO = SCRIPT.parents[1]
sys.path.insert(0, str(REPO))
from drivers import run_b3_full as runtime

read, require, file_hash = runtime.read, runtime.require, runtime.file_hash


def atomic_json(path, value):
    for attempt in range(50):
        try:
            return runtime.atomic_json(path, value)
        except PermissionError:
            if os.name != "nt" or attempt == 49:
                raise
            time.sleep(.02)


def resolve(repo, value):
    path = (repo / value).resolve()
    require(path.is_relative_to(repo), "All study paths must stay inside the selected project.")
    return path


def read_exclusion(path):

    from qaoa_study.records import read_library
    if path.name == "generated.json" and path.is_file():
        from qaoa_study.experiments import digest
        saved = read(path)
        require(set(saved) == {"digest", "library"} and digest(saved["library"]) == saved["digest"],
                "Excluded generated.json checksum differs from its frozen graph draws.")
        return saved["library"]
    return read_library(path)


def initialize(repo, root, inputs_path, backend, development=False, graph_config=None):
    exp = runtime.setup(repo)
    from scripts.build_library import matched_ws_rgg_config
    inputs = read(inputs_path)
    require(set(inputs) == {"b1_batch", "b2_fits", "b4_fits", "b5_fits"}, "Unexpected input fields.")
    paths = {key: resolve(repo, value) for key, value in inputs.items() if key != "b2_fits"}
    fits = [resolve(repo, path) for path in inputs["b2_fits"]]
    baseline, original, _ = exp.read_batch(paths["b1_batch"])
    library_path = (paths["b1_batch"] / baseline["library_path"]).resolve()
    require(not baseline["issues"], "Original B1 batch has unresolved design issues.")
    require((backend == "default.qubit") if development else (sys.platform == "linux" and backend == "lightning.gpu"),
            "Full execution uses Linux/lightning.gpu; development checks use default.qubit.")
    require(development or (baseline["config"]["evaluation_restarts"] == 50 and
            baseline["config"]["reference"]["p2_restarts"] == 100), "Full run requires the original 50/100 pools.")
    require(graph_config is None or root != repo / "data/manual/new-families-full-v1",
            "A revised graph configuration requires a distinct --root; retain the original run directory.")
    config = read(graph_config) if graph_config else matched_ws_rgg_config(original)
    from qaoa_study.graphs import _generation_cells
    cells = _generation_cells(config)
    require({cell["n"] for cell in cells} <= set(config["exact_sizes"]),
            "Every evaluation size requires exact MaxCut annotation.")
    quota = config["quota_per_cell"]
    quantities = [quota[str(cell["n"])] if isinstance(quota, dict) else quota for cell in cells]
    require(all(type(count) is int and count > 0 for count in quantities)
            and config["training_count"] == 0 and config["tier2_count"] == sum(quantities)
            and config.get("require_excluded_library") is True,
            "New graph batches require positive cell quotas, original-library exclusion and evaluation-only coverage.")
    additional = config.get("additional_excluded_libraries", [])
    require(isinstance(additional, list) and all(isinstance(path, str) and not Path(path).is_absolute()
            and "\\" not in path and ":" not in path for path in additional),
            "additional_excluded_libraries must list repository-relative library paths.")
    exclusions = [resolve(repo, path) for path in additional]
    require(len({library_path, *exclusions}) == 1 + len(exclusions),
            "Excluded library paths must be distinct from one another and the original library.")
    for path in exclusions:
        read_exclusion(path)
    files = [inputs_path, paths["b1_batch"] / "manifest.json", library_path / "manifest.json", *fits,
             paths["b4_fits"] / "manifest.json", paths["b5_fits"] / "manifest.json",
             *(path if path.is_file() else path / "manifest.json" for path in exclusions)]
    if graph_config:
        files.append(graph_config)
    protected = [library_path, *exclusions, *paths.values(), *fits, inputs_path]
    require(root != repo and all(not root.is_relative_to(p) and not p.is_relative_to(root) for p in protected),
            "Output overlaps existing study inputs.")
    environment = exp.environment(backend)
    environment.pop("device_identity")
    require(not environment.get("gpu") or not environment["gpu"]["unknown"], "GPU environment is not fully identified.")
    return {"format": "new-family-driver-v1", "inputs": inputs, "graph_config": config,
            "backend": backend, "development": development, "environment": environment,
            "source": exp.source_identity(repo), "original_library": library_path.relative_to(repo).as_posix(),
            "input_hashes": {p.relative_to(repo).as_posix(): file_hash(p) for p in files},
            "support_hashes": {p.relative_to(repo).as_posix(): file_hash(p) for p in (SCRIPT, Path(runtime.__file__))}}


def identity(root, repo):
    exp, meta = runtime.setup(repo), read(root / "run.json")
    require(exp.source_identity(repo) == meta["source"], "Frozen working source changed.")
    require(all(file_hash(repo / path) == value for path, value in meta["support_hashes"].items()), "Driver changed.")
    require(all(file_hash(repo / path) == value for path, value in meta["input_hashes"].items()), "Frozen input files changed.")
    current = exp.environment(meta["backend"])
    current.pop("device_identity")
    require(current == meta["environment"], "Numerical environment changed.")
    return meta, exp


def generate(root, repo):

    meta, exp = identity(root, repo)
    from qaoa_study.graphs import generate_library
    from qaoa_study.records import write_once_json
    config = meta["graph_config"]
    raw_path = root / "generated.json"
    if not raw_path.exists():
        excluded = [meta["original_library"], *config.get("additional_excluded_libraries", [])]
        raw = generate_library(config, excluded_libraries=[read_exclusion(resolve(repo, path)) for path in excluded])
        write_once_json(raw_path, {"digest": exp.digest(raw), "library": raw})
    saved = read(raw_path)
    raw = saved["library"]
    require(exp.digest(raw) == saved["digest"] and raw["config"] == config, "Generated graph inputs changed.")
    rows = []
    for cell in raw["cells"]:
        degrees = [2 * len(graph["edges"]) / graph["n"] for graph in raw["graphs"]
                   if graph["representative_cell"] == cell["cell_id"]]
        row = {key: cell[key] for key in ("cell_id", "n", "family", "target_degree", "generation_group", "quota",
               "accepted", "shortfall", "attempts", "rejected_disconnected", "duplicates", "generator_errors") if key in cell}
        row.update(mean_degree=sum(degrees) / len(degrees) if degrees else None,
                   min_mean_degree=min(degrees, default=None), max_mean_degree=max(degrees, default=None))
        rows.append(row)
    summary = {"scope": "graph_generation_only", "library_id": raw["library_id"], "graphs": len(raw["graphs"]), "cells": rows}
    path = root / "graph-summary.json"
    if path.exists():
        require(read(path) == summary, "Saved graph coverage differs from frozen draws.")
    else:
        write_once_json(path, summary)
    shortfalls = {cell["cell_id"]: cell["shortfall"] for cell in raw["cells"] if cell["shortfall"]}
    require(not shortfalls, f"Frozen graph generation has unfilled quotas: {shortfalls}. Retain this version and revise the design in a new run directory.")
    return raw


def prepare(root, repo):
    meta, exp = identity(root, repo)
    from qaoa_study.records import annotate_library, read_library, save_library, write_once_json
    config = meta["graph_config"]
    if not (root / "library").exists():
        raw = generate(root, repo)
        annotated = []
        for graph in raw["graphs"]:
            path = root / "annotations" / (exp.digest(graph["iso_class_id"]) + ".json")
            if not path.exists():

                one = annotate_library({"graphs": [graph]}, config["exact_sizes"], config["exact_chunk_size"])
                record = {"input_digest": exp.digest(graph), "graph": one["graphs"][0]}
                write_once_json(path, {**record, "digest": exp.digest(record)})
            record = read(path)
            require(record["input_digest"] == exp.digest(graph) and record["digest"] == exp.digest(
                {k: v for k, v in record.items() if k != "digest"}), "Saved exact annotation changed.")
            annotated.append(record["graph"])
        library = {**raw, "graphs": annotated, "annotations": {"exact_sizes": config["exact_sizes"],
                   "exact_chunk_size": config["exact_chunk_size"], "feature_version": annotated[0]["feature_version"]}}
        runtime.staged(root, "library", lambda path: save_library(path, library), read_library)
    inputs = meta["inputs"]
    manifest = runtime.staged(root, "batch", lambda path: exp.prepare_transfer_batch(path,
        repo / inputs["b1_batch"], root / "library", [repo / p for p in inputs["b2_fits"]],
        repo / inputs["b4_fits"], repo / inputs["b5_fits"]), lambda path: exp.read_batch(path)[0])
    require(not manifest["issues"], f"Incomplete plan: {manifest['issues']}")
    _, _, tasks = exp.read_batch(root / "batch")
    groups = exp._task_groups(tasks)
    progress = {exp.digest([group[0]["iso_class_id"], group[0]["experiment_role"]]): len(group) for group in groups.values()}
    if not (root / "progress-index.json").exists():
        write_once_json(root / "progress-index.json", {"planned": len(tasks), "groups": progress})
    return {"planned": len(tasks), "graphs": len({t["iso_class_id"] for t in tasks}), "counts": manifest["counts"]}


def summarize(root, repo):
    meta, exp = identity(root, repo)
    from qaoa_study import analysis as analysis
    from qaoa_study.records import evaluate_trace, write_once_json
    manifest, library, tasks = exp.read_batch(root / "batch")
    graphs = {g["iso_class_id"]: g for g in library["graphs"]}
    refs, selected, costs, reference_costs = {}, {}, [], []
    buffered, current = [], None

    def collect():
        if not buffered:
            return
        planned = [t for group, _ in buffered for t in group]
        chosen = exp.select_attempts([a for _, rows in buffered for a in rows])
        references = exp.freeze_references(manifest, planned, chosen)
        refs.update(references)
        for task in planned:
            attempt = chosen.get(task["task_id"])
            if attempt is None:
                continue
            if task["experiment_role"] == "reference":
                reference_costs.append({k: v for k, v in attempt.items() if k in (
                    "task_id", "attempt_id", "kind", "counts", "elapsed_seconds", "preparation_seconds", "grid", "cost_status", "cost_unavailable")})
                continue
            trace = attempt.get("trace", [])
            reference = references[task["iso_class_id"], task["p"]]
            hit = evaluate_trace(attempt, reference["C_ref"], C_star=graphs[task["iso_class_id"]]["C_star"],
                                 metric=manifest["config"]["success_metric"])["first_hit"] if reference["complete"] else None
            keep = {trace[0]["call_id"], hit, attempt.get("best_call_id")} if trace else set()
            selected[task["task_id"]] = {k: v for k, v in attempt.items() if k not in ("trace", "initial_gradient", "final_gradient")}
            selected[task["task_id"]]["trace"] = [row for row in trace if row["call_id"] in keep]

    for planned, attempts, _ in exp.iter_attempt_groups(manifest, tasks, root / "attempts"):
        graph_id = planned[0]["iso_class_id"]
        if current is not None and graph_id != current:
            collect()
            buffered.clear()
        current = graph_id
        buffered.append((planned, attempts))
        costs.extend({k: v for k, v in row.items() if k in (
            "task_id", "attempt_id", "kind", "counts", "elapsed_seconds", "preparation_seconds", "grid", "cost_status", "cost_unavailable")}
                     for row in attempts)
    collect()
    settings = {"success_metric": manifest["config"]["success_metric"],
                "evaluation_restarts": manifest["config"]["evaluation_restarts"], "bootstrap_seed": 20261006,
                "bootstrap_samples": 2000}
    scientific_tasks = [t for t in tasks if t["experiment_role"] != "reference"]
    summary = analysis.build_transfer_summary(library, scientific_tasks, selected, refs, settings=settings)
    summary["planned_quantum_tasks_including_references"] = len(tasks)
    summary["selected_reference_costs"] = analysis._costs(reference_costs)
    summary["all_attempt_costs"] = analysis._costs(costs)
    summary["all_attempt_costs"]["attempts"] = len(costs)
    summary["source_id"] = manifest["source_id"]
    require(summary["complete"], "Incomplete results; complete attempts remain available for continuation.")
    if not (root / "references").exists():
        runtime.staged(root, "references", lambda path: exp.save_references(path, refs), exp.read_references)
    require(exp.read_references(root / "references") == refs, "Frozen scoring references changed.")
    path = root / "summary.json"
    if path.exists():
        require(read(path) == summary, "Stored summary differs from verified records.")
    else:
        write_once_json(path, summary)
    return {"complete": True, "graphs": len(graphs), "tasks": len(tasks), "summary": str(path.relative_to(repo))}


def pack(root, repo):
    meta, exp = identity(root, repo)
    from scripts.snapshot import _publish
    from qaoa_study.records import write_once_json
    receipt = root / "complete.json"
    if receipt.exists():
        saved = read(receipt)
        require(file_hash(root / "new-graphs-complete.zip") == saved["archive_sha256"], "Result archive changed.")
        return saved
    result = summarize(root, repo)
    payload = {p.relative_to(repo).as_posix(): p for p in exp.runtime_files(repo)}
    for directory in ("library", "batch", "attempts", "references", "validation"):
        for path in (root / directory).rglob("*"):
            if path.is_file() and path.name != "writer.lock":
                require(not path.is_symlink(), "Do not archive linked inputs.")
                payload[path.relative_to(repo).as_posix()] = path
    for path in (root / "run.json", root / "summary.json", SCRIPT, Path(runtime.__file__)):
        payload[path.relative_to(repo).as_posix()] = path
    if (root / "graph-summary.json").exists():
        payload[(root / "graph-summary.json").relative_to(repo).as_posix()] = root / "graph-summary.json"
    manifest = {"format": "new-family-results-v1", "source_id": meta["source"]["source_id"],
        "source_files": meta["source"]["files"], "library_id": read(root / "batch/manifest.json")["library_id"],
        "run_root": root.relative_to(repo).as_posix(), "external_model_inputs": meta["inputs"],
        "files": {name: file_hash(path) for name, path in payload.items()}, **result}
    manifest["snapshot_id"] = exp.digest(manifest)
    archive = root / "new-graphs-complete.zip"
    if archive.exists():
        with zipfile.ZipFile(archive) as stream:
            require(json.loads(stream.read("snapshot.json")) == manifest, "Existing archive belongs to another result.")
            require(all(hashlib.sha256(stream.read(name)).hexdigest() == sha for name, sha in manifest["files"].items()),
                    "Existing archive payload changed.")
        saved = {"archive_sha256": file_hash(archive), "snapshot_id": manifest["snapshot_id"], **result}
    else:
        saved = {**_publish(archive, payload, manifest, validate_inventory=lambda: identity(root, repo)), **result}
    write_once_json(receipt, saved)
    return saved


def step(root, repo, stage):
    meta, exp = identity(root, repo)
    if stage == "prepare":
        return prepare(root, repo)
    if stage == "verify":
        from scripts.verify_backend import main as verify
        folder = root / "validation" / uuid4().hex
        folder.mkdir(parents=True)
        require(verify(["--execute", "--backend", meta["backend"], "--sizes", "4", "6", "--depths", "1", "2",
                        "--output", str(folder / "report.json"), "--attempts-dir", str(folder / "attempts")]) == 0,
                "Backend verification failed.")
        return {"verified": True}
    if stage == "work":
        result = exp.run_worker(root / "batch", root / "attempts", backend=meta["backend"], execute=True, partitioned=True)
        require(result["missing_tasks"] == result["unresolved_execution_faults"] == 0, "Some tasks need attention; inspect retained attempts.")
        return result
    if stage == "pack":
        return pack(root, repo)
    raise ValueError(stage)


def status(root):
    state = read(root / "status.json") if (root / "status.json").exists() else {"state": "not_started"}
    if (root / "progress-index.json").exists():
        progress = read(root / "progress-index.json")
        sealed = {p.stem for p in (root / "attempts/sealed").glob("*.tgz")}
        count = sum(n for key, n in progress["groups"].items() if key in sealed)
        state.update(planned=progress["planned"], sealed_completed=count,
                     remaining_unsealed=progress["planned"] - count,
                     count_scope="sealed complete groups; active partial attempts are retained but not included here")
    state["active_lock"] = runtime.locked(root)
    if not state["active_lock"] and state.get("state") == "running":
        state["state"] = "stopped"
    return state


def supervise(root, repo):
    with runtime.driver_lock(root) as lock:
        state = {"session": uuid4().hex, "pid": os.getpid(), "state": "running"}
        stopping = False
        def request_stop(*_):
            nonlocal stopping
            stopping = True
        signal.signal(signal.SIGTERM, request_stop)
        signal.signal(signal.SIGINT, request_stop)
        if os.name == "posix":
            signal.signal(signal.SIGHUP, signal.SIG_IGN)
        def update(**values):
            state.update(values, updated_utc=runtime.now())
            atomic_json(root / "status.json", state)
        try:
            identity(root, repo)
            if (root / "complete.json").exists():
                result = pack(root, repo)
            else:
                stages = ("pack",) if (root / "summary.json").exists() else ("prepare", "verify", "work", "pack")
                for stage in stages:
                    update(phase=stage, child_pid=None)
                    token = uuid4().hex
                    command = [sys.executable, "-B", "-u", str(SCRIPT), "_step", "--repo", str(repo), "--root", str(root),
                               "--stage", stage, "--token", token, "--parent-pid", str(os.getpid())]
                    child = subprocess.Popen(command, cwd=repo, stdin=subprocess.DEVNULL,
                        **({"pass_fds": (lock.fileno(),)} if os.name == "posix" else {}))
                    try:
                        while child.poll() is None:
                            stop = read(root / "stop.json") if (root / "stop.json").exists() else {}
                            if stopping or stop.get("session") == state["session"]:
                                raise InterruptedError("Stopped; completed attempts and graph annotations are retained.")
                            update(child_pid=child.pid)
                            time.sleep(1)
                        require(child.returncode == 0, f"{stage} exited {child.returncode}; see logs/console.log.")
                        reply = read(root / "step-result.json")
                        require(reply["token"] == token, "Stale child result.")
                        result = reply["result"]
                    finally:
                        runtime.stop_child(child)
            update(state="complete", phase="complete", child_pid=None, result=result)
            return 0
        except (Exception, KeyboardInterrupt) as error:
            update(state="paused", child_pid=None, reason=f"{type(error).__name__}: {error}")
            print(state["reason"], file=sys.stderr, flush=True)
            return 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("check", "graphs", "start", "status", "stop", "pack", "_run", "_step"))
    parser.add_argument("--repo", type=Path, default=REPO)
    parser.add_argument("--root", type=Path, default=Path("data/manual/new-families-full-v1"))
    parser.add_argument("--inputs", type=Path, default=Path("drivers/new-graphs-inputs.json"))
    parser.add_argument("--backend", choices=("default.qubit", "lightning.gpu"), default="lightning.gpu")
    parser.add_argument("--development", action="store_true")
    parser.add_argument("--graph-config", type=Path,
                        help="Adopted graph-generation JSON; requires a distinct --root.")
    parser.add_argument("--watch", type=float, default=0)
    parser.add_argument("--foreground", action="store_true")
    for name in ("stage", "token", "parent-pid"):
        parser.add_argument("--" + name, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    repo = args.repo.resolve()
    root = resolve(repo, args.root)
    require(root.is_relative_to(repo / "data"), "Use a dedicated output beneath data/.")
    if args.command == "status":
        require(args.watch == 0 or args.watch >= 2, "Watch interval must be at least two seconds.")
        while True:
            print(json.dumps(status(root), indent=2), flush=True)
            if not args.watch:
                return 0
            time.sleep(args.watch)
    if args.command == "stop":
        if runtime.locked(root):
            atomic_json(root / "stop.json", {"session": read(root / "status.json")["session"]})
        return 0
    if args.command == "_step":
        runtime.bind_parent(int(args.parent_pid))
        atomic_json(root / "step-result.json", {"token": args.token, "result": step(root, repo, args.stage)})
        return 0
    if args.command == "_run":
        return supervise(root, repo)
    if args.command == "pack":
        with runtime.driver_lock(root):
            print(json.dumps(pack(root, repo), indent=2))
        return 0
    meta = initialize(repo, root, resolve(repo, args.inputs), args.backend, args.development,
                      resolve(repo, args.graph_config) if args.graph_config else None)
    if args.command == "check":
        print(json.dumps({"checked": True, "graph_config": meta["graph_config"], "inputs": meta["inputs"]}, indent=2))
        return 0
    root.mkdir(parents=True, exist_ok=True)
    if runtime.locked(root):
        print(json.dumps(status(root), indent=2))
        return 0
    from qaoa_study.records import write_once_json
    with runtime.driver_lock(root):
        if (root / "run.json").exists():
            require(read(root / "run.json") == meta, "Frozen inputs/settings changed; keep the original run setup.")
        else:
            require(all(p.name == "driver.lock" for p in root.iterdir()), "Use an empty output directory.")
            write_once_json(root / "run.json", meta)
        if args.command == "graphs":
            generate(root, repo)
            print(json.dumps(read(root / "graph-summary.json"), indent=2))
            return 0
        (root / "logs").mkdir(exist_ok=True)
    if args.foreground:
        return supervise(root, repo)
    command = [sys.executable, "-B", "-u", str(SCRIPT), "_run", "--repo", str(repo), "--root", str(root)]
    with (root / "logs/console.log").open("ab", buffering=0) as log:
        child = subprocess.Popen(command, cwd=repo, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            **({"start_new_session": True} if os.name == "posix" else {"creationflags": subprocess.CREATE_NO_WINDOW}))
    print(json.dumps({"launch_requested": True, "pid": child.pid, "log": str(root / "logs/console.log")}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError) as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(2)
    except KeyboardInterrupt:
        raise SystemExit(130)

import argparse
from contextlib import ExitStack
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
from uuid import uuid4
import zipfile

SCRIPT = Path(__file__).resolve()
sys.path.insert(0, str(SCRIPT.parents[1]))
from drivers import run_b3_full as runtime
from qaoa_study.experiments import _writer_lock, digest
from scripts.snapshot import _payload_path, _publish

read, require, file_hash = runtime.read, runtime.require, runtime.file_hash
NAMES = ("new-families-full-v1", "size-ws-v2", "size-rgg35-v2", "size-rgg35-v2-platform-tail-v1")


def export(repo):

    repo = Path(repo).resolve()
    old, ws, rgg, tail = roots = [repo / "data/manual" / name for name in NAMES]
    control = repo / "data/manual/size-revision-launcher-v1"
    payload = {}

    def add(path, expected=None):
        name = path.relative_to(repo).as_posix()
        path = _payload_path(repo, name)
        require(path.is_file(), f"Missing export input: {name}")
        require(not any(p.is_symlink() for p in (path, *path.parents) if p.is_relative_to(repo)),
                f"Linked export input: {name}")
        require(expected is None or file_hash(path) == expected, f"Frozen input changed: {name}")
        payload[name] = path

    def tree(path):
        require(path.is_dir() and not path.is_symlink(), f"Missing or linked directory: {path}")
        for item in sorted(path.rglob("*")):
            require(not item.is_symlink(), f"Linked export input: {item}")
            if item.is_file() and item.name != "writer.lock":
                require(item.suffix != ".zip", f"Unexpected nested ZIP in scientific data: {item}")
                add(item)

    with ExitStack() as guards:
        for root in (control, *roots):
            _payload_path(repo, root.relative_to(repo).as_posix())
            require(root.is_dir() and (root / "driver.lock").is_file(), f"Missing run: {root}")
            guards.enter_context(runtime.driver_lock(root))
        for root in roots:
            require((root / "attempts/manifest.json").is_file(), f"Missing attempts: {root}")
            guards.enter_context(_writer_lock(root / "attempts"))
        old_meta, ws_meta, rgg_meta = [read(root / "run.json") for root in (old, ws, rgg)]
        index = read(control / "old-ws-progress-index.json")
        old_done = read(control / "old-ws-complete.json")
        ws_done, tail_done = [read(root / "complete.json") for root in (ws, tail)]
        ws_summary, summary = [read(root / "summary.json") for root in (ws, tail)]
        plan = read(tail / "plan.json")
        require(index["planned"] == sum(index["groups"].values()) == 66442 and len(set(index["graph_ids"])) == 278,
                "Old WS selection must contain 278 graphs and 66442 tasks.")
        result = old_done["result"]
        require(result["completed"] == result["valid_completed"] == 66442 and
                result["missing_tasks"] == result["unresolved_execution_faults"] == 0 and
                old_done["source_id"] == index["source_id"] == old_meta["source"]["source_id"], "Old WS is incomplete.")
        require(ws_done["complete"] is True and ws_done["graphs"] == 284 and ws_done["tasks"] == 67876 and
                ws_summary["complete"] is True and ws_summary["planned_quantum_tasks_including_references"] == 67876,
                "New WS completion differs from the adopted scope.")
        require(tail_done["complete"] is True and tail_done["graphs"] == 562 and tail_done["tasks"] == 134318 and
                summary["complete"] is True and summary["planned_quantum_tasks_including_references"] == 134318 and
                tail_done["summary_digest"] == digest(summary) and tail_done["plan_id"] == plan["plan_id"] and
                plan["plan_id"] == digest({k: v for k, v in plan.items() if k != "plan_id"}) and
                plan["parent"] == rgg.relative_to(repo).as_posix(), "RGG union completion differs from its frozen plan.")
        require(ws_meta["source"] == rgg_meta["source"] == plan["source"] and
                ws_summary["source_id"] == summary["source_id"] == plan["source"]["source_id"], "Frozen source identities differ.")
        continuation = summary["platform_continuation"]
        require(plan["parent_total"] == plan["parent_valid"] + plan["planned"] == 134318 and
                all(continuation[key] == plan[key] for key in ("plan_id", "parent", "parent_environment")) and
                continuation["supplement_environment"] == plan["environment"], "RGG summary provenance differs.")
        verification = read(tail / "verification.json")
        report_path = _payload_path(tail, verification["report"])
        report = read(report_path)
        require(verification["plan_id"] == plan["plan_id"] and file_hash(report_path) == verification["sha256"] and
                report["status"] == "completed" and report["source"] == plan["source"] and
                {k: v for k, v in report["environment"].items() if k != "device_identity"} == plan["environment"],
                "Tail backend verification differs from its frozen plan.")
        for name, sha in {**plan["parent_hashes"], **plan["parent_active_files"]}.items():
            add(rgg / name, sha)
        require(sorted(p.name for p in (rgg / "attempts/sealed").glob("*.tgz")) == plan["parent_sealed_names"],
                "Original RGG sealed inventory changed after the tail plan.")
        active = {(p.relative_to(rgg).as_posix()): file_hash(p) for group in plan["unsealed_groups"]
                  for p in (rgg / "attempts/active" / group).glob("*") if p.is_file()}
        require(active == plan["parent_active_files"], "Original RGG active inventory changed after the tail plan.")
        for root in (old, ws, rgg):
            for directory in ("library", "batch"):
                tree(root / directory)
            add(root / "run.json")
        add(old / "attempts/manifest.json")
        for group in index["groups"]:
            require(len(group) == 64 and all(c in "0123456789abcdef" for c in group), "Invalid old-WS group ID.")
            add(old / "attempts/sealed" / (group + ".tgz"))
            if (old / "attempts/active" / group).exists():
                tree(old / "attempts/active" / group)
        for name in ("old-ws-progress-index.json", "old-ws-complete.json"):
            add(control / name)
        for root in (ws, rgg, tail):
            for directory in ("attempts", "validation"):
                tree(root / directory)
        for root in (ws, tail):
            tree(root / "references")
            for name in ("summary.json", "complete.json"):
                add(root / name)
        for root in (ws, rgg):
            for name in ("progress-index.json", "graph-summary.json"):
                add(root / name)
        for name in ("plan.json", "verification.json"):
            add(tail / name)
        for meta in (ws_meta, rgg_meta):
            for name, sha in {**meta["source"]["files"], **meta["support_hashes"]}.items():
                add(repo / name, sha)
        add(repo / "drivers/run_rgg_platform_tail.py", plan["helper_sha256"])
        add(repo / "drivers/run_size_revision.py", plan["launcher_sha256"])
        add(repo / "drivers/export_ws_rgg_results.py", file_hash(SCRIPT))
        expected = {**old_meta["source"]["files"], **old_meta["support_hashes"],
                    "_provenance/run.json": file_hash(old / "run.json")}
        with zipfile.ZipFile(_payload_path(repo, (old / "frozen-source.zip").relative_to(repo).as_posix())) as archive:
            preservation = json.loads(archive.read("source-preservation.json"))
            require(set(archive.namelist()) == {*expected, "source-preservation.json"} and
                    len(archive.namelist()) == len(expected) + 1 and preservation["files"] == expected and
                    preservation["source_id"] == old_meta["source"]["source_id"], "Old source inventory differs.")
            for name in archive.namelist():
                _payload_path(repo, name)
                value = archive.read(name)
                require(name not in expected or hashlib.sha256(value).hexdigest() == expected[name], "Old source checksum differs.")
                payload["reproduction/old-ws/" + name] = value
        print(f"Collected {len(payload)} files; hashing the export inputs...", flush=True)
        manifest = {"format": "ws-rgg-analysis-export-v1", "source_id": None, "library_id": None,
                    "created_utc": datetime.now(timezone.utc).isoformat(),
                    "scope": {"old_ws": {"graphs": 278, "tasks": 66442}, "new_ws": {"graphs": 284, "tasks": 67876},
                              "rgg_union": {"graphs": 562, "tasks": 134318, "plan_id": plan["plan_id"]}},
                    "source_ids": {root.name: meta["source"]["source_id"] for root, meta in zip((old, ws, rgg), (old_meta, ws_meta, rgg_meta))},
                    "external_inputs": {root.name: meta["inputs"] for root, meta in zip((old, ws, rgg), (old_meta, ws_meta, rgg_meta))},
                    "notes": ["Old WS uses only the indexed graph groups; its full frozen library and batch remain intact.",
                              "RGG completion is the original plus supplement union; original completion is not changed.",
                              "Model inputs remain external; frozen batch/transfer.json retains the executed starts.",
                              "Existing result ZIPs are omitted; new WS scientific contents are included directly.",
                              "Export verifies receipts and file hashes, not a fresh scientific reanalysis."],
                    "files": {name: file_hash(value) if isinstance(value, Path) else hashlib.sha256(value).hexdigest()
                              for name, value in sorted(payload.items())}}
        manifest["snapshot_id"] = digest(manifest)
        output = repo / (datetime.now(timezone.utc).strftime("ws-rgg-results-%Y%m%d-%H%M%S-") + uuid4().hex[:6] + ".zip")
        print(f"Writing and verifying {output.name}...", flush=True)
        return {"archive": str(output), **_publish(output, payload, manifest)}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", type=Path, default=SCRIPT.parents[1])
    args = parser.parse_args()
    try:
        print(json.dumps(export(args.repo), indent=2))
    except (KeyError, ValueError, OSError, RuntimeError, zipfile.BadZipFile) as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(2)

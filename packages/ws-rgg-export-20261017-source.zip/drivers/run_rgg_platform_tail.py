import argparse
from collections import Counter
from contextlib import nullcontext
from itertools import groupby
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from uuid import uuid4

SCRIPT = Path(__file__).resolve()
REPO = SCRIPT.parents[1]
sys.path.insert(0, str(REPO))
from drivers import run_b3_full as runtime
from drivers.run_new_graphs_full import atomic_json
from drivers.run_size_revision import worker_locked

read, require, file_hash = runtime.read, runtime.require, runtime.file_hash
DEFAULT_PARENT = "data/manual/size-rgg35-v2"
DEFAULT_ROOT = "data/manual/size-rgg35-v2-platform-tail-v1"
_OWNED_PARENT_LOCK = None


def _parent_state(parent, repo, development):
    exp = runtime.setup(repo)
    require((_OWNED_PARENT_LOCK == parent or not runtime.locked(parent)) and not worker_locked(parent),
            "Stop the original RGG driver and worker first.")
    meta = read(parent / "run.json")
    backend = "default.qubit" if development else "lightning.gpu"
    require(meta["backend"] == backend and (development or sys.platform == "linux"), "Backend/platform differs from this continuation.")
    require(exp.source_identity(repo) == meta["source"], "Frozen working source changed.")
    for category in ("input_hashes", "support_hashes"):
        require(all(file_hash(repo / name) == sha for name, sha in meta[category].items()), f"Frozen {category} changed.")
    current = exp.environment(backend)
    current.pop("device_identity")
    require(not current.get("gpu") or not current["gpu"]["unknown"], "GPU environment is not identified.")
    require({k: v for k, v in current.items() if k != "platform"} ==
            {k: v for k, v in meta["environment"].items() if k != "platform"},
            "Only the recorded platform difference is allowed; another environment field changed.")
    if not development:
        old_platform, new_platform = meta["environment"]["platform"], current["platform"]
        require(old_platform.endswith("with-glibc2.39") and new_platform.endswith("with-glibc2.43") and
                old_platform.removesuffix("2.39") == new_platform.removesuffix("2.43"),
                "This continuation permits only the observed glibc 2.39 to 2.43 change on the same platform.")
    manifest, library, tasks = exp.read_batch(parent / "batch")
    require(manifest["config"].get("kind") == "transfer" and not manifest["issues"], "A valid frozen transfer batch is required.")
    if not development:
        require(len(tasks) == 134318 and len(library["graphs"]) == 562 and all(
            "rgg" in graph["families"] and graph["n"] in (12, 14, 16, 18, 20, 22) for graph in library["graphs"]),
            "Production continuation is restricted to the existing 562-graph RGG batch.")
    execution = read(parent / "attempts/manifest.json")
    exp._validate_execution(manifest, execution)
    require(execution["environment"] == meta["environment"] and execution.get("storage_layout") == exp.PARTITIONED_LAYOUT,
            "Parent execution environment/layout differs from its frozen driver.")
    return exp, meta, current, manifest, library, tasks, execution


def _draft(parent, root, repo, development):
    exp, meta, current, manifest, library, tasks, execution = _parent_state(parent, repo, development)
    groups = exp._task_groups(tasks)
    directory = exp._record_directory(parent / "attempts")
    sealed = sorted(p.name for p in (directory / "sealed").glob("*.tgz"))
    expected = {exp.digest(list(key)): group for key, group in groups.items()}
    index = read(parent / "progress-index.json")
    require(index == {"planned": len(tasks), "groups": {key: len(group) for key, group in expected.items()}},
            "Parent progress index differs from the frozen tasks.")
    exp._check_partition_paths(directory, groups)
    pending = {key: group for key, group in expected.items() if key + ".tgz" not in sealed}
    require(development or sum(len(group) for group in pending.values()) <= 856,
            "The unsealed scope exceeds the observed 856 tasks; inspect the original records first.")
    old, inventory, started = [], {}, set()
    for key, group in pending.items():
        audit = {}
        old.extend(exp._load_scope(manifest, execution, group, directory, metadata_only=True, audit=audit))
        inventory.update({"attempts/active/" + key + "/" + p.name: file_hash(p)
                          for p in (directory / "active" / key).glob("*") if p.is_file()})
        started.update(audit.get("started_attempt_ids", []))
    selected, counts = exp.select_attempts(old), Counter(row["task_id"] for row in old)
    missing = [task for group in pending.values() for task in group
               if task["task_id"] not in selected or exp.execution_failed(selected[task["task_id"]])]
    require(all(counts[task["task_id"]] < manifest["config"]["max_attempts"] for task in missing),
            "An old execution fault exhausted its attempt cap; retain it for review, do not reset retries.")
    plan = {"format": "rgg-platform-tail-v1", "parent": parent.relative_to(repo).as_posix(),
            "development": development, "backend": meta["backend"], "environment": current,
            "parent_environment": meta["environment"], "source": meta["source"],
            "helper_sha256": file_hash(SCRIPT), "launcher_sha256": file_hash(repo / "drivers/run_size_revision.py"),
            "parent_total": len(tasks),
            "parent_valid": len(tasks) - len(missing), "planned": len(missing),
            "task_ids": sorted(task["task_id"] for task in missing), "unsealed_groups": sorted(pending),
            "old_attempt_digests": {row["attempt_id"]: exp.digest(row) for row in old},
            "parent_hashes": {name: file_hash(parent / name) for name in
                ("run.json", "batch/manifest.json", "attempts/manifest.json", "progress-index.json")},
            "parent_active_files": inventory, "parent_sealed_names": sealed,
            "orphan_start_receipts": sorted(started - {row["attempt_id"] for row in old}),
            "orphan_cost_scope": "Interrupted attempts have unknown work; their original receipts are retained."}
    plan["plan_id"] = exp.digest(plan)
    return plan, exp, manifest, library, tasks, old


def prepare(parent, root, repo, *, development=False):

    parent, root, repo = Path(parent).resolve(), Path(root).resolve(), Path(repo).resolve()
    require(parent.is_relative_to(repo / "data") and root.is_relative_to(repo / "data") and
            not root.is_relative_to(parent) and not parent.is_relative_to(root), "Use distinct data directories inside this project.")
    plan, exp, *_ = _draft(parent, root, repo, development)
    root.mkdir(parents=True, exist_ok=True)
    from qaoa_study.records import write_once_json
    if (root / "plan.json").exists():
        require(read(root / "plan.json") == plan, "Frozen continuation inputs, records, helper or environment changed.")
    else:
        require(all(p.name in {"driver.lock", "logs", "status.json", "stop.json"} for p in root.iterdir()), "Use an empty continuation directory.")
        write_once_json(root / "plan.json", plan)
    return plan


def _load(root, repo):
    plan = read(root / "plan.json")
    fresh, exp, manifest, library, tasks, old = _draft(repo / plan["parent"], root, repo, plan["development"])
    require(fresh == plan, "Frozen continuation inputs, records, helper or environment changed.")
    return plan, exp, manifest, library, tasks, old


def _execution(plan, manifest, exp):
    value = {"batch_id": manifest["batch_id"], "source": plan["source"], "environment": plan["environment"],
             "protocol_version": manifest["config"]["protocol_version"], "config": manifest["config"],
             "attempt_selection_rule": exp.ATTEMPT_RULE}
    return {**value, "execution_id": exp.digest(value)}


def _check_attempts(rows, cap, exp):
    require(len({r["attempt_id"] for r in rows}) == len(rows), "Duplicate cross-environment attempt identity.")
    for task_id, grouped in groupby(sorted(rows, key=lambda r: r["task_id"]), key=lambda r: r["task_id"]):
        ordered = sorted(grouped, key=lambda r: r["attempt_number"])
        require([r["attempt_number"] for r in ordered] == list(range(1, len(ordered) + 1)) and len(ordered) <= cap,
                f"Attempt sequence/cap changed for {task_id}.")
        require(all(exp.execution_failed(row) for row in ordered[:-1]), "An attempt followed an already valid result.")


def _verified(root, plan):
    receipt = read(root / "verification.json")
    report = read(root / receipt["report"])
    env = dict(report["environment"])
    env.pop("device_identity")
    require(receipt["plan_id"] == plan["plan_id"] and file_hash(root / receipt["report"]) == receipt["sha256"] and
            report["status"] == "completed" and report["source"] == plan["source"] and env == plan["environment"],
            "Backend verification does not match this continuation.")


def work(root, repo, max_tasks=None):

    plan, exp, manifest, library, tasks, old = _load(root, repo)
    if not plan["development"]:
        _verified(root, plan)
    allowed = set(plan["task_ids"])
    selected = sorted((t for t in tasks if t["task_id"] in allowed),
                      key=lambda t: (t["iso_class_id"], t["p"], t["experiment_role"], t["restart_id"]))
    output, execution = exp._record_directory(root / "attempts"), _execution(plan, manifest, exp)
    from qaoa_study.records import write_once_json
    output.mkdir(exist_ok=True)
    with exp._writer_lock(output):
        if (output / "manifest.json").exists():
            require(read(output / "manifest.json") == execution, "Supplement execution identity changed.")
        else:
            write_once_json(output / "manifest.json", execution)
        paths = [p for p in output.glob("*.json")]
        added, _ = exp._load_flat_attempts(manifest, selected, output, metadata_only=True, paths=paths, execution=execution)
        prior = [row for row in old if row["task_id"] in allowed] + added
        _check_attempts(prior, manifest["config"]["max_attempts"], exp)
        report = {"executed": 0, "execution_faults": 0, "compute_started": False}
        device = exp.environment(plan["backend"])["device_identity"]
        exp._execute_work(manifest, library, selected, output, execution, prior, report,
                          backend=plan["backend"], device_identity=device, max_tasks=max_tasks)
        report.update(planned=plan["planned"], parent_valid=plan["parent_valid"])
        atomic_json(root / "progress.json", report)
    return report


def summarize(root, repo):

    plan, exp, manifest, library, tasks, _ = _load(root, repo)
    from qaoa_study import analysis
    from qaoa_study.records import evaluate_trace, write_once_json
    allowed = set(plan["task_ids"])
    supplemental = [t for t in tasks if t["task_id"] in allowed]
    require(read(root / "attempts/manifest.json") == _execution(plan, manifest, exp), "Supplement execution identity changed.")
    audit = {}
    added, _ = exp._load_flat_attempts(manifest, supplemental, root / "attempts", execution=_execution(plan, manifest, exp), audit=audit)
    new_orphans = sorted(set(audit.get("started_attempt_ids", [])) - {r["attempt_id"] for r in added})
    added_by_group = {}
    for row in added:
        added_by_group.setdefault((row["iso_class_id"], row["experiment_role"]), []).append(row)
    graphs = {g["iso_class_id"]: g for g in library["graphs"]}
    refs, selected, costs, ref_costs, provenance = {}, {}, [], [], Counter()
    parent_execution = read(repo / plan["parent"] / "attempts/manifest.json")["execution_id"]
    affected_graphs = set()
    cost_fields = {"task_id", "attempt_id", "kind", "counts", "elapsed_seconds", "preparation_seconds",
                   "grid", "cost_status", "cost_unavailable"}
    buffer, current = [], None

    def collect():
        if not buffer:
            return
        planned = [t for group, _, _ in buffer for t in group]
        old_rows = [r for _, rows, _ in buffer for r in rows]
        new_rows = [r for _, _, rows in buffer for r in rows]
        all_rows = old_rows + new_rows
        _check_attempts(all_rows, manifest["config"]["max_attempts"], exp)
        chosen = exp.select_attempts(all_rows)
        original = exp.select_attempts(old_rows)
        for task_id, row in original.items():
            if not exp.execution_failed(row):
                require(chosen[task_id]["attempt_id"] == row["attempt_id"], "A valid parent result would be replaced.")
        references = exp.freeze_references(manifest, planned, chosen)
        refs.update(references)
        costs.extend({k: v for k, v in row.items() if k in cost_fields} for row in all_rows)
        for task in planned:
            attempt = chosen.get(task["task_id"])
            if attempt is None:
                continue
            origin = "parent" if attempt["execution_id"] == parent_execution else "supplement"
            provenance[(task["n"], task["p"], task.get("method") or task["experiment_role"], origin)] += 1
            if origin == "supplement":
                affected_graphs.add(task["iso_class_id"])
            if task["experiment_role"] == "reference":
                ref_costs.append({k: v for k, v in attempt.items() if k in cost_fields})
                continue
            reference = references[task["iso_class_id"], task["p"]]
            trace = attempt.get("trace", [])
            hit = evaluate_trace(attempt, reference["C_ref"], C_star=graphs[task["iso_class_id"]]["C_star"],
                                 metric=manifest["config"]["success_metric"])["first_hit"] if reference["complete"] else None
            keep = {trace[0]["call_id"], hit, attempt.get("best_call_id")} if trace else set()
            selected[task["task_id"]] = {k: v for k, v in attempt.items() if k not in ("trace", "initial_gradient", "final_gradient")}
            selected[task["task_id"]]["trace"] = [row for row in trace if row["call_id"] in keep]

    parent_audit, old_orphans = {}, set()
    for group, rows, _ in exp.iter_attempt_groups(manifest, tasks, repo / plan["parent"] / "attempts", audit=parent_audit):
        old_orphans.update(set(parent_audit.get("started_attempt_ids", [])) - {row["attempt_id"] for row in rows})
        parent_audit.clear()
        graph = group[0]["iso_class_id"]
        if current is not None and graph != current:
            collect()
            buffer.clear()
        current = graph
        buffer.append((group, rows, added_by_group.get((graph, group[0]["experiment_role"]), [])))
    collect()
    totals = Counter()
    for (n, p, method, origin), count in provenance.items():
        totals[n, p, method] += count
    settings = {"success_metric": manifest["config"]["success_metric"],
                "evaluation_restarts": manifest["config"]["evaluation_restarts"], "bootstrap_seed": 20261006, "bootstrap_samples": 2000}
    summary = analysis.build_transfer_summary(library, [t for t in tasks if t["experiment_role"] != "reference"], selected, refs, settings=settings)
    summary.update(planned_quantum_tasks_including_references=len(tasks), source_id=manifest["source_id"],
                   all_attempt_costs=analysis._costs(costs), selected_reference_costs=analysis._costs(ref_costs),
                   platform_continuation={"plan_id": plan["plan_id"], "parent": plan["parent"],
                       "parent_environment": plan["parent_environment"], "supplement_environment": plan["environment"],
                       "orphan_start_receipts": sorted(old_orphans), "orphan_cost_scope": plan["orphan_cost_scope"],
                       "supplement_orphan_start_receipts": new_orphans,
                       "affected_graph_ids": sorted(affected_graphs),
                       "selected_counts": [{"n": n, "p": p, "method": method, "origin": origin, "count": count,
                                            "fraction": count / totals[n, p, method]}
                                           for (n, p, method, origin), count in sorted(provenance.items())]})
    summary["all_attempt_costs"]["attempts"] = len(costs)
    summary["all_attempt_costs"]["population"] = "All completed attempts across both environments; interrupted attempt work remains unknown."
    require(summary["complete"] and all(ref["complete"] for ref in refs.values()), "Merged study remains incomplete; retain all attempts for inspection.")
    _load(root, repo)
    if not (root / "references").exists():
        runtime.staged(root, "references", lambda p: exp.save_references(p, refs), exp.read_references)
    require(exp.read_references(root / "references") == refs, "Merged references changed.")
    for name, value in (("summary.json", summary), ("complete.json", {"complete": True, "plan_id": plan["plan_id"],
                         "graphs": len(graphs), "tasks": len(tasks), "summary_digest": exp.digest(summary)})):
        if (root / name).exists():
            require(read(root / name) == value, f"Saved {name} differs from checked records.")
        else:
            write_once_json(root / name, value)
    return summary


def status(root):
    state = read(root / "status.json") if (root / "status.json").exists() else {"state": "not_started"}
    state["active_lock"] = runtime.locked(root)
    if state.get("state") == "running" and not state["active_lock"]:
        state["state"] = "stopped"
    if (root / "plan.json").exists():
        from qaoa_study.records import execution_failed, read_run
        plan = read(root / "plan.json")
        valid = set()
        for path in (root / "attempts").glob("*.json"):
            if path.name != "manifest.json" and not path.name.endswith((".started.json", ".io.json")):
                row = read_run(path, require_integrity=True)
                require(row["task_id"] in plan["task_ids"], "Unexpected supplemental task in status.")
                if not execution_failed(row):
                    valid.add(row["task_id"])
        state.update(completed=plan["parent_valid"] + len(valid), planned=plan["parent_total"],
                     tail_completed=len(valid), tail_planned=plan["planned"], remaining=plan["planned"] - len(valid),
                     complete=(root / "complete.json").exists(),
                     count_scope="Parent sealed counts retained provisionally; final summary validates every record.")
    return state


def supervise(root, repo, parent, development):
    require(not runtime.locked(parent) and not worker_locked(parent), "Stop the original driver and worker first.")
    parent_guard = runtime.driver_lock(parent) if os.name == "posix" else nullcontext()
    with runtime.driver_lock(root) as lock, parent_guard as parent_lock:
        state = {"session": uuid4().hex, "pid": os.getpid(), "state": "running", "phase": "prepare"}
        stopping = False
        def request_stop(*_):
            nonlocal stopping
            stopping = True
        signal.signal(signal.SIGTERM, request_stop)
        signal.signal(signal.SIGINT, request_stop)
        if os.name == "posix":
            signal.signal(signal.SIGHUP, signal.SIG_IGN)
        def update(**values):
            state.update(values, updated_utc=runtime.now())
            atomic_json(root / "status.json", state)
        def check_stop():
            stop = read(root / "stop.json") if (root / "stop.json").exists() else {}
            if stopping or stop.get("session") == state["session"]:
                raise InterruptedError("Stopped; old data and completed supplement attempts are retained.")
        try:
            for phase in ("prepare", "verify", "work", "summarize"):
                check_stop()
                update(phase=phase, child_pid=None)
                command = [sys.executable, "-B", "-u", str(SCRIPT), "_step", "--repo", str(repo), "--root", str(root),
                           "--parent", str(parent), "--phase", phase, "--parent-pid", str(os.getpid())]
                if development:
                    command.append("--development")
                if parent_lock is not None:
                    command.extend(("--parent-lock-fd", str(parent_lock.fileno())))
                child = subprocess.Popen(command, cwd=repo, stdin=subprocess.DEVNULL,
                    **({"pass_fds": (lock.fileno(), parent_lock.fileno())} if os.name == "posix" else {}))
                try:
                    while child.poll() is None:
                        check_stop()
                        update(child_pid=child.pid)
                        time.sleep(1)
                    check_stop()
                    require(child.returncode == 0, f"{phase} exited {child.returncode}; inspect logs/console.log.")
                finally:
                    runtime.stop_child(child)
            update(state="complete", phase="complete", child_pid=None)
            return 0
        except (Exception, KeyboardInterrupt) as error:
            update(state="paused", child_pid=None, reason=f"{type(error).__name__}: {error}")
            print(state["reason"], file=sys.stderr, flush=True)
            return 2


def main(argv=None):
    global _OWNED_PARENT_LOCK
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("start", "status", "stop", "_run", "_step"))
    parser.add_argument("--repo", type=Path, default=REPO)
    parser.add_argument("--parent", type=Path, default=Path(DEFAULT_PARENT))
    parser.add_argument("--root", type=Path, default=Path(DEFAULT_ROOT))
    parser.add_argument("--watch", type=float, default=0)
    parser.add_argument("--development", action="store_true")
    parser.add_argument("--phase", choices=("prepare", "verify", "work", "summarize"), help=argparse.SUPPRESS)
    parser.add_argument("--parent-pid", type=int, help=argparse.SUPPRESS)
    parser.add_argument("--parent-lock-fd", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    repo = args.repo.resolve()
    root, parent = (repo / args.root).resolve(), (repo / args.parent).resolve()
    require(parent.is_relative_to(repo / "data") and root.is_relative_to(repo / "data") and
            not root.is_relative_to(parent) and not parent.is_relative_to(root), "Use distinct data directories inside this project.")
    if args.command == "status":
        require(args.watch == 0 or args.watch >= 2, "Watch interval must be at least two seconds.")
        while True:
            print(json.dumps(status(root), indent=2), flush=True)
            if not args.watch:
                return 0
            time.sleep(args.watch)
    if args.command == "stop":
        if runtime.locked(root):
            atomic_json(root / "stop.json", {"session": read(root / "status.json")["session"]})
        return 0
    if args.command == "_step":
        runtime.bind_parent(args.parent_pid)
        if args.parent_lock_fd is not None:
            descriptor, target = os.fstat(args.parent_lock_fd), (parent / "driver.lock").stat()
            require((descriptor.st_dev, descriptor.st_ino) == (target.st_dev, target.st_ino), "Inherited parent lock refers to another file.")
            _OWNED_PARENT_LOCK = parent
        if args.phase == "prepare":
            result = prepare(parent, root, repo, development=args.development)
            print(json.dumps({"planned_tail": result["planned"], "parent_valid": result["parent_valid"]}), flush=True)
        elif args.phase == "verify":
            plan, *_ = _load(root, repo)
            if (root / "verification.json").exists():
                _verified(root, plan)
                return 0
            from scripts.verify_backend import main as verify
            from qaoa_study.records import write_once_json
            folder = root / "validation" / uuid4().hex
            folder.mkdir(parents=True)
            require(verify(["--execute", "--backend", plan["backend"], "--sizes", "4", "6", "--depths", "1", "2",
                            "--output", str(folder / "report.json"), "--attempts-dir", str(folder / "attempts")]) == 0, "Backend verification failed.")
            write_once_json(root / "verification.json", {"plan_id": plan["plan_id"],
                "report": (folder / "report.json").relative_to(root).as_posix(), "sha256": file_hash(folder / "report.json")})
        elif args.phase == "work":
            report = work(root, repo)
            print(json.dumps(report), flush=True)
            require(report["missing_tasks"] == report["unresolved_execution_faults"] == 0, "Supplement remains incomplete; inspect retained faults.")
        else:
            summarize(root, repo)
        return 0
    require(args.development or sys.platform == "linux", "Run production computation on ICRN/Linux.")
    root.mkdir(parents=True, exist_ok=True)
    if args.command == "_run":
        return supervise(root, repo, parent, args.development)
    if runtime.locked(root):
        print(json.dumps(status(root), indent=2))
        return 0
    if (root / "complete.json").exists():
        _load(root, repo)
        print(json.dumps(status(root), indent=2))
        return 0
    require(not runtime.locked(repo / "data/manual/size-revision-launcher-v1"), "Stop the original full-sequence launcher first.")
    (root / "logs").mkdir(exist_ok=True)
    command = [sys.executable, "-B", "-u", str(SCRIPT), "_run", "--repo", str(repo), "--root", str(root), "--parent", str(parent)]
    if args.development:
        command.append("--development")
    with (root / "logs/console.log").open("ab", buffering=0) as log:
        child = subprocess.Popen(command, cwd=repo, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            **({"start_new_session": True} if os.name == "posix" else {"creationflags": subprocess.CREATE_NO_WINDOW}))
    print(json.dumps({"launch_requested": True, "pid": child.pid, "log": str(root / "logs/console.log")}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError) as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(2)

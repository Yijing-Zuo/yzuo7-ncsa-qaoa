import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import signal
import subprocess
import sys
import time
from uuid import uuid4
import zipfile

SCRIPT = Path(__file__).resolve()
REPO = SCRIPT.parents[1]
sys.path.insert(0, str(REPO))
from drivers import run_b3_full as runtime

CONTROL = Path("data/manual/size-revision-launcher-v1")
OLD = Path("data/manual/new-families-full-v1")
DESIGN = Path("configs/size-revision")
CASES = (("ws", "size-ws-v2", "graphs-ws-new-sizes.json", 284),
         ("rgg", "size-rgg35-v2", "graphs-rgg-degree35.json", 562),
         ("original4", "size-original4-v2", "graphs-original4-new-sizes.json", 1136))
PHASES = tuple("graphs-" + row[0] for row in CASES) + ("old-ws",) + tuple("run-" + row[0] for row in CASES)
read, require = runtime.read, runtime.require


def worker_locked(root):

    path = root / "attempts/writer.lock"
    if not path.exists():
        return False
    with path.open("r+b") as stream:
        try:
            if os.name == "nt":
                import msvcrt
                if path.stat().st_size == 0:
                    stream.write(b"0")
                    stream.flush()
                    stream.seek(0)
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return True
    return False


def require_idle(repo):
    for root in (repo / OLD, *(repo / "data/manual" / row[1] for row in CASES)):
        require(not runtime.locked(root) and not worker_locked(root),
                f"Another driver/worker owns {root}. Stop it before starting the sequence.")


def verify_update(repo):
    manifest = read(repo / DESIGN / "update-manifest.json")
    files = {**manifest["working_source"]["files"],
             **{name: sha for name, sha in manifest["files"].items() if name.endswith((".py", ".json"))}}
    require(all((repo / name).is_file() and runtime.file_hash(repo / name) == sha
                for name, sha in files.items()), "Installed runtime/configuration differs from the size-revision update package.")


def frozen_runtime(repo):

    root = repo / OLD
    meta = read(root / "run.json")
    expected = {**meta["source"]["files"], **meta["support_hashes"],
                "_provenance/run.json": runtime.file_hash(root / "run.json")}
    target = root / "frozen-runtime"
    with zipfile.ZipFile(root / "frozen-source.zip") as archive:
        manifest = json.loads(archive.read("source-preservation.json"))
        require(manifest["files"] == expected and manifest["source_id"] == meta["source"]["source_id"]
                and set(archive.namelist()) == {*expected, "source-preservation.json"}
                and len(archive.namelist()) == len(expected) + 1, "Preserved source archive inventory differs.")
        for name, sha in expected.items():
            relative = PurePosixPath(name)
            path = target.joinpath(*relative.parts)
            require(not relative.is_absolute() and ".." not in relative.parts and "\\" not in name
                    and ":" not in name and path.resolve().is_relative_to(target.resolve()), "Unsafe preserved source path.")
            payload = archive.read(name)
            require(hashlib.sha256(payload).hexdigest() == sha, "Preserved source checksum differs.")
            if path.exists():
                require(runtime.file_hash(path) == sha, f"Existing frozen source changed: {name}")
            else:
                path.parent.mkdir(parents=True, exist_ok=True)
                with path.open("xb") as stream:
                    stream.write(payload)
    return target


def old_ws(repo):

    frozen = frozen_runtime(repo)
    sys.path.insert(0, str(frozen))
    from qaoa_study import experiments as exp
    require(Path(exp.__file__).resolve() == frozen / "qaoa_study/experiments.py", "Old worker imported another checkout.")
    root, control = repo / OLD, repo / CONTROL
    manifest, library, tasks = exp.read_batch(root / "batch")
    require(exp.source_identity() == manifest["source"], "Frozen working source differs from the old batch.")
    ids = sorted(g["iso_class_id"] for g in library["graphs"]
                 if g["n"] in (12, 16, 20) and g["provenance"][0]["family"] == "ws")
    require(len(ids) == 278, f"Expected 278 old WS graphs; found {len(ids)}.")
    selected = set(ids)
    groups = {exp.digest([key[0], key[1]]): len(rows) for key, rows in exp._task_groups(tasks).items() if key[0] in selected}
    index = {"planned": sum(groups.values()), "groups": groups, "graph_ids": ids, "source_id": manifest["source_id"]}
    require(index["planned"] == 278 * 239, "Old WS task coverage differs from the adopted full pools.")
    index_path = control / "old-ws-progress-index.json"
    if index_path.exists():
        require(read(index_path) == index, "Old WS selection differs from its saved scope.")
    else:
        runtime.atomic_json(index_path, index)
    result = exp.run_worker(root / "batch", root / "attempts", backend="lightning.gpu", execute=True,
                            partitioned=True, graph_ids=ids)
    require(result["missing_tasks"] == result["unresolved_execution_faults"] == 0,
            "Old WS has missing tasks or execution faults; completed records remain available.")
    runtime.atomic_json(control / "old-ws-complete.json", {"source_id": manifest["source_id"], "result": result})
    print(json.dumps(result, indent=2), flush=True)


def step(repo, phase, parent_pid):
    runtime.bind_parent(parent_pid)
    for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
        os.environ[name] = "1"
    require_idle(repo)
    if phase == "old-ws":
        return old_ws(repo)
    action, name = phase.split("-", 1)
    row = next(row for row in CASES if row[0] == name)
    command = [sys.executable, "-B", "-u", str(repo / "drivers/run_new_graphs_full.py"),
               "graphs" if action == "graphs" else "start", "--root", str(Path("data/manual") / row[1]),
               "--graph-config", str(DESIGN / row[2])]
    if action == "run":
        command.append("--foreground")
    os.execv(sys.executable, command)


def progress(root, index_path, planned):
    count = 0
    if index_path.exists():
        index = read(index_path)
        sealed = {path.stem for path in (root / "attempts/sealed").glob("*.tgz")}
        count, planned = sum(n for group, n in index["groups"].items() if group in sealed), index["planned"]
    return {"planned": planned, "sealed_completed": count, "remaining_unsealed": planned - count}


def status(repo):
    control = repo / CONTROL
    state = read(control / "status.json") if (control / "status.json").exists() else {"state": "not_started"}
    state["active_lock"] = runtime.locked(control)
    if not state["active_lock"] and state.get("state") == "running":
        state["state"] = "stopped"
    old = progress(repo / OLD, control / "old-ws-progress-index.json", 278 * 239)
    old.update(name="old-ws", graphs=278,
               complete=(control / "old-ws-complete.json").exists() and old["remaining_unsealed"] == 0,
               count_available=(control / "old-ws-progress-index.json").exists())
    state["batches"] = [old]
    for name, directory, _, graphs in CASES:
        root = repo / "data/manual" / directory
        row = progress(root, root / "progress-index.json", graphs * 239)
        row.update(name=name, graphs=graphs, complete=(root / "complete.json").exists(),
                   graphs_frozen=(root / "graph-summary.json").exists())
        state["batches"].append(row)
    state["count_scope"] = "Sealed complete groups; saved attempts in the active group are retained but not yet counted."
    return state


def supervise(repo):
    control = repo / CONTROL
    with runtime.driver_lock(control) as lock:
        state = {"session": uuid4().hex, "pid": os.getpid(), "state": "running", "phase": "preflight",
                 "started_utc": runtime.now()}
        stopping = False
        def request_stop(*_):
            nonlocal stopping
            stopping = True
        signal.signal(signal.SIGTERM, request_stop)
        signal.signal(signal.SIGINT, request_stop)
        if os.name == "posix":
            signal.signal(signal.SIGHUP, signal.SIG_IGN)
        def update(**values):
            state.update(values, updated_utc=runtime.now())
            runtime.atomic_json(control / "status.json", state)
        def check_stop():
            stop = read(control / "stop.json") if (control / "stop.json").exists() else {}
            if stopping or stop.get("session") == state["session"] or stop.get("requested_utc", "") >= state["started_utc"]:
                raise InterruptedError("Paused; completed graph files and optimizer records are retained.")
        try:
            update(child_pid=None)
            require_idle(repo)
            verify_update(repo)
            frozen_runtime(repo)
            for phase in PHASES:
                check_stop()
                update(phase=phase, child_pid=None)
                command = [sys.executable, "-B", "-u", str(SCRIPT), "_step", "--phase", phase,
                           "--parent-pid", str(os.getpid())]
                child = subprocess.Popen(command, cwd=repo, stdin=subprocess.DEVNULL,
                    **({"pass_fds": (lock.fileno(),)} if os.name == "posix" else {}))
                try:
                    update(child_pid=child.pid)
                    while child.poll() is None:
                        check_stop()
                        time.sleep(1)
                    check_stop()
                    require(child.returncode == 0, f"{phase} exited {child.returncode}; inspect logs/console.log.")
                finally:
                    runtime.stop_child(child)
            update(state="complete", phase="complete", child_pid=None)
            return 0
        except (Exception, KeyboardInterrupt) as error:
            update(state="paused", child_pid=None, reason=f"{type(error).__name__}: {error}")
            print(state["reason"], file=sys.stderr, flush=True)
            return 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("start", "status", "stop", "_run", "_step"))
    parser.add_argument("--watch", type=float, default=0)
    parser.add_argument("--phase", choices=PHASES, help=argparse.SUPPRESS)
    parser.add_argument("--parent-pid", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    control = REPO / CONTROL
    if args.command == "status":
        require(args.watch == 0 or args.watch >= 2, "Watch interval must be at least two seconds.")
        while True:
            print(json.dumps(status(REPO), indent=2), flush=True)
            if not args.watch:
                return 0
            time.sleep(args.watch)
    if args.command == "stop":
        if runtime.locked(control):
            current = read(control / "status.json") if (control / "status.json").exists() else {}
            runtime.atomic_json(control / "stop.json", {"session": current.get("session"), "requested_utc": runtime.now()})
        return 0
    require(sys.platform == "linux", "Run this full GPU sequence on the existing Linux/ICRN environment.")
    os.chdir(REPO)
    if args.command == "_step":
        step(REPO, args.phase, args.parent_pid)
        return 0
    if args.command == "_run":
        return supervise(REPO)
    control.mkdir(parents=True, exist_ok=True)
    if runtime.locked(control):
        print(json.dumps(status(REPO), indent=2))
        return 0
    require_idle(REPO)
    verify_update(REPO)
    frozen_runtime(REPO)
    (control / "logs").mkdir(exist_ok=True)
    with (control / "logs/console.log").open("ab", buffering=0) as log:
        child = subprocess.Popen([sys.executable, "-B", "-u", str(SCRIPT), "_run"], cwd=REPO,
            stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    for _ in range(50):
        current = read(control / "status.json") if (control / "status.json").exists() else {}
        if current.get("pid") == child.pid and runtime.locked(control):
            break
        require(child.poll() is None, "Launcher exited during startup; inspect logs/console.log.")
        time.sleep(.1)
    else:
        runtime.stop_child(child)
        raise RuntimeError("Launcher startup timed out; inspect logs/console.log.")
    print(json.dumps({"launch_requested": True, "pid": child.pid, "log": str(control / "logs/console.log")}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, RuntimeError) as error:
        print(f"{type(error).__name__}: {error}", file=sys.stderr)
        raise SystemExit(2)
    except KeyboardInterrupt:
        raise SystemExit(130)

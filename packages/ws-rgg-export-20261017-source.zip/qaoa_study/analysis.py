from collections import defaultdict
import math

import numpy as np
from scipy.cluster.hierarchy import fcluster, linkage
from scipy.spatial.distance import squareform

from .records import (DEFAULT_SUCCESS_METRIC, LEGACY_SUCCESS_METRIC, evaluate_trace,
                      execution_failed, resolve_success_metric, success_threshold)


ANALYSIS_VERSION = "plan-a-analysis-v3"
DEFAULT_ANALYSIS_SETTINGS = {
    "success_metric": DEFAULT_SUCCESS_METRIC,
    "evaluation_restarts": 50,
    "cluster_threshold": 0.05,
    "cluster_sensitivity": [0.025, 0.1],
    "energy_bins": 20,
}


def _finite(value):
    return value is not None and math.isfinite(value)


def _analysis_settings(defaults, settings):
    supplied = settings or {}
    metric = resolve_success_metric(supplied if any(k in supplied for k in ("epsilon", "success_metric"))
                                    else defaults["success_metric"])
    return {**{k: v for k, v in defaults.items() if k != "success_metric"},
            **{k: v for k, v in supplied.items() if k not in ("epsilon", "success_metric")},
            "success_metric": metric}


def wilson_interval(successes: int, planned: int) -> list | None:

    if not 0 <= successes <= planned:
        raise ValueError("Expected 0 <= successes <= denominator.")
    if not planned:
        return None
    z = 1.959963984540054
    rate = successes / planned
    denominator = 1 + z * z / planned
    center = (rate + z * z / (2 * planned)) / denominator
    half = z * math.sqrt(rate * (1 - rate) / planned + z * z / (4 * planned**2)) / denominator
    return [0.0 if successes == 0 else max(0.0, center - half),
            1.0 if successes == planned else min(1.0, center + half)]


def evaluate_restart(task: dict, attempt: dict | None, reference: dict | None,
                     epsilon: float | None = None, *, C_star: float | None = None,
                     metric: dict | None = None) -> dict:

    if epsilon is not None and metric is not None:
        raise ValueError("Specify metric or legacy epsilon, not both.")
    metric = resolve_success_metric(epsilon if epsilon is not None else metric)
    row = {key: task.get(key) for key in (
        "task_id", "library_id", "iso_class_id", "p", "experiment_role", "pool",
        "method", "restart_id", "seed", "theta0", "budget", "protocol_version", "graph_split",
    )}
    reference_ready = bool(reference and reference.get("complete") and _finite(reference.get("C_ref")))
    row.update(
        attempt_id=attempt.get("attempt_id") if attempt else None,
        batch_id=attempt.get("batch_id") if attempt else None,
        reference_id=reference.get("reference_id") if reference else None,
        reference_complete=reference_ready,
        C_ref=reference.get("C_ref") if reference_ready else None,
        success_metric=metric, C_star=C_star,
        threshold=success_threshold(reference["C_ref"], C_star, metric) if reference_ready else None,
        epsilon=metric["tolerance"] * (C_star if metric["kind"] == "normalized_gap" else 1.0)
            if metric["kind"] == "absolute" or C_star is not None else None,
        C_final=None, theta_final=None, best_seen=None, best_theta=None,
        final_call_id=None, best_call_id=None,
        stop_reason=None, counts=None, elapsed_seconds=None, execution_valid=False,
        cost_status=None, cost_unavailable=None,
        execution_fault=False, missing=attempt is None, first_hit=None, hit=None,
        terminal_success=None, reference_exceeded=None,
    )
    if attempt is None:
        return row
    for name in ("C_final", "theta_final", "best_seen", "best_theta", "final_call_id", "best_call_id",
                 "stop_reason", "counts", "elapsed_seconds", "cost_status", "cost_unavailable"):
        row[name] = attempt.get(name)
    valid = bool(attempt.get("run_completed") and not execution_failed(attempt)
                 and _finite(attempt.get("C_final")))
    row.update(execution_valid=valid, execution_fault=not valid)
    if reference_ready:
        row.update(evaluate_trace(attempt, reference["C_ref"], C_star=C_star, metric=metric))


        row["terminal_success"] = bool(valid and row["terminal_success"])
    return row


def hit_statistics(rows: list[dict]) -> dict:


    planned = len(rows)
    hits = sorted(row["first_hit"] for row in rows if row["first_hit"] is not None)
    curve = [{"objective_calls": 0, "hits": 0, "planned": planned, "fraction": 0.0 if planned else None}]
    for call in sorted(set(hits)):
        count = sum(value <= call for value in hits)
        curve.append({"objective_calls": call, "hits": count, "planned": planned,
                      "fraction": count / planned})

    def quantile(fraction):
        required = math.ceil(fraction * planned)
        if not planned or len(hits) < required:
            return {"value": None, "status": "not_reached"}
        return {"value": hits[required - 1], "status": "reached"}

    return {
        "population": "all_planned_logical_restarts", "planned": planned,
        "hits": len(hits), "curve": curve,
        "median": quantile(0.5), "p90": quantile(0.9),
        "conditional_on_hit": {
            "population": "selected_attempts_with_finite_threshold_hit", "count": len(hits),
            "median": hits[math.ceil(0.5 * len(hits)) - 1] if hits else None,
            "p90": hits[math.ceil(0.9 * len(hits)) - 1] if hits else None,
        },
    }


def pool_statistics(rows: list[dict], expected_restarts: int = 50) -> dict:


    planned = len(rows)
    valid = sum(row["execution_valid"] for row in rows)
    missing = sum(row["missing"] for row in rows)
    faults = sum(row["execution_fault"] for row in rows)
    reference_ready = bool(planned and all(row["reference_complete"] for row in rows))
    successes = sum(row["terminal_success"] is True for row in rows) if reference_ready else None
    complete_execution = bool(planned and valid == planned)
    configured_complete = bool(complete_execution and planned == expected_restarts and reference_ready)
    scientific_complete = bool(configured_complete and planned == 50)
    return {
        "successes": successes, "planned": planned, "valid": valid,
        "execution_faults": faults, "missing": missing, "expected_restarts": expected_restarts,
        "complete_execution": complete_execution, "reference_complete": reference_ready,
        "configured_pool_complete": configured_complete,
        "scientific_label_complete": scientific_complete,
        "success_rate_label": successes / planned if scientific_complete else None,
        "fixed_budget_success_fraction": successes / planned if reference_ready else None,
        "wilson95_planned": wilson_interval(successes, planned) if reference_ready else None,
        "provisional": not scientific_complete,
        "provisional_interpretation": "known_successes/planned; missing outcomes are unresolved",
        "hit_statistics": hit_statistics(rows) if reference_ready else None,
    }


def periodic_distances(angles, p: int, beta_period: float = math.pi) -> np.ndarray:

    values = np.asarray(angles, dtype=np.float64).reshape((-1, 2 * p))
    periods = np.asarray([2 * math.pi] * p + [beta_period] * p)
    wrapped = np.mod(values, periods)
    delta = np.abs(wrapped[:, None, :] - wrapped[None, :, :])
    return np.sqrt(np.sum(np.minimum(delta, periods - delta)**2, axis=-1))


def _entropy(counts) -> float | None:
    total = sum(counts)
    if not total:
        return None
    return -math.fsum((count / total) * math.log(count / total) for count in counts if count)


def cluster_endpoints(rows: list[dict], p: int, threshold: float = 0.05,
                      beta_period: float = math.pi) -> dict:


    if threshold <= 0 or not math.isfinite(threshold):
        raise ValueError("Clustering threshold must be finite and positive.")
    endpoints = sorted((row for row in rows if row["execution_valid"]
                        and row.get("theta_final") is not None), key=lambda row: row["task_id"])
    distances = periodic_distances([row["theta_final"] for row in endpoints], p, beta_period)
    labels = fcluster(linkage(squareform(distances, checks=False), method="complete"),
                      t=threshold, criterion="distance") if len(endpoints) > 1 else np.ones(len(endpoints), dtype=int)
    groups = defaultdict(list)
    for label, row in zip(labels, endpoints, strict=True):
        groups[int(label)].append(row)
    clusters = [{"cluster_id": members[0]["task_id"], "count": len(members),
                 "task_ids": [row["task_id"] for row in members],
                 "attempt_ids": [row["attempt_id"] for row in members]}
                for members in groups.values()]
    clusters.sort(key=lambda cluster: cluster["cluster_id"])
    best = min(endpoints, key=lambda row: (-row["C_final"], row["task_id"])) if endpoints else None
    best_cluster = next((cluster for cluster in clusters if best["task_id"] in cluster["task_ids"]), None) if best else None
    return {
        "algorithm": "complete_linkage", "metric": "radian_torus_euclidean",
        "gamma_period": 2 * math.pi, "beta_period": beta_period, "threshold": threshold,
        "planned": len(rows), "valid_endpoints": len(endpoints), "excluded": len(rows) - len(endpoints),
        "cluster_count": len(clusters), "clusters": clusters,
        "shannon_entropy_nats": _entropy([cluster["count"] for cluster in clusters]),
        "best_cluster_id": best_cluster["cluster_id"] if best_cluster else None,
        "best_endpoint_task_id": best["task_id"] if best else None,
        "best_cluster_frequency": best_cluster["count"] / len(endpoints) if best_cluster else None,
    }


def energy_distribution(rows: list[dict], C_star: float | None, bins: int = 20) -> dict:


    if bins < 1 or int(bins) != bins:
        raise ValueError("Expected a positive integer bin count.")
    endpoints = [row for row in rows if row["execution_valid"] and _finite(row["C_final"])]
    values = [row["C_final"] for row in endpoints]
    result = {
        "C_source": "selected_attempt_C_final", "population": "execution_valid_endpoints",
        "values": values, "task_ids": [row["task_id"] for row in endpoints],
        "count": len(values), "mean": float(np.mean(values)) if values else None,
        "population_variance": float(np.var(values)) if values else None,
        "minimum": min(values) if values else None, "maximum": max(values) if values else None,
        "C_star": C_star, "bin_edges": None, "bin_counts": None,
        "shannon_entropy_nats": None, "out_of_range": None,
        "entropy_population": "finite_endpoints_within_fixed_exact_cut_range",
    }
    if _finite(C_star) and C_star > 0:
        edges = np.linspace(0, C_star, bins + 1)
        counts = np.histogram(values, bins=edges)[0].tolist()
        result.update(bin_edges=edges.tolist(), bin_counts=counts,
                      shannon_entropy_nats=_entropy(counts),
                      out_of_range=sum(value < 0 or value > C_star for value in values))
    return result


def gradient_statistics(samples: list[dict], p: int, edge_count: int, population: str) -> dict:


    valid = [row for row in samples if row.get("gradient") is not None
             and np.shape(row["gradient"]) == (2 * p,) and np.all(np.isfinite(row["gradient"]))]
    gradients = np.asarray([row["gradient"] for row in valid], dtype=np.float64).reshape((-1, 2 * p))
    sources = {}
    for row in valid:
        key = (row.get("task_id"), row.get("attempt_id"), row.get("seed"))
        if key not in sources:
            sources[key] = {"task_id": key[0], "attempt_id": key[1], "seed": key[2], "call_ids": [],
                            "gradient_source": row.get("gradient_source", "caller_supplied.gradient"),
                            "coordinate_source": row.get("coordinate_source", "caller_supplied.theta")}
        sources[key]["call_ids"].append(row.get("call_id"))

    def summarize(array):
        return {"mean": array.mean(axis=0).tolist(), "population_variance": array.var(axis=0).tolist(),
                "norms": np.linalg.norm(array, axis=1).tolist(),
                "mean_norm": float(np.linalg.norm(array, axis=1).mean())} if len(array) else None

    return {
        "population": population, "gradient_convention": "positive_C", "ddof": 0,
        "sample_count": len(valid), "excluded_samples": len(samples) - len(valid),
        "raw_C": summarize(gradients), "C_per_edge": summarize(gradients / edge_count) if edge_count else None,
        "sample_sources": list(sources.values()),
    }


def _costs(rows):


    names = ("objective_calls", "gradient_requests", "device_executions", "device_derivatives", "device_vjps", "iterations")
    metrics = (*names, "elapsed_seconds", "preparation_seconds", "analytic_evaluations", "analytic_points_requested")
    known, unknown = {name: [] for name in metrics}, {name: [] for name in metrics}
    affected = []
    for row in rows:
        unavailable = row.get("cost_unavailable") or {}
        values = {name: (row.get("counts") or {}).get(name) for name in names}
        values.update(elapsed_seconds=row.get("elapsed_seconds"), preparation_seconds=row.get("preparation_seconds"))
        values.update({name: (row.get("grid") or {}).get(name, None if row.get("kind") == "p1_grid" else 0)
                       for name in ("analytic_evaluations", "analytic_points_requested")})
        missing = []
        for name, value in values.items():


            unverified = row.get("cost_status") == "unverified_invalid_result" and name in names
            if not _finite(value) or name in unavailable or unverified:
                unknown[name].append(row.get("attempt_id"))
                missing.append(name)
            else:
                known[name].append(value)
        if missing:
            affected.append({"task_id": row.get("task_id"), "attempt_id": row.get("attempt_id"),
                             "cost_status": row.get("cost_status"), "unknown_metrics": missing,
                             "cost_unavailable": unavailable})
    subtotals = {name: math.fsum(values) if name.endswith("seconds") else sum(values)
                 for name, values in known.items()}
    return {**{name: None if unknown[name] else subtotals[name] for name in metrics},
            "known_subtotals": subtotals,
            "unknown_counts": {name: len(attempts) for name, attempts in unknown.items()},
            "unknown_attempt_ids_by_metric": unknown,
            "unverified_attempt_count": len(affected), "cost_provenance": affected,
            "population": "all_selected_attempts_including_execution_faults",
            "backend_warning": "Tracker counters retain backend-specific semantics; no equivalent-energy conversion"}


def build_summary(library: dict, tasks: list[dict], selected_attempts: dict,
                  references: dict, analysis_settings: dict | None = None) -> dict:


    settings = _analysis_settings(DEFAULT_ANALYSIS_SETTINGS, analysis_settings)
    graph_by_id = {row["iso_class_id"]: row for row in library["graphs"]}
    task_by_id = {task["task_id"]: task for task in tasks}
    if len(task_by_id) != len(tasks):
        raise ValueError("Task identities must be unique; each logical restart counts once.")
    if set(selected_attempts) - set(task_by_id):
        raise ValueError("A selected attempt has no planned task.")
    grouped_tasks = defaultdict(list)
    for task in tasks:
        if task["library_id"] != library["library_id"] or task["iso_class_id"] not in graph_by_id:
            raise ValueError("Task and frozen library identities disagree.")
        if task["graph_split"] != graph_by_id[task["iso_class_id"]]["graph_split"]:
            raise ValueError("Task graph split disagrees with the frozen library.")
        attempt = selected_attempts.get(task["task_id"])
        if attempt and attempt.get("task_id") != task["task_id"]:
            raise ValueError("Selected attempt belongs to another logical task.")
        grouped_tasks[task["iso_class_id"], task["p"]].append(task)
    graph_rows, restart_rows, diagnostics = [], [], []
    for (identity, p), group in sorted(grouped_tasks.items()):
        graph = graph_by_id[identity]
        reference = references.get((identity, p))
        if reference and any(reference.get(key) != expected for key, expected in
                             (("library_id", library["library_id"]), ("iso_class_id", identity), ("p", p))):
            raise ValueError("Reference and graph/depth identities disagree.")
        if reference:
            if "protocol_version" in reference and any(task["protocol_version"] != reference["protocol_version"] for task in group):
                raise ValueError("Reference and task protocol versions disagree.")
            if "planned_task_ids" in reference and set(reference["planned_task_ids"]) != {
                    task["task_id"] for task in group if task["experiment_role"] == "reference"}:
                raise ValueError("Reference comes from a different planned reference pool.")
            if "batch_id" in reference and any(attempt.get("batch_id") != reference["batch_id"]
                                               for task in group if (attempt := selected_attempts.get(task["task_id"]))):
                raise ValueError("Reference and selected attempt batches disagree.")
        C_star = graph.get("C_star") if graph.get("exact_status") == "computed" else None
        rows = [evaluate_restart(task, selected_attempts.get(task["task_id"]), reference,
                                 C_star=C_star, metric=settings["success_metric"])
                for task in group if task["kind"] == "optimization"]
        evaluation = [row for row in rows if row["experiment_role"] == "evaluation"]
        tier1 = [row for row in rows if row["experiment_role"] == "tier1"]
        valid_tier1 = [row for row in tier1 if row["execution_valid"] and _finite(row["best_seen"])]
        best = min(valid_tier1, key=lambda row: (-row["best_seen"], row["task_id"])) if valid_tier1 else None
        C_ref = reference.get("C_ref") if reference and reference.get("complete") else None
        for row in rows:
            row.update(C_star=C_star, C_source="selected_attempt_C_final",
                       ratio_exact=row["C_final"] / C_star if _finite(row["C_final"]) and C_star else None,
                       gap_ref=C_ref - row["C_final"] if _finite(C_ref) and _finite(row["C_final"]) else None,
                       gap_ratio=(C_ref - row["C_final"]) / C_star
                       if _finite(C_ref) and _finite(row["C_final"]) and C_star else None)
        restart_rows.extend(rows)
        pool = pool_statistics(evaluation, settings["evaluation_restarts"])
        provenance = {"library_id": library["library_id"], "iso_class_id": identity, "p": p,
                      "reference_id": reference.get("reference_id") if reference else None,
                      "task_ids": sorted(task["task_id"] for task in group),
                      "attempt_ids": [selected_attempts[task["task_id"]]["attempt_id"] for task in group
                                      if task["task_id"] in selected_attempts]}
        graph_rows.append({
            **provenance, "graph_split": graph["graph_split"], "n": graph["n"],
            "C_star": C_star, "exact_status": graph.get("exact_status"), "C_ref": C_ref,
            "success_metric": settings["success_metric"],
            "evaluation": pool,
            "training_label_eligible": bool(graph["graph_split"] == "training" and pool["scientific_label_complete"]),
            "tier1": {"C_source": "tier1_selected_valid_attempt_trace_best_seen", "planned": len(tier1),
                      "valid": len(valid_tier1), "tier1_best_seen": best["best_seen"] if best else None,
                      "source_task_id": best["task_id"] if best else None,
                      "source_attempt_id": best["attempt_id"] if best else None,
                      "source_call_id": best["best_call_id"] if best else None,
                      "bias_C_ref_minus_tier1_best_seen": C_ref - best["best_seen"] if best and _finite(C_ref) else None,
                      "ratio_exact": best["best_seen"] / C_star if best and C_star else None},
            "reference_ratio_exact": C_ref / C_star if _finite(C_ref) and C_star else None,
            "reference_ratio_C_source": "frozen_reference_C_ref",
            "reference_exceeded_count": sum(row["reference_exceeded"] is True for row in evaluation),
            "costs_by_role": {role: _costs([selected_attempts[task["task_id"]] for task in group
                                           if task["experiment_role"] == role and task["task_id"] in selected_attempts])
                              for role in sorted({task["experiment_role"] for task in group})},
        })
        uniform, trajectory = [], []
        for task in group:
            attempt = selected_attempts.get(task["task_id"])
            if not attempt:
                continue
            origin = {"task_id": task["task_id"], "attempt_id": attempt["attempt_id"], "seed": task["seed"]}
            if task["kind"] == "gradient":
                uniform.extend({**origin, "call_id": sample["call_id"], "gradient": sample.get("gradient"),
                                "gradient_source": "gradient_samples[*].gradient; match call_id (positive C)",
                                "coordinate_source": "gradient_samples[*].theta; match call_id"}
                               for sample in attempt.get("gradient_samples", []))
            elif task["experiment_role"] == "evaluation":
                trajectory.extend({**origin, "call_id": sample["call_id"],
                                   "gradient": [-value for value in sample["gradient"]],
                                   "gradient_source": "-trace[*].gradient; match call_id (stored loss gradient)",
                                   "coordinate_source": "trace[*].theta; match call_id"}
                                  for sample in attempt["trace"] if sample.get("gradient") is not None)
        edge_count = graph.get("m", len(graph.get("edges", [])))
        diagnostics.append({
            **provenance, "population": "evaluation_pool_observed_terminal_solutions",
            "clusters": cluster_endpoints(evaluation, p, settings["cluster_threshold"]),
            "clusters_beta_pi_over_2": cluster_endpoints(
                evaluation, p, settings["cluster_threshold"], beta_period=math.pi / 2),
            "cluster_threshold_sensitivity": [cluster_endpoints(evaluation, p, threshold)
                                              for threshold in settings["cluster_sensitivity"]],
            "energy_distribution": energy_distribution(evaluation, C_star, settings["energy_bins"]),
            "uniform_gradients": gradient_statistics(uniform, p, edge_count, "independent_uniform_periodic_points"),
            "trajectory_gradients": gradient_statistics(trajectory, p, edge_count, "evaluation_optimizer_trials"),
            "gradient_planned_tasks": sum(task["kind"] == "gradient" for task in group),
            "gradient_missing_tasks": sum(task["kind"] == "gradient" and task["task_id"] not in selected_attempts for task in group),
            "gradient_failed_tasks": sum(task["kind"] == "gradient" and task["task_id"] in selected_attempts
                                         and execution_failed(selected_attempts[task["task_id"]]) for task in group),
        })
    return {"analysis_version": ANALYSIS_VERSION, "settings": settings, "library_id": library["library_id"],
            "graph_qaoa": graph_rows, "restarts": restart_rows, "diagnostics": diagnostics}


WARM_ANALYSIS_VERSION = "plan-a-warm-analysis-v2"
DEFAULT_WARM_SETTINGS = {"success_metric": DEFAULT_SUCCESS_METRIC, "bootstrap_seed": 20260912, "bootstrap_samples": 2000}
_WARM_METRICS = ("C_initial", "C_final", "ratio_initial_exact", "ratio_final_exact",
                 "gap_initial_ref", "gap_final_ref", "gap_initial_ratio", "gap_final_ratio",
                 "terminal_success_fraction", "hit_fraction")


def _warm_settings(settings):
    settings = _analysis_settings(DEFAULT_WARM_SETTINGS, settings)
    if (type(settings["bootstrap_samples"]) is not int or
            settings["bootstrap_samples"] < 1 or type(settings["bootstrap_seed"]) is not int or settings["bootstrap_seed"] < 0):
        raise ValueError("Warm analysis requires a positive bootstrap count and nonnegative integer seed.")
    return settings


def build_transfer_summary(library, tasks, selected, references, *, settings=None):


    settings = _warm_settings(settings)
    repeats = settings.setdefault("evaluation_restarts", 50)
    if type(repeats) is not int or repeats < 1:
        raise ValueError("Transfer analysis requires a positive planned B1 restart count.")
    graphs = {graph["iso_class_id"]: graph for graph in library["graphs"]}
    identities = {task["task_id"] for task in tasks}
    if (not graphs or len(graphs) != len(library["graphs"]) or len(identities) != len(tasks)
            or set(selected) - identities or any(attempt["task_id"] != key for key, attempt in selected.items())
            or any(graph["tier"] != 2 or graph["graph_split"] != "evaluation" for graph in graphs.values())):
        raise ValueError("Transfer analysis needs distinct planned tasks and evaluation-only graphs.")
    baseline, groups = defaultdict(list), defaultdict(list)
    fields = ("method", "p", "variant", "feature_group", "shuffle_seed")
    for task in tasks:
        if task["experiment_role"] == "reference":
            continue
        method, p, identity = task["method"], task["p"], task["iso_class_id"]
        if (identity not in graphs or task["library_id"] != library["library_id"]
                or task["graph_split"] != "evaluation" or task["kind"] != "optimization" or p not in (1, 2)):
            raise ValueError("Transfer task and graph/depth identities disagree.")
        if method == "B1":
            if task["experiment_role"] != "evaluation":
                raise ValueError("Transfer B1 baselines must use the evaluation restart pool.")
            baseline[identity, p].append(task)
        elif (method in ("B2", "B3", "B4", "B5") and task["experiment_role"] == "warm_start"
              and task.get("regime") == "random" and task.get("fold") is None and task["restart_id"] == 0
              and task.get("target_scope") in ("external_family_transfer", "external_size_transfer", "independent_holdout")
              and task.get("start_id")
              and task.get("source_id")):
            groups[tuple(task.get(name) for name in fields)].append(task)
        else:
            raise ValueError("Unsupported transfer method, scope or warm-start identity.")
    depths = {p for _, p in baseline}
    if (not depths or set(baseline) != {(identity, p) for identity in graphs for p in depths}
            or any(len(rows) != repeats or {row["restart_id"] for row in rows} != set(range(repeats))
                   for rows in baseline.values())):
        raise ValueError("Every transfer graph/depth needs its complete planned B1 restart pool.")
    for p in depths:
        cases = {key for key in groups if key[1] == p}
        if ({key[0] for key in cases} != {"B2", "B3", "B4", "B5"}
                or {key[2:] for key in cases if key[0] == "B2"}
                != {("medoid", None, None), ("aligned_median", None, None)}
                or len([key for key in cases if key[0] == "B3"]) != 1
                or {key[2:] for key in cases if key[0] == "B4"}
                != {key[2:] for key in cases if key[0] == "B5"}):
            raise ValueError("Transfer needs B2 variants, one B3 rule and matching B4/B5 model cases.")
    if any(key[1] not in depths for key in groups):
        raise ValueError("Warm-start depth has no transfer B1 baseline.")
    restarts, pools, graph_rows, comparisons = [], {}, [], []
    for (identity, p), group in sorted(baseline.items()):
        reference = references.get((identity, p))
        if reference and any(reference.get(name) != value for name, value in
                             (("library_id", library["library_id"]), ("iso_class_id", identity), ("p", p))):
            raise ValueError("Transfer reference and graph/depth identities disagree.")
        rows = [_warm_restart(task, selected.get(task["task_id"]), reference, graphs[identity],
                              settings["success_metric"]) for task in group]
        restarts.extend(rows)
        pools[identity, p] = _b3_pool(rows, "B1")
    for key, group in sorted(groups.items(), key=lambda item: repr(item[0])):
        metadata = dict(zip(fields, key))
        method, p = key[:2]
        if (len(group) != len(graphs) or {task["iso_class_id"] for task in group} != set(graphs)
                or len({task["source_id"] for task in group}) != 1):
            raise ValueError("Each frozen transfer model case must cover every graph exactly once.")
        scopes = {task["target_scope"] for task in group}
        metadata.update(source_id=group[0]["source_id"], regime="random", fold=None,
                        target_scope=next(iter(scopes)) if len(scopes) == 1 else "mixed_external_targets")
        strata = defaultdict(list)
        for task in sorted(group, key=lambda row: row["iso_class_id"]):
            identity = task["iso_class_id"]
            graph, reference = graphs[identity], references.get((identity, p))
            if any(row["budget"] != task["budget"] for row in baseline[identity, p]):
                raise ValueError("Transfer warm starts and B1 must have identical optimizer budgets.")
            warm = _warm_restart(task, selected.get(task["task_id"]), reference, graph, settings["success_metric"])
            warm.update({name: task.get(name) for name in (*fields, "start_id", "source_id", "target_scope")})
            restarts.append(warm)
            b1, other = pools[identity, p], _b3_pool([warm], method)
            source = next(row for row in graph["provenance"] if row["cell_id"] == graph["representative_cell"])
            dimensions = {"family": source["family"], "n": graph["n"]}
            if "target_degree" in source:
                dimensions["degree_band"] = source["target_degree"]
            else:
                dimensions["generation_group"] = source["generation_group"]
            row = {**metadata, **dimensions, "target_scope": task["target_scope"],
                   "library_id": library["library_id"], "iso_class_id": identity,
                   "reference_id": reference.get("reference_id") if reference else None,
                   "B1": b1, method: other, "budget": task["budget"],
                   "complete": b1["complete"] and other["complete"],
                   "provisional": not (b1["complete"] and other["complete"])}
            graph_rows.append(row)
            strata["all", "all"].append(row)
            for dimension, value in dimensions.items():
                strata[dimension, value].append(row)
            if len(scopes) > 1:
                strata["target_scope", task["target_scope"]].append(row)
            strata["cell", source["cell_id"]].append(row)
        for (dimension, value), pairs in sorted(strata.items(), key=lambda item: repr(item[0])):
            pair_scopes = {row["target_scope"] for row in pairs}
            comparisons.append({**metadata, "dimension": dimension, "value": value,
                "target_scope": next(iter(pair_scopes)) if len(pair_scopes) == 1 else "mixed_external_targets",
                "stratum_interpretation": "representative-owner strata; descriptive, no density adjustment",
                **_warm_comparison(pairs, settings, warm_method=method,
                                   metrics_names=(*_WARM_METRICS, "objective_calls"))})
    return {"analysis_version": "plan-a-transfer-analysis-v1", "settings": settings,
            "library_id": library["library_id"], "graph_qaoa": graph_rows,
            "restarts": restarts, "diagnostics": [], "comparisons": comparisons,
            "complete": bool(graph_rows) and all(row["complete"] for row in graph_rows),
            "planned_tasks": len(tasks), "selected_tasks": len(selected), "missing_tasks": len(tasks) - len(selected),
            "selected_costs_by_method": {method: _costs([selected[task["task_id"]] for task in tasks
                if task["method"] == method and task["experiment_role"] != "reference" and task["task_id"] in selected])
                for method in ("B1", "B2", "B3", "B4", "B5")},
            "selected_reference_costs": _costs([selected[task["task_id"]] for task in tasks
                if task["experiment_role"] == "reference" and task["task_id"] in selected])}


def _warm_restart(task, attempt, reference, graph, metric):
    exact = graph.get("C_star") if graph.get("exact_status") == "computed" else None
    row = evaluate_restart(task, attempt, reference, C_star=exact, metric=resolve_success_metric(metric))
    row.update({key: task.get(key) for key in ("regime", "fold", "variant", "fit_id")})
    first = next(iter(attempt.get("trace", [])), None) if attempt else None
    if first and (first["call_id"] != 1 or first.get("theta") != task["theta0"]):
        raise ValueError("Warm comparison requires the actual first call at frozen theta0.")
    initial = first["C"] if first and _finite(first.get("C")) else None
    row.update(C_initial=initial, initial_call_id=1 if initial is not None else None,
               initial_score_source="trace[0].C at frozen theta0; no new objective evaluation",
               initial_score_available=initial is not None, C_star=exact)
    for name, score in (("initial", initial), ("final", row["C_final"])):
        row[f"ratio_{name}_exact"] = score / exact if _finite(score) and exact else None
        row[f"gap_{name}_ref"] = row["C_ref"] - score if _finite(score) and row["reference_complete"] else None
        row[f"gap_{name}_ratio"] = row[f"gap_{name}_ref"] / exact if row[f"gap_{name}_ref"] is not None and exact else None
    return row


def _warm_pool(rows):

    planned = len(rows)
    valid = sum(row["execution_valid"] for row in rows)
    ready = all(row["reference_complete"] for row in rows)
    complete = valid == planned and ready and all(row["initial_score_available"] for row in rows)
    metrics, observed = {}, {}
    for name in _WARM_METRICS[:-2]:
        values = [row[name] for row in rows if row["execution_valid"] and _finite(row[name])]
        mean = math.fsum(values) / len(values) if values else None
        metrics[name] = mean if len(values) == planned else None
        observed[name] = {"mean": mean, "valid_observed": len(values), "planned": planned}
    metrics["terminal_success_fraction"] = sum(row["terminal_success"] is True for row in rows) / planned if ready else None
    metrics["hit_fraction"] = sum(row["first_hit"] is not None for row in rows) / planned if ready else None
    return {"planned": planned, "valid": valid, "missing": sum(row["missing"] for row in rows),
            "execution_faults": sum(row["execution_fault"] for row in rows),
            "reference_complete": ready, "complete": complete, "provisional": not complete,
            "metrics": metrics, "observed_scores": observed,
            "first_hits": [row["first_hit"] for row in rows],
            "task_ids": [row["task_id"] for row in rows], "attempt_ids": [row["attempt_id"] for row in rows],
            "success_interpretation": "known successes/planned; unresolved outcomes retained, not treated as completed failures"}


def _warm_hit_curve(pools):

    if not all(pool["reference_complete"] for pool in pools):
        return None
    events = defaultdict(list)
    for pool in pools:
        for call in pool["first_hits"]:
            if call is not None:
                events[call].append(1 / (len(pools) * pool["planned"]))
    curve = [{"objective_calls": 0, "fraction": 0.0}]
    masses = []
    for call in sorted(events):
        masses.append(math.fsum(events[call]))
        curve.append({"objective_calls": call, "fraction": min(1.0, math.fsum(masses))})
    quantiles = {}
    for name, fraction in (("median", 0.5), ("p90", 0.9)):
        hit = next((point["objective_calls"] for point in curve if point["fraction"] >= fraction - 1e-12), None)
        quantiles[name] = {"value": hit, "status": "reached" if hit is not None else "not_reached"}
    return {"population": "all_planned_graphs_equal_weight; within_graph_all_planned_restarts_equal_weight",
            "graphs": len(pools), "planned_restarts": sum(pool["planned"] for pool in pools),
            "provisional": any(pool["provisional"] for pool in pools), "curve": curve, **quantiles}


def _warm_comparison(rows, settings, *, baseline_method="B1", warm_method="B2", metrics_names=_WARM_METRICS):
    complete = all(row["complete"] for row in rows)
    draws = np.random.default_rng(settings["bootstrap_seed"]).integers(
        len(rows), size=(settings["bootstrap_samples"], len(rows))) if complete and len(rows) > 1 else None
    metrics = {}
    for name in metrics_names:
        baseline = [row[baseline_method]["metrics"][name] for row in rows]
        warm = [row[warm_method]["metrics"][name] for row in rows]
        available = all(_finite(value) for value in baseline + warm)
        delta = np.asarray(warm) - np.asarray(baseline) if available else None
        metrics[name] = {
            baseline_method: math.fsum(baseline) / len(rows) if all(_finite(v) for v in baseline) else None,
            warm_method: math.fsum(warm) / len(rows) if all(_finite(v) for v in warm) else None,
            f"difference_{warm_method}_minus_{baseline_method}": float(delta.mean()) if available else None,
            "paired_bootstrap_ci95": np.quantile(delta[draws].mean(axis=1), [0.025, 0.975]).tolist()
            if available and draws is not None else None,
            "ci_status": "available" if available and draws is not None else
                         "provisional" if not complete else "fewer_than_two_graphs" if len(rows) < 2 else "metric_unavailable",
        }
    return {"graphs": len(rows), "complete": complete, "provisional": not complete,
            "weighting": f"{baseline_method} mean within each graph, then equal graph weights; {warm_method} one start per graph",
            "difference_interpretation": f"{warm_method} minus {baseline_method}; provisional known-success differences are not bounds",
            "metrics": metrics, "hit_statistics": {
                method: _warm_hit_curve([row[method] for row in rows]) for method in (baseline_method, warm_method)},
            "bootstrap": {"unit": "paired iso_class_id", "seed": settings["bootstrap_seed"],
                          "samples": settings["bootstrap_samples"], "interval": "percentile 95%",
                          "scope": "mean paired differences; no CI when planned execution/reference incomplete"}}


def build_warm_summary(library: dict, tasks: list[dict], selected: dict, references: dict, *,
                       b1_tasks: list[dict], b1_selected: dict, settings: dict | None = None,
                       include_comparisons: bool = True) -> dict:


    settings = _warm_settings(settings)
    graphs = {graph["iso_class_id"]: graph for graph in library["graphs"]}
    warm_groups, baseline_tasks = defaultdict(list), defaultdict(list)
    seen = set()
    for method, planned, attempts in (("B1", b1_tasks, b1_selected), ("B2", tasks, selected)):
        identities = {task["task_id"] for task in planned}
        if len(identities) != len(planned) or set(attempts) - identities or identities & seen:
            raise ValueError("Warm comparison contains duplicate/unplanned task identities.")
        seen.update(identities)
        for task in planned:
            graph = graphs.get(task["iso_class_id"])
            if (not graph or task["library_id"] != library["library_id"] or task["graph_split"] != graph["graph_split"]
                    or task["kind"] != "optimization" or task["method"] != method
                    or task["experiment_role"] != ("evaluation" if method == "B1" else "warm_start")):
                raise ValueError("Warm comparison task, graph, method or role disagrees.")
            if task["task_id"] in attempts and attempts[task["task_id"]]["task_id"] != task["task_id"]:
                raise ValueError("Selected warm comparison attempt belongs to another task.")
            if method == "B1":
                baseline_tasks[task["iso_class_id"], task["p"]].append(task)
            else:
                if (task["regime"] not in ("random", "lofo") or task["variant"] not in ("medoid", "aligned_median")
                        or (task["regime"] == "random") != (task["fold"] is None) or graph["graph_split"] != "evaluation"):
                    raise ValueError("Unsupported warm regime/fold/variant or non-evaluation target graph.")
                key = tuple(task[name] for name in ("regime", "fold", "p", "variant", "fit_id"))
                warm_groups[key].append(task)
    restarts, graph_rows, comparisons, evaluated_b1 = [], [], [], {}
    target_sets = {}
    for key, group in sorted(warm_groups.items(), key=lambda item: repr(item[0])):
        metadata = dict(zip(("regime", "fold", "p", "variant", "fit_id"), key))
        identities = {task["iso_class_id"] for task in group}
        target_key = key[:3] + key[4:]
        if len(identities) != len(group) or target_sets.setdefault(target_key, identities) != identities:
            raise ValueError("Each warm variant must have exactly one task per same target graph/depth.")
        paired = []
        for task in sorted(group, key=lambda row: row["iso_class_id"]):
            identity, p = task["iso_class_id"], task["p"]
            baseline = sorted(baseline_tasks.get((identity, p), []), key=lambda row: row["task_id"])
            if not baseline or any(row["budget"] != task["budget"] for row in baseline):
                raise ValueError("Warm comparison needs a planned B1 pool with exactly the same optimizer budget.")
            reference = references.get((identity, p))
            if reference and any(reference.get(name) != value for name, value in
                                 (("library_id", library["library_id"]), ("iso_class_id", identity), ("p", p))):
                raise ValueError("Warm reference and target graph/depth identities disagree.")
            if (identity, p) not in evaluated_b1:
                evaluated_b1[identity, p] = [_warm_restart(row, b1_selected.get(row["task_id"]), reference,
                                                         graphs[identity], settings["success_metric"]) for row in baseline]
                restarts.extend(evaluated_b1[identity, p])
            warm = _warm_restart(task, selected.get(task["task_id"]), reference, graphs[identity], settings["success_metric"])
            restarts.append(warm)
            b1, b2 = _warm_pool(evaluated_b1[identity, p]), _warm_pool([warm])
            row = {**metadata, "library_id": library["library_id"], "iso_class_id": identity,
                   "graph_split": graphs[identity]["graph_split"], "n": graphs[identity]["n"],
                   "reference_id": reference.get("reference_id") if reference else None,
                   "B1": b1, "B2": b2, "complete": b1["complete"] and b2["complete"],
                   "provisional": not (b1["complete"] and b2["complete"]),
                   "budget": task["budget"]}
            paired.append(row)
            graph_rows.append(row)
        if include_comparisons:
            comparisons.append({**metadata, **_warm_comparison(paired, settings)})
    used = {row["task_id"] for row in restarts}
    return {"analysis_version": WARM_ANALYSIS_VERSION, "settings": settings, "library_id": library["library_id"],
            "graph_qaoa": graph_rows, "restarts": restarts, "diagnostics": [], "comparisons": comparisons,
            "complete": bool(graph_rows) and all(row["complete"] for row in graph_rows),
            "selected_costs_by_method": {method: _costs([attempt for identity, attempt in attempts.items() if identity in used])
                                         for method, attempts in (("B1", b1_selected), ("B2", selected))}}


B3_ANALYSIS_VERSION = "plan-a-b3-comparison-v2"


def _b3_pool(rows, method):
    pool = _warm_pool(rows)
    calls = _costs(rows)["objective_calls"]
    pool["metrics"]["objective_calls"] = calls / len(rows) if calls is not None else None
    if method == "B1":
        pool["terminal_success_wilson95_restarts"] = (
            wilson_interval(sum(row["terminal_success"] is True for row in rows), len(rows))
            if pool["complete"] else None)
    return pool


def _b3_success_intervals(rows, method, settings):

    pools = [row[method] for row in rows]
    values = [pool["metrics"]["terminal_success_fraction"] for pool in pools]
    ready = all(_finite(value) for value in values)
    complete = all(row["complete"] for row in rows)
    result = {"planned_graphs": len(rows), "complete": complete,
              "fraction": math.fsum(values) / len(rows) if ready else None}
    if method == "B1":
        draws = np.random.default_rng(settings["bootstrap_seed"]).integers(
            len(rows), size=(settings["bootstrap_samples"], len(rows))) if complete and len(rows) > 1 else None
        result.update(graph_bootstrap_ci95=np.quantile(np.asarray(values)[draws].mean(axis=1), [0.025, 0.975]).tolist()
                      if ready and draws is not None else None,
                      scope="equal graph weights over within-graph random-restart fractions; no pooled binomial interval")
    else:
        successes = sum(int(value) for value in values) if ready else None
        result.update(known_successes=successes,
                      wilson95_nominal=wilson_interval(successes, len(rows)) if ready and complete else None,
                      scope="nominal independent-graph Bernoulli approximation; stratified-design coverage not guaranteed")
    return result


def build_b3_summary(library: dict, tasks: list[dict], selected: dict, references: dict, *,
                     b1_tasks: list[dict], b1_selected: dict, b2_tasks: list[dict],
                     b2_selected: dict, settings: dict | None = None) -> dict:


    warm = build_warm_summary(library, b2_tasks, b2_selected, references,
                             b1_tasks=b1_tasks, b1_selected=b1_selected, settings=settings,
                             include_comparisons=False)
    settings = warm["settings"]
    graphs = {row["iso_class_id"]: row for row in library["graphs"]
              if row["tier"] == 2 and row["graph_split"] == "evaluation"}
    depths = {task["p"] for task in tasks}
    lookup = {(task["iso_class_id"], task["p"]): task for task in tasks}
    identities = {task["task_id"] for task in tasks}
    if (not depths or not depths <= {1, 2} or len(lookup) != len(tasks) or len(identities) != len(tasks)
            or set(selected) - identities or identities & {row["task_id"] for row in warm["restarts"]}
            or set(lookup) != {(identity, p) for identity in graphs for p in depths}):
        raise ValueError("B3 requires exactly one global task per evaluation graph/depth and distinct planned identities.")
    rules = defaultdict(set)
    b3_rows = []
    for key, task in sorted(lookup.items()):
        reference = references.get(key)
        if (task["library_id"] != library["library_id"] or task["graph_split"] != "evaluation"
                or task["method"] != "B3" or task["kind"] != "optimization" or task["experiment_role"] != "warm_start"
                or task["restart_id"] != 0 or not task.get("rule_id") or not task.get("initialization_id")
                or (reference is not None and task.get("reference_id") != reference.get("reference_id"))
                or (task["task_id"] in selected and selected[task["task_id"]]["task_id"] != task["task_id"])):
            raise ValueError("B3 task, rule, initialization, reference or selected attempt identity disagrees.")
        rules[task["p"]].add(task["rule_id"])
        row = _warm_restart(task, selected.get(task["task_id"]), reference, graphs[key[0]], settings["success_metric"])
        row.update({name: task.get(name) for name in ("rule_id", "initialization_id", "initialization_set_id")})
        b3_rows.append(row)
    if any(len(values) != 1 for values in rules.values()):
        raise ValueError("B3 requires one frozen rule per depth.")

    restart_rows = {row["task_id"]: row for row in (*warm["restarts"], *b3_rows)}
    b1_groups, scopes = defaultdict(list), defaultdict(list)
    for row in warm["restarts"]:
        if row["method"] == "B1":
            b1_groups[row["iso_class_id"], row["p"]].append(row)
    for task in b2_tasks:
        scopes[task["regime"], task["fold"]].append(task)
    if ("random", None) not in scopes:
        raise ValueError("B3 comparison requires the declared random B2 case.")
    b3_pools = {(row["iso_class_id"], row["p"]): _b3_pool([row], "B3") for row in b3_rows}
    b1_pools = {key: _b3_pool(rows, "B1") for key, rows in b1_groups.items()}
    graph_rows, comparisons = [], []
    for (regime, fold), group in sorted(scopes.items(), key=lambda item: repr(item[0])):
        expected = {identity for identity, graph in graphs.items() if regime == "random"
                    or (graph["lofo_eligible"] and graph["families"] == [fold])}
        indexed = {(task["iso_class_id"], task["p"], task["variant"]): task for task in group}
        if (not expected or len({task["fit_id"] for task in group}) != 1 or len(indexed) != len(group)
                or set(indexed) != {(identity, p, variant) for identity in expected for p in depths
                                    for variant in ("medoid", "aligned_median")}):
            raise ValueError("Each B2 case must provide both variants and every declared graph/depth under one fit.")
        for p in sorted(depths):
            for method, variant in (("B1", None), ("B2", "medoid"), ("B2", "aligned_median")):
                metadata = {"regime": regime, "fold": fold, "p": p, "baseline_method": method,
                            "variant": variant, "fit_id": group[0]["fit_id"] if method == "B2" else None,
                            "rule_id": next(iter(rules[p]))}
                paired = []
                for identity in sorted(expected):
                    task = lookup[identity, p]
                    b2 = indexed[identity, p, variant or "medoid"]
                    if b2["budget"] != task["budget"]:
                        raise ValueError("B3 and its B1/B2 comparison need identical optimizer budgets.")
                    baseline = (b1_pools[identity, p] if method == "B1"
                                else _b3_pool([restart_rows[b2["task_id"]]], "B2"))
                    b3 = b3_pools[identity, p]
                    row = {**metadata, "library_id": library["library_id"], "iso_class_id": identity,
                           "graph_split": "evaluation", "n": graphs[identity]["n"],
                           "reference_id": restart_rows[task["task_id"]]["reference_id"],
                           method: baseline, "B3": b3, "budget": task["budget"],
                           "complete": baseline["complete"] and b3["complete"],
                           "provisional": not (baseline["complete"] and b3["complete"])}
                    paired.append(row)
                    graph_rows.append(row)
                comparison = _warm_comparison(paired, settings, baseline_method=method, warm_method="B3",
                                               metrics_names=(*_WARM_METRICS, "objective_calls"))
                comparison["success_intervals"] = {name: _b3_success_intervals(paired, name, settings)
                                                   for name in (method, "B3")}
                comparisons.append({**metadata, **comparison})
    used = set(restart_rows)
    selected_inputs = (("B1", b1_tasks, b1_selected), ("B2", b2_tasks, b2_selected), ("B3", tasks, selected))
    return {"analysis_version": B3_ANALYSIS_VERSION, "settings": settings, "library_id": library["library_id"],
            "graph_qaoa": graph_rows, "restarts": list(restart_rows.values()), "diagnostics": [],
            "comparisons": comparisons, "complete": all(row["complete"] for row in comparisons),
            "selected_costs_by_method": {method: _costs([row for identity, row in attempts.items() if identity in used])
                                         for method, _, attempts in selected_inputs},
            "selected_costs_by_method_depth": {
                method: {str(p): _costs([attempts[task["task_id"]] for task in planned if task["p"] == p
                                        and task["task_id"] in attempts and task["task_id"] in used]) for p in sorted(depths)}
                for method, planned, attempts in selected_inputs}}


B4_ANALYSIS_VERSION = "plan-a-b4-analysis-v2"
B5_ANALYSIS_VERSION = "plan-a-b5-analysis-v2"
_B4_CASE_FIELDS = ("regime", "fold", "p", "feature_group", "shuffle_seed")


def _prediction_comparison(rows, settings, baseline="constant", warm_method="B4"):

    complete = bool(rows) and all(row["observed"] is not None for row in rows)
    draws = np.random.default_rng(settings["bootstrap_seed"]).integers(
        len(rows), size=(settings["bootstrap_samples"], len(rows))) if complete and len(rows) > 1 else None
    metrics = {}
    for name in ("rmse", "mae"):
        def score(errors, axis=None):
            return np.sqrt(np.mean(errors**2, axis=axis)) if name == "rmse" else np.mean(np.abs(errors), axis=axis)
        values, intervals, errors = {}, {}, {}
        for method in (warm_method, baseline):
            errors[method] = (np.asarray([row[method] - row["observed"] for row in rows])
                              if complete else None)
            values[method] = float(score(errors[method])) if complete else None
            intervals[method] = (np.quantile(score(errors[method][draws], axis=1), [0.025, 0.975]).tolist()
                                 if draws is not None else None)
        difference = values[warm_method] - values[baseline] if complete else None
        paired = (score(errors[warm_method][draws], axis=1) - score(errors[baseline][draws], axis=1)
                  if draws is not None else None)
        metrics[name] = {**values, f"difference_{warm_method}_minus_{baseline}": difference,
                         "ci95": intervals, "paired_bootstrap_ci95": np.quantile(paired, [0.025, 0.975]).tolist()
                         if paired is not None else None,
                         "ci_status": "provisional" if not complete else "available" if draws is not None else "fewer_than_two_graphs"}
    return {"graphs": len(rows), "valid_labels": sum(row["observed"] is not None for row in rows),
            "complete": complete, "provisional": not complete, "metrics": metrics,
            "bootstrap": {"unit": "paired iso_class_id", "seed": settings["bootstrap_seed"],
                          "samples": settings["bootstrap_samples"], "interval": "percentile 95%",
                          "scope": "unstratified graphs; fixed predictions and training mean; RMSE recalculated per draw"},
            "target": "observed s/50, not noiseless latent success probability"}


def _build_learning_summary(library, tasks, selected, references, *, b1_tasks, b1_selected,
                     b2_tasks, b2_selected, b3_tasks, b3_selected, predictions,
                     success_models, settings=None, warm_method="B4"):


    from .learning import select_b2_graphs

    settings = _warm_settings(settings)
    graphs = {g["iso_class_id"]: g for g in library["graphs"]
              if g["tier"] == 2 and g["graph_split"] == "evaluation"}
    models = {}
    for model in success_models:
        if resolve_success_metric(model.get("success_metric", LEGACY_SUCCESS_METRIC)) != settings["success_metric"]:
            raise ValueError("Success-model metric differs from analysis; use matching re-scored labels and fits.")
        key = (model["regime"], model["fold"], model["p"], model["group"], model["shuffle_seed"])
        if (key in models or model["head"] != "success" or model["p"] not in (1, 2)
                or model["group"] not in ("L", "U", "F", "J+U", "J+U+S")
                or not _finite(model["training_mean"]) or not 0 <= model["training_mean"] <= 1
                or (model["shuffle_seed"] is not None and
                    (key[:2] != ("random", None) or model["group"] != "F"
                     or model["shuffle_seed"] not in (20260922, 20260923, 20260924)))):
            raise ValueError(f"Invalid or duplicate {warm_method} success-model case.")
        models[key] = model
    if not models or len({model["fit_id"] for model in models.values()}) != len(models):
        raise ValueError(f"{warm_method} needs distinct frozen success models declaring every planned case.")
    expected = {key: {g["iso_class_id"] for g in select_b2_graphs(library, key[0], key[1], "evaluation")}
                for key in models}
    if any(not ids for ids in expected.values()):
        raise ValueError(f"A declared {warm_method} case has no eligible evaluation graphs.")
    target_pairs = {(identity, key[2]) for key, ids in expected.items() for identity in ids}
    by_method, seen = {}, set()
    for method, planned, attempts in (("B1", b1_tasks, b1_selected), ("B2", b2_tasks, b2_selected),
                                     ("B3", b3_tasks, b3_selected), (warm_method, tasks, selected)):
        identities = {task["task_id"] for task in planned}
        if len(identities) != len(planned) or identities & seen or set(attempts) - identities:
            raise ValueError(f"{warm_method} comparison has duplicate or unplanned task identities.")
        seen.update(identities)
        rows = []
        for task in sorted(planned, key=lambda row: row["task_id"]):
            identity, p = task["iso_class_id"], task["p"]
            ref, attempt = references.get((identity, p)), attempts.get(task["task_id"])
            if (identity not in graphs or (identity, p) not in target_pairs or task["method"] != method
                    or task["library_id"] != library["library_id"] or task["graph_split"] != "evaluation"
                    or task["kind"] != "optimization"
                    or task["experiment_role"] != ("evaluation" if method == "B1" else "warm_start")
                    or (method != "B1" and task["restart_id"] != 0)
                    or (attempt is not None and attempt["task_id"] != task["task_id"])):
                raise ValueError(f"{warm_method} comparison task/attempt identity, split or role disagrees.")
            if ref is not None and (any(ref.get(name) != value for name, value in
                    (("library_id", library["library_id"]), ("iso_class_id", identity), ("p", p)))
                    or (method != "B1" and task.get("reference_id") != ref.get("reference_id"))):
                raise ValueError(f"{warm_method} comparison scoring reference disagrees.")
            row = _warm_restart(task, attempt, ref, graphs[identity], settings["success_metric"])
            row.update({name: task.get(name) for name in (*_B4_CASE_FIELDS, "prediction_id")})
            if method == "B3":
                row.update({name: task.get(name) for name in ("rule_id", "initialization_id", "initialization_set_id")})
            rows.append(row)
        by_method[method] = rows
    baseline_groups = defaultdict(list)
    for method in ("B1", "B2", "B3"):
        for row in by_method[method]:
            scope = (row["regime"], row["fold"], row["variant"]) if method == "B2" else (None, None, None)
            baseline_groups[method, *scope, row["iso_class_id"], row["p"]].append(row)
    required = {("B1", None, None, None, identity, p) for identity, p in target_pairs}
    required |= {("B3", None, None, None, identity, p) for identity, p in target_pairs}
    required |= {("B2", key[0], key[1], variant, identity, key[2]) for key, ids in expected.items()
                 for identity in ids for variant in ("medoid", "aligned_median")}
    if set(baseline_groups) != required:
        raise ValueError(f"{warm_method} comparison requires every declared B1/B2/B3 baseline graph/depth.")
    baseline_pools, labels = {}, {}
    for key, rows in baseline_groups.items():
        if (len(rows) != (50 if key[0] == "B1" else 1)
                or (key[0] == "B1" and {row["restart_id"] for row in rows} != set(range(50)))):
            raise ValueError(f"{warm_method} needs all 50 planned B1 restarts and one B2/B3 start per variant.")
        baseline_pools[key] = _b3_pool(rows, key[0])
        if key[0] == "B1":
            labels[key[-2:]] = pool_statistics(rows)
    prediction_by_id = {row["prediction_id"]: row for row in predictions}
    if len(prediction_by_id) != len(predictions) or set(prediction_by_id) != {t["prediction_id"] for t in tasks}:
        raise ValueError(f"{warm_method} prediction coverage differs from its task plan.")
    groups = defaultdict(dict)
    for row in by_method[warm_method]:
        key = tuple(row[name] for name in _B4_CASE_FIELDS)
        if key not in models or row["iso_class_id"] in groups[key]:
            raise ValueError(f"Duplicate or undeclared {warm_method} graph/model case.")
        groups[key][row["iso_class_id"]] = row
    if set(groups) != set(models) or any(set(groups[key]) != ids for key, ids in expected.items()):
        raise ValueError(f"{warm_method} tasks omit or add a declared model or evaluation graph.")
    graph_rows, diagnostics, comparisons, prediction_comparisons = [], [], [], []
    warm_pools, prediction_rows = {}, {}
    for key, group in sorted(groups.items(), key=lambda item: repr(item[0])):
        model = models[key]
        fit_ids = {row["fit_id"] for row in group.values()}
        if len(fit_ids) != 1 or None in fit_ids:
            raise ValueError(f"Each {warm_method} case requires one frozen angle fit.")
        metadata = {**dict(zip(_B4_CASE_FIELDS, key)), "fit_id": next(iter(fit_ids)),
                    "success_fit_id": model["fit_id"]}
        pools, success_rows = {}, []
        for identity, row in sorted(group.items()):
            prediction = prediction_by_id[row["prediction_id"]]
            if (prediction["fit_id"] != row["fit_id"] or prediction["success_fit_id"] != model["fit_id"]
                    or resolve_success_metric(prediction.get("success_metric", LEGACY_SUCCESS_METRIC)) != settings["success_metric"]
                    or prediction["iso_class_id"] != identity or prediction["theta0"] != row["theta0"]
                    or any(prediction[name] != row[name] for name in _B4_CASE_FIELDS)
                    or np.shape(prediction["rho"]) != (2 * key[2],)
                    or not all(_finite(v) and v >= 0 for v in prediction["rho"])
                    or type(prediction["fallback"]) is not bool
                    or not _finite(prediction["success_probability"])
                    or not 0 <= prediction["success_probability"] <= 1
                    or type(prediction["unseen_type_count"]) is not int or prediction["unseen_type_count"] < 0
                    or not _finite(prediction["unseen_type_fraction"]) or not 0 <= prediction["unseen_type_fraction"] <= 1):
                raise ValueError(f"{warm_method} frozen prediction, model or diagnostics disagree.")
            pools[identity] = _b3_pool([row], warm_method)
            label = labels[identity, key[2]]
            graph_rows.append({**metadata, "iso_class_id": identity, "n": graphs[identity]["n"],
                "library_id": library["library_id"], "graph_split": "evaluation", "reference_id": row["reference_id"],
                warm_method: pools[identity], "complete": pools[identity]["complete"], "provisional": pools[identity]["provisional"]})
            diagnostics.append({**metadata, "iso_class_id": identity, "task_id": row["task_id"],
                "prediction_id": row["prediction_id"], **{name: prediction[name] for name in
                    ("rho", "fallback", "trigger_coordinates", "unseen_type_count", "unseen_type_fraction", "success_probability")},
                "observed_success": label, "training_mean": model["training_mean"]})
            success_rows.append({"iso_class_id": identity, "observed": label["success_rate_label"],
                                 warm_method: prediction["success_probability"], "constant": model["training_mean"]})
        warm_pools[key], prediction_rows[key] = pools, success_rows
        prediction_comparisons.append({**metadata, **_prediction_comparison(success_rows, settings, warm_method=warm_method)})
        for method, variant in (("B1", None), ("B2", "medoid"), ("B2", "aligned_median"), ("B3", None)):
            pairs = []
            for identity, pool in pools.items():
                base_key = (method, key[0] if method == "B2" else None,
                            key[1] if method == "B2" else None, variant, identity, key[2])
                if any(base["budget"] != group[identity]["budget"] for base in baseline_groups[base_key]):
                    raise ValueError(f"{warm_method} and baseline optimizer budgets differ.")
                base = baseline_pools[base_key]
                pairs.append({method: base, warm_method: pool, "complete": base["complete"] and pool["complete"]})
            comparison = _warm_comparison(pairs, settings, baseline_method=method, warm_method=warm_method,
                                           metrics_names=(*_WARM_METRICS, "objective_calls"))
            comparisons.append({**metadata, "baseline_method": method, "baseline_variant": variant,
                "primary": key[0] == "random" and key[3:] == ("F", None), **comparison,
                "success_intervals": {name: _b3_success_intervals(pairs, name, settings) for name in (method, warm_method)}})
    feature_comparisons, success_feature_comparisons = [], []
    for key in groups:
        controls = [(key[3], seed) for seed in (20260922, 20260923, 20260924)] if key[3:] == ("F", None) else []
        if key[4] is None and key[3] in ("F", "J+U+S"):
            controls.append(("U" if key[3] == "F" else "J+U", None))
        for feature, shuffle in controls:
            other = (*key[:3], feature, shuffle)
            if other not in groups:
                continue
            pairs = [{warm_method: warm_pools[key][identity], f"{warm_method}_control": warm_pools[other][identity],
                      "complete": warm_pools[key][identity]["complete"] and warm_pools[other][identity]["complete"]}
                     for identity in sorted(expected[key])]
            metadata = {**dict(zip(_B4_CASE_FIELDS, key)), "fit_id": next(iter(groups[key].values()))["fit_id"],
                        "success_fit_id": models[key]["fit_id"], "baseline_success_fit_id": models[other]["fit_id"],
                        "baseline_feature_group": feature, "baseline_shuffle_seed": shuffle,
                        "baseline_fit_id": next(iter(groups[other].values()))["fit_id"],
                        "comparison_kind": "shuffled_control" if shuffle is not None else "feature_group"}
            feature_comparisons.append({**metadata, **_warm_comparison(pairs, settings,
                baseline_method=f"{warm_method}_control", warm_method=warm_method, metrics_names=(*_WARM_METRICS, "objective_calls"))})
            control = {row["iso_class_id"]: row[warm_method] for row in prediction_rows[other]}
            paired_predictions = [{**row, f"{warm_method}_control": control[row["iso_class_id"]]} for row in prediction_rows[key]]
            success_feature_comparisons.append({**metadata, **_prediction_comparison(
                paired_predictions, settings, baseline=f"{warm_method}_control", warm_method=warm_method)})
    complete = all(row["complete"] for row in (*comparisons, *prediction_comparisons))
    return {"analysis_version": B4_ANALYSIS_VERSION if warm_method == "B4" else B5_ANALYSIS_VERSION, "library_id": library["library_id"], "settings": settings,
            "graph_qaoa": graph_rows, "restarts": [row for rows in by_method.values() for row in rows],
            "diagnostics": diagnostics, "comparisons": comparisons, "feature_comparisons": feature_comparisons,
            "success_prediction_comparisons": prediction_comparisons,
            "success_feature_comparisons": success_feature_comparisons, "complete": complete, "provisional": not complete,
            "uncertainty_scope": "unstratified graph bootstrap conditional on frozen fits; no training resampling or simultaneous coverage"}


def build_b4_summary(library, tasks, selected, references, *, b1_tasks, b1_selected,
                     b2_tasks, b2_selected, b3_tasks, b3_selected, predictions,
                     success_models, settings=None):

    return _build_learning_summary(library, tasks, selected, references, b1_tasks=b1_tasks,
        b1_selected=b1_selected, b2_tasks=b2_tasks, b2_selected=b2_selected,
        b3_tasks=b3_tasks, b3_selected=b3_selected, predictions=predictions,
        success_models=success_models, settings=settings)


def _b5_shap_summary(predictions, explanations, success_models):


    models = {model["fit_id"]: model for model in success_models
              if model["group"] == "F" and model["shuffle_seed"] is None}
    expected = {row["prediction_id"]: row for row in predictions if row["success_fit_id"] in models}
    groups, seen = defaultdict(list), set()
    for row in explanations:
        identity = row["prediction_id"]
        prediction = expected.get(identity)
        if (identity in seen or prediction is None
                or any(row.get(name) != prediction.get(name) for name in
                       ("success_fit_id", "iso_class_id", *_B4_CASE_FIELDS))):
            raise ValueError("B5 SHAP has duplicate, unplanned or mismatched prediction/model identities.")
        seen.add(identity)
        columns, values = row["columns"], np.asarray(row["contributions"], dtype=float)
        raw, bias = row["raw_prediction"], row["bias"]
        if (columns != models[row["success_fit_id"]]["feature_names"]
                or resolve_success_metric(row.get("success_metric", LEGACY_SUCCESS_METRIC)) !=
                    resolve_success_metric(models[row["success_fit_id"]].get("success_metric", LEGACY_SUCCESS_METRIC))
                or not columns or len(set(columns)) != len(columns) or not all(isinstance(c, str) for c in columns)
                or values.shape != (len(columns),) or not np.all(np.isfinite(values))
                or not _finite(raw) or not _finite(bias) or not _finite(row["additivity_error"])
                or raw != prediction["raw_success_prediction"]
                or prediction["success_probability"] != min(1., max(0., raw))):
            raise ValueError("B5 SHAP values, original column names or raw/clipped frozen prediction disagree.")
        error = abs(float(bias + math.fsum(values)) - raw)
        if error > 1e-5 + 1e-6 * abs(raw) or not math.isclose(error, row["additivity_error"], abs_tol=1e-12):
            raise ValueError("B5 native SHAP contributions do not add to the raw output within the fixed tolerance.")
        group = groups[row["success_fit_id"]]
        if group and group[0]["columns"] != columns:
            raise ValueError("B5 SHAP feature order differs within one frozen model.")
        group.append(row)
    summaries = []
    for fit_id, model in sorted(models.items()):
        rows = groups[fit_id]
        planned = sum(row["success_fit_id"] == fit_id for row in expected.values())
        values = np.asarray([row["contributions"] for row in rows], dtype=float)
        raw = [row["raw_prediction"] for row in rows]
        summaries.append({"success_fit_id": fit_id,
            **{name: model[name] for name in ("regime", "fold", "p", "shuffle_seed")}, "feature_group": "F",
            "planned_graphs": planned, "observed_graphs": len(rows), "complete": len(rows) == planned,
            "columns": rows[0]["columns"] if rows else None,
            "mean_absolute_contribution": np.mean(abs(values), axis=0).tolist() if rows else None,
            "mean_signed_contribution": np.mean(values, axis=0).tolist() if rows else None,
            "signed_quantiles": {str(q): np.quantile(values, q, axis=0).tolist() for q in (0., .25, .5, .75, 1.)}
                                if rows else None,
            "raw_range": [min(raw), max(raw)] if rows else None,
            "clipped_predictions": sum(value < 0 or value > 1 for value in raw),
            "maximum_additivity_error": max(row["additivity_error"] for row in rows) if rows else None,
            "interpretation": "raw margin; native training-path/cover tree attribution, not clipped probability or causal effect"})
    return summaries, {"planned_models": len(models), "observed_models": sum(bool(rows) for rows in groups.values()),
        "planned_rows": len(expected), "observed_rows": len(seen),
        "missing_prediction_ids": sorted(set(expected) - seen), "complete": set(expected) == seen}


def build_b5_summary(library, tasks, selected, references, *, b1_tasks, b1_selected,
                     b2_tasks, b2_selected, b3_tasks, b3_selected, predictions, success_models,
                     b4_tasks, b4_selected, b4_predictions, b4_success_models, explanations, settings=None):


    common = dict(b1_tasks=b1_tasks, b1_selected=b1_selected, b2_tasks=b2_tasks,
                  b2_selected=b2_selected, b3_tasks=b3_tasks, b3_selected=b3_selected, settings=settings)
    summary = _build_learning_summary(library, tasks, selected, references, predictions=predictions,
        success_models=success_models, warm_method="B5", **common)
    prediction_by_id = {row["prediction_id"]: row for row in predictions}
    models_by_id = {row["fit_id"]: row for row in success_models}
    for diagnostic in summary["diagnostics"]:
        prediction = prediction_by_id[diagnostic["prediction_id"]]
        raw = prediction["raw_success_prediction"]
        if not _finite(raw) or prediction["success_probability"] != min(1., max(0., raw)):
            raise ValueError("B5 raw success prediction and clipped probability disagree.")
        columns = models_by_id[prediction["success_fit_id"]]["feature_names"]
        coordinates = prediction["out_of_training_range_coordinates"]
        conversion = prediction["float32_conversion"]
        if (not columns or any(type(i) is not int or not 0 <= i < len(columns) for i in coordinates)
                or coordinates != sorted(set(coordinates))
                or prediction["out_of_training_range_features"] != [columns[i] for i in coordinates]
                or type(prediction["out_of_training_range_count"]) is not int
                or prediction["out_of_training_range_count"] != len(coordinates)
                or prediction["out_of_training_range_fraction"] != len(coordinates) / len(columns)
                or set(conversion) != {"feature_float32_max_abs_error"}
                or not _finite(conversion["feature_float32_max_abs_error"])
                or conversion["feature_float32_max_abs_error"] < 0):
            raise ValueError("B5 training-range or float32 feature diagnostics disagree with frozen columns.")
        diagnostic.update(raw_success_prediction=raw, success_prediction_clipped=raw < 0 or raw > 1,
            **{name: prediction[name] for name in ("out_of_training_range_coordinates", "out_of_training_range_features",
               "out_of_training_range_count", "out_of_training_range_fraction", "float32_conversion")})
    keys = {tuple(row[name] for name in _B4_CASE_FIELDS) for row in tasks}
    matched_tasks = [row for row in b4_tasks if tuple(row[name] for name in _B4_CASE_FIELDS) in keys]
    matched_ids = {row["task_id"] for row in matched_tasks}
    if (matched_ids & {row["task_id"] for row in tasks}
            or set(b4_selected) - {row["task_id"] for row in b4_tasks}):
        raise ValueError("B5/B4 task identities overlap or B4 has unplanned attempts.")
    prediction_ids = {row["prediction_id"] for row in matched_tasks}
    matched_models = [model for model in b4_success_models if
        (model["regime"], model["fold"], model["p"], model["group"], model["shuffle_seed"]) in keys]
    baseline = build_b4_summary(library, matched_tasks,
        {identity: row for identity, row in b4_selected.items() if identity in matched_ids}, references,
        predictions=[row for row in b4_predictions if row["prediction_id"] in prediction_ids],
        success_models=matched_models, **common)
    settings = summary["settings"]

    def identity(row):
        return (*(row[name] for name in _B4_CASE_FIELDS), row["iso_class_id"])

    b4_rows = {identity(row): row for row in baseline["graph_qaoa"]}
    b4_diagnostics = {identity(row): row for row in baseline["diagnostics"]}
    b5_diagnostics = {identity(row): row for row in summary["diagnostics"]}
    if set(b4_rows) != {identity(row) for row in summary["graph_qaoa"]}:
        raise ValueError("B5 needs exactly matched B4 cases and evaluation graph coverage.")
    budgets = {identity(task): task["budget"] for task in matched_tasks}
    if any(task["budget"] != budgets[identity(task)] for task in tasks):
        raise ValueError("B5 and matched B4 optimizer budgets differ.")
    groups = defaultdict(list)
    for row in summary["graph_qaoa"]:
        groups[identity(row)[:-1]].append(row)
    for key, rows in sorted(groups.items(), key=lambda item: repr(item[0])):
        metadata = {name: rows[0][name] for name in (*_B4_CASE_FIELDS, "fit_id", "success_fit_id")}
        pairs, prediction_pairs = [], []
        for row in rows:
            base = b4_rows[identity(row)]
            pairs.append({"B4": base["B4"], "B5": row["B5"],
                          "complete": base["complete"] and row["complete"]})
            diagnostic = b5_diagnostics[identity(row)]
            prediction_pairs.append({"iso_class_id": row["iso_class_id"],
                "observed": diagnostic["observed_success"]["success_rate_label"],
                "B5": diagnostic["success_probability"],
                "B4": b4_diagnostics[identity(row)]["success_probability"]})
        summary["comparisons"].append({**metadata, "baseline_method": "B4", "baseline_variant": None,
            "baseline_fit_id": b4_rows[identity(rows[0])]["fit_id"],
            "primary": key[0] == "random" and key[3:] == ("F", None),
            **_warm_comparison(pairs, settings, baseline_method="B4", warm_method="B5",
                               metrics_names=(*_WARM_METRICS, "objective_calls")),
            "success_intervals": {name: _b3_success_intervals(pairs, name, settings) for name in ("B4", "B5")}})
        summary["success_prediction_comparisons"].append({**metadata, "baseline_method": "B4",
            "baseline_success_fit_id": b4_rows[identity(rows[0])]["success_fit_id"],
            **_prediction_comparison(prediction_pairs, settings, baseline="B4", warm_method="B5")})
    for row in summary["success_prediction_comparisons"]:
        row.setdefault("baseline_method", "constant")
    summary["restarts"].extend(row for row in baseline["restarts"] if row["method"] == "B4")
    summary["grouped_comparisons"] = _b5_grouped_comparisons(library, summary, b4_rows)
    summary["shap_summaries"], summary["shap_coverage"] = _b5_shap_summary(predictions, explanations, success_models)
    summary["warm_compute_complete"] = all(row["complete"] for row in summary["graph_qaoa"])
    summary["analysis_complete"] = (all(row["complete"] for row in
        (*summary["comparisons"], *summary["success_prediction_comparisons"])) and summary["shap_coverage"]["complete"])
    summary["complete"] = summary["warm_compute_complete"] and summary["analysis_complete"]
    summary["provisional"] = not summary["complete"]
    return summary


def _b5_grouped_comparisons(library, summary, b4_rows):

    graphs = {row["iso_class_id"]: row for row in library["graphs"]}
    baselines = defaultdict(list)
    for row in summary["restarts"]:
        method = row["method"]
        if method in ("B1", "B3") or method == "B2" and row["regime"] == "random":
            baselines[method, row["variant"] if method == "B2" else None, row["iso_class_id"], row["p"]].append(row)
    strata = defaultdict(list)
    for row in summary["graph_qaoa"]:
        if (row["regime"], row["feature_group"], row["shuffle_seed"]) != ("random", "F", None):
            continue
        graph = graphs[row["iso_class_id"]]
        source = graph.get("provenance", [{}])[0]
        dimensions = {"n": graph["n"], "degree_band": source.get("target_degree", "unknown"),
                      "family": source.get("family", "+".join(graph["families"]))}
        for name, value in dimensions.items():
            strata[row["p"], name, str(value)].append(row)
    output = []
    for (p, dimension, value), rows in sorted(strata.items()):
        degrees = [2 * len(graphs[row["iso_class_id"]]["edges"]) / graphs[row["iso_class_id"]]["n"]
                   for row in rows if "edges" in graphs[row["iso_class_id"]]]
        for method, variant in (("B1", None), ("B2", "medoid"), ("B2", "aligned_median"), ("B3", None), ("B4", None)):
            pairs = []
            for row in rows:
                base = (b4_rows[(*(row[name] for name in _B4_CASE_FIELDS), row["iso_class_id"])]["B4"]
                        if method == "B4" else _b3_pool(baselines[method, variant, row["iso_class_id"], p], method))
                pairs.append({method: base, "B5": row["B5"], "complete": base["complete"] and row["complete"]})
            output.append({"p": p, "dimension": dimension, "value": value, "regime": "random", "feature_group": "F",
                "baseline_method": method, "baseline_variant": variant,
                "mean_actual_degree": math.fsum(degrees) / len(degrees) if len(degrees) == len(rows) else None,
                "interpretation": "descriptive representative-owner strata; no density adjustment, interactions or causal conclusion",
                **_warm_comparison(pairs, summary["settings"], baseline_method=method, warm_method="B5",
                                   metrics_names=(*_WARM_METRICS, "objective_calls"))})
    return output

import argparse
from collections import Counter, defaultdict
from contextlib import nullcontext
from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import signal
import sys

for name in ("OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"):
    os.environ[name] = "1"
if (Path.cwd() / "qaoa_study").is_dir():
    sys.path.insert(0, str(Path.cwd()))
else:
    for parent in Path(__file__).resolve().parents:
        if (parent / "qaoa_study").is_dir():
            sys.path.insert(0, str(parent))
            break

import numpy as np
from qaoa_study import experiments as exp
from qaoa_study.graphs import graph_from_record, graph_split_coverage
from qaoa_study.learning import b3_initialization
from qaoa_study.optimize import random_angles
from qaoa_study.parallel import ParallelSettings
from qaoa_study.records import execution_failed, read_json, save_library, write_once_json


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_inputs(data):
    if exp.digest({k: v for k, v in data.items() if k != "input_id"}) != data["input_id"]:
        raise ValueError("Input checksum changed; export a new input file.")
    graphs = {g["iso_class_id"]: g for g in data["library"]["graphs"]}
    ids = data["evaluation_graph_ids"]
    if ids != sorted(set(ids)) or any(graphs[g]["graph_split"] != "evaluation" for g in ids):
        raise ValueError("Preserve the original evaluation graph IDs and split.")
    keys = [(r["iso_class_id"], r["p"]) for r in data["scoring_references"]]
    if len(keys) != len(set(keys)):
        raise ValueError("Duplicate scoring references.")
    missing = data["missing_p12_graph_ids"]
    if sorted(g for g in ids if (g, 1) not in keys) != missing or sorted(g for g in ids if (g, 2) not in keys) != missing:
        raise ValueError("Missing p1/p2 reference coverage disagrees with its frozen scope.")
    if {g for g, p in keys if p == 3} != set(ids):
        raise ValueError("Require all existing p3 independent references.")


def build_quality_tasks(data, config):

    graphs = {g["iso_class_id"]: g for g in data["library"]["graphs"]}
    tasks = []
    for gid in data["evaluation_graph_ids"]:
        record = graphs[gid]
        for p in config["depths"]:
            b3 = b3_initialization(graph_from_record(record), p, rules=data["b3_rules"])
            for method, count in (("B1", config["evaluation_restarts"]), ("B3", 1)):
                for restart in range(count):
                    role = "evaluation" if method == "B1" else "warm_start"
                    stream = dict(namespace=config["seed_namespace"], master_seed=config["seed"],
                        library_id=data["library"]["library_id"], iso_class_id=gid, p=p,
                        experiment_role=role, restart_id=restart)
                    seed = int(exp.digest(stream)[:32], 16)
                    task = dict(task_version=exp.TASK_VERSION, library_id=data["library"]["library_id"],
                        iso_class_id=gid, n=record["n"], p=p, graph_split=record["graph_split"],
                        kind="optimization", experiment_role=role, pool="evaluation" if method == "B1" else None,
                        method=method, restart_id=restart, seed=seed,
                        theta0=random_angles(p, seed).tolist() if method == "B1" else b3["theta"],
                        budget=config["optimizer"][str(p)], protocol_version=config["protocol_version"])
                    if method == "B3":
                        task.update(rule_id=b3["rule_id"], initialization_id=exp.digest(b3))
                    task["task_id"] = exp.digest(task)
                    tasks.append(task)
    return sorted(tasks, key=lambda t: t["task_id"])


def save_quality_batch(directory, library_path, library, config, tasks):

    directory = Path(directory)
    content = "".join(json.dumps(t, sort_keys=True, allow_nan=False) + "\n" for t in tasks).encode()
    source = exp.source_identity()
    identity = dict(library_id=library["library_id"], config=config, source_id=source["source_id"],
                    tasks_sha256=hashlib.sha256(content).hexdigest())
    manifest = dict(**identity, batch_id=exp.digest(identity), source=source,
        library_path=os.path.relpath(Path(library_path).resolve(), directory.resolve()),
        library_manifest_sha256=sha(Path(library_path) / "manifest.json"),
        issues=exp.library_issues(library, config), task_count=len(tasks),
        counts=dict(Counter(t["experiment_role"] for t in tasks)),
        coverage=graph_split_coverage(library["graphs"], library.get("cells")), attempt_selection_rule=exp.ATTEMPT_RULE)
    if manifest["issues"]:
        raise ValueError(manifest["issues"])
    directory.mkdir(parents=True, exist_ok=False)
    (directory / "tasks.jsonl").write_bytes(content)
    write_once_json(directory / "manifest.json", manifest)
    exp.read_batch(directory)
    return manifest


def prepare(inputs_path, config_path, root):
    root = Path(root).resolve()
    if root.exists():
        raise FileExistsError("Choose a new output directory; old results are never replaced.")
    data, config = read_json(inputs_path), read_json(config_path)
    verify_inputs(data)
    exp.validate_config(config)
    if config["depths"] != [1, 2, 3] or len({exp.digest(v) for v in config["optimizer"].values()}) != 1:
        raise ValueError("All three depths must use identical optimization settings.")
    tasks = build_quality_tasks(data, config)
    ref_config = {**deepcopy(config), "kind": "matched-depth-missing-references", "depths": [1, 2],
        "seed_namespace": config["seed_namespace"] + "-independent-references",
        "reference_graph_ids": data["missing_p12_graph_ids"]}
    references = exp.build_tasks(data["library"], ref_config) if data["missing_p12_graph_ids"] else []
    seeds = [t["seed"] for t in tasks + references]
    if len(seeds) != len(set(seeds)) or set(seeds) & set(data["prior_seeds"]):
        raise ValueError("Seed streams overlap.")
    root.mkdir(parents=True)
    write_once_json(root / "inputs.json", data)
    save_library(root / "library", data["library"])
    batch = save_quality_batch(root / "quality-batch", root / "library", data["library"], config, tasks)
    batches = {"quality": batch["batch_id"]}
    if references:
        batch_ref = exp.save_batch(root / "references-batch", root / "library", ref_config)
        if batch_ref["issues"]:
            raise ValueError(batch_ref["issues"])
        batches["references"] = batch_ref["batch_id"]
    result = dict(input_id=data["input_id"], script_sha256=sha(__file__), batches=batches,
        quality_tasks=len(tasks), reference_tasks=len(references),
        optimizer_call_cap=sum(t["budget"]["max_evaluations"] for t in tasks + references if t["kind"] == "optimization"),
        analytic_grid_tasks=sum(t["kind"] == "p1_grid" for t in references),
        old_seed_overlap=0, primary="C_final/C_star; equal graph weights (equivalent to equal cell weights for this balanced96 cohort)",
        secondary="Reference success retains unequal historical reference efforts; not a pure depth comparison.")
    write_once_json(root / "preparation.json", result)
    return result


def read_root(root, phase):
    root = Path(root)
    data, prep = read_json(root / "inputs.json"), read_json(root / "preparation.json")
    verify_inputs(data)
    if sha(__file__) != prep["script_sha256"] or data["input_id"] != prep["input_id"]:
        raise ValueError("Frozen driver or inputs changed; use the original runtime.")
    manifest, library, tasks = exp.read_batch(root / (phase + "-batch"))
    if manifest["batch_id"] != prep["batches"][phase] or library != data["library"]:
        raise ValueError("Batch no longer matches the original library or preparation.")
    if phase == "quality" and tasks != build_quality_tasks(data, manifest["config"]):
        raise ValueError("Quality tasks disagree with the frozen graph-only initialization rules.")
    if phase == "references" and manifest["config"]["reference_graph_ids"] != data["missing_p12_graph_ids"]:
        raise ValueError("Missing-reference graph scope changed.")
    return data, manifest, library, tasks


def observations(root, phase, metadata_only=True):
    data, manifest, library, tasks = read_root(root, phase)
    output = Path(root) / (phase + "-attempts")
    attempts = exp.load_attempts(manifest, tasks, output, metadata_only=metadata_only)[0] if (output / "manifest.json").exists() else []
    return data, manifest, library, tasks, attempts, exp.select_attempts(attempts)


def status(root):
    result = {}
    for phase in read_json(Path(root) / "preparation.json")["batches"]:
        _, _, _, tasks, attempts, selected = observations(root, phase)
        valid = sum(not execution_failed(r) for r in selected.values())
        result[phase] = dict(planned=len(tasks), valid=valid, attempts=len(attempts),
            missing=len(tasks) - len(selected), unresolved_execution_faults=len(selected) - valid,
            complete=valid == len(tasks))
    result["stop_requested"] = (Path(root) / "stop.request").exists()
    return result


def run(root, phase, backend, workers, execute, max_tasks=None):
    root, stopped, previous = Path(root), [False], {}
    read_root(root, phase)
    with exp._writer_lock(root) if execute else nullcontext():
        if execute:
            (root / "stop.request").unlink(missing_ok=True)
            for number in (signal.SIGINT, signal.SIGTERM):
                previous[number] = signal.signal(number, lambda *_: stopped.__setitem__(0, True))
        try:
            result = exp.run_worker(root / (phase + "-batch"), root / (phase + "-attempts"),
                backend=backend, execute=execute, parallel=ParallelSettings(workers=workers), max_tasks=max_tasks,
                should_stop=lambda: stopped[0] or (root / "stop.request").exists(),
                progress=lambda r: print(json.dumps({k: r.get(k) for k in
                    ("executed", "valid_completed", "missing_tasks", "unresolved_execution_faults")}), flush=True))
            return {k: result.get(k) for k in ("dry_run", "planned", "executed", "valid_completed", "missing_tasks", "unresolved_execution_faults", "compute_started")}
        finally:
            for number, handler in previous.items():
                signal.signal(number, handler)


def summarize(root, output, overlays=None):

    data, manifest, library, tasks, quality_attempts, selected = observations(root, "quality", metadata_only=False)
    if any(t["task_id"] not in selected or execution_failed(selected[t["task_id"]]) for t in tasks):
        raise ValueError("Complete all quality tasks, including valid nonconverged runs, before summarizing.")
    references = {(r["iso_class_id"], r["p"]): r for r in data["scoring_references"]}
    if "references" in read_json(Path(root) / "preparation.json")["batches"]:
        _, rm, _, rt, reference_attempts, rs = observations(root, "references", metadata_only=False)
        fresh = exp.freeze_references(rm, rt, rs)
        if any(not r["complete"] for r in fresh.values()):
            raise ValueError("Complete the missing p1/p2 reference pool before the combined summary.")
        references.update(fresh)
    overlay_history, seen_sets = [], set()
    for overlay in overlays or []:
        added = exp.read_references(overlay)
        overlay_set_id = read_json(Path(overlay) / "manifest.json")["reference_set_id"]
        if overlay_set_id in seen_sets:
            continue
        seen_sets.add(overlay_set_id)
        decisions = []
        for ref in added.values():
            key = ref["iso_class_id"], ref["p"]
            if key not in references or ref["p"] != 3 or not ref["complete"]:
                raise ValueError("Overlay must contain complete p3 references on these graphs.")
            old = references[key]
            improved = ref["C_ref"] > old["C_ref"]
            decisions.append(dict(iso_class_id=key[0], previous_reference_id=old.get("reference_id", old.get("scoring_reference_id")),
                candidate_reference_id=ref["reference_id"], improved=improved))
            if improved:
                references[key] = ref
        overlay_history.append(dict(reference_set_id=overlay_set_id, decisions=decisions, references=list(added.values())))
    graphs = {g["iso_class_id"]: g for g in library["graphs"]}
    rows, grouped = [], defaultdict(list)
    for task in tasks:
        r = selected[task["task_id"]]
        gid, p = task["iso_class_id"], task["p"]
        star, ref = graphs[gid]["C_star"], references[gid, p]
        trace = [v for v in r["trace"] if v["valid"]]
        threshold = ref["C_ref"] - .01 * star
        first = next((v["call_id"] for v in trace if v["C"] >= threshold), None)
        row = dict(task_id=task["task_id"], attempt_id=r["attempt_id"], graph=gid, p=p, method=task["method"],
            cell=graphs[gid]["representative_cell"], quality=r["C_final"] / star,
            initial_quality=trace[0]["C"] / star, best_quality=r["best_seen"] / star,
            success=int(r["C_final"] >= threshold), initial_success=int(trace[0]["C"] >= threshold),
            first_hit=first, calls=r["counts"]["objective_calls"], elapsed_seconds=r["elapsed_seconds"],
            reference_id=ref.get("reference_id", ref.get("scoring_reference_id")),
            reference_exceeded=int(r["best_seen"] > ref["C_ref"] + 1e-8), stop_reason=r["stop_reason"])
        rows.append(row)
        grouped[gid, p, task["method"]].append(row)
    metrics = ("quality", "initial_quality", "best_quality", "success", "initial_success", "calls", "elapsed_seconds", "reference_exceeded")
    graph_rows = [dict(graph=g, p=p, method=m, cell=rr[0]["cell"], repeats=len(rr),
        first_hits=[r["first_hit"] for r in rr], **{k: float(np.mean([r[k] for r in rr])) for k in metrics})
        for (g, p, m), rr in grouped.items()]
    pairs = []
    rng = np.random.default_rng(manifest["config"]["analysis"]["bootstrap_seed"])
    for method in ("B1", "B3"):
        by_key = {(r["graph"], r["p"]): r for r in graph_rows if r["method"] == method}
        for lower, upper in ((1, 2), (2, 3), (1, 3)):
            cells = defaultdict(list)
            for gid in data["evaluation_graph_ids"]:
                cells[by_key[gid, lower]["cell"]].append(by_key[gid, upper]["quality"] - by_key[gid, lower]["quality"])
            samples = np.sum([np.sum(rng.choice(v, size=(2000, len(v)), replace=True), axis=1) for v in cells.values()], axis=0) / len(data["evaluation_graph_ids"])
            pairs.append(dict(method=method, lower=lower, upper=upper,
                quality_gain=float(np.mean([value for values in cells.values() for value in values])),
                equal_cell_sensitivity=float(np.mean([np.mean(v) for v in cells.values()])),
                paired_graph_bootstrap95=np.quantile(samples, [.025, .975]).tolist()))
    result = dict(batch_id=manifest["batch_id"], input_id=data["input_id"], reference_overlays=overlay_history,
        convention="Equal graphs; B1 repeats averaged within graph. Equal cell weighting is equivalent in this balanced96 cohort and is reported as a sensitivity check. Paired graph bootstrap within cell, 2000 draws.",
        interpretation="Quality under equal objective-call budgets. Depth changes gate work and wall time. Reference-success histories have unequal search effort.",
        cost_all_quality_attempts=exp.attempt_cost_totals(quality_attempts),
        cost_all_new_reference_attempts=exp.attempt_cost_totals(reference_attempts) if "references" in read_json(Path(root) / "preparation.json")["batches"] else None,
        references=list(references.values()), runs=rows, graph_metrics=graph_rows, paired_depth_quality=pairs)
    write_once_json(output, result)
    return dict(output=str(output), runs=len(rows), graph_depth_method_rows=len(graph_rows), pairs=pairs)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    p = sub.add_parser("prepare")
    p.add_argument("--inputs", required=True); p.add_argument("--config", required=True); p.add_argument("--root", required=True)
    for name in ("run", "status", "stop", "summarize"):
        p = sub.add_parser(name); p.add_argument("--root", required=True)
        if name == "run":
            p.add_argument("--phase", choices=("quality", "references"), required=True)
            p.add_argument("--backend", default="default.qubit"); p.add_argument("--workers", type=int, default=4)
            p.add_argument("--execute", action="store_true"); p.add_argument("--max-tasks", type=int)
        elif name == "summarize":
            p.add_argument("--output", required=True); p.add_argument("--p3-reference-overlay", action="append")
    args = parser.parse_args()
    if args.command == "prepare": result = prepare(args.inputs, args.config, args.root)
    elif args.command == "run": result = run(args.root, args.phase, args.backend, args.workers, args.execute, args.max_tasks)
    elif args.command == "status": result = status(args.root)
    elif args.command == "stop":
        if not (Path(args.root) / "preparation.json").exists(): raise ValueError("Unknown output root.")
        (Path(args.root) / "stop.request").touch(); result = {"stop_requested": True}
    else: result = summarize(args.root, args.output, args.p3_reference_overlay)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()

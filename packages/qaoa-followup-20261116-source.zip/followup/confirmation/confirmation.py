import argparse
import base64
from collections import defaultdict
from contextlib import nullcontext
from copy import deepcopy
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import sys
import zipfile

for key in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[key] = '1'
REPO = Path.cwd().resolve()
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
import numpy as np
from qaoa_study import experiments as exp, records, graphs, learning
from qaoa_study.features import b4_feature_row
from qaoa_study.parallel import ParallelSettings

ROLES = ['reference', 'evaluation']
FAMILIES = ['ba', 'er', 'regular', 'sbm']


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def load_inputs(path):
    data = json.loads(gzip.decompress(Path(path).read_bytes()))
    if exp.digest({k:v for k,v in data.items() if k != 'input_id'}) != data['input_id']:
        raise ValueError('Frozen confirmation inputs changed.')
    return data


def export_inputs(output):

    import pyarrow.parquet as pq
    checkpoint = REPO / 'checkpoints'
    reconciliation = checkpoint / '20261115-study-reconciliation'
    manifest = records.read_json(reconciliation / 'cohorts-manifest.json')
    expected = records.read_json(reconciliation / 'graphs-manifest.json')['graphs']
    rows, source_hashes = {}, {}

    def payload(path, member=None):
        if member:
            with zipfile.ZipFile(path) as archive:
                raw = archive.read(member)
        else:
            raw = path.read_bytes()
        source_hashes[str(path.relative_to(REPO)) + ('::'+member if member else '')] = sha(raw)
        return raw

    def register(records_):
        for row in records_:
            if row['iso_class_id'] in rows:
                assert rows[row['iso_class_id']]['edges'] == row['edges']
            else:
                rows[row['iso_class_id']] = row

    for library in manifest['libraries'].values():
        path = REPO / library['archive']; prefix = library['root']
        old = json.loads(payload(path, prefix+'manifest.json'))
        raw = payload(path, prefix+'graphs.parquet')
        assert sha(raw) == old['files']['graphs.parquet']
        loaded = pq.read_table(io.BytesIO(raw)).to_pylist()
        for row in loaded:
            for key in ('provenance', 'iso_mappings', 'feature_missing'):
                row[key] = json.loads(row.pop(key+'_json'))
        register(loaded)
    for name, binding in manifest['inputs'].items():
        if not name.endswith('/plan.json'):
            continue
        path, member = name.split('::', 1)
        raw = payload(REPO/path, member)
        assert sha(raw) == binding['sha256']
        plan = json.loads(raw)
        if 'graphs' in plan:
            register(plan['graphs'])
    assert set(rows) == {r['graph_id'] for r in expected}
    for row in expected:
        original = rows[row['graph_id']]
        digest = sha(json.dumps([original['n'], sorted(sorted(e) for e in original['edges'])], separators=(',', ':')).encode())
        assert digest == row['topology_sha256']
    models = []
    for method, folder, filename in [
            ('Ridge_F', '20260927-normalized-metrics', 'b4-success-overlay.json'),
            ('XGBoost_F', '20260928-b5-normalized-metrics', 'b5-success-overlay.json')]:
        source = json.loads(payload(checkpoint/folder/filename))
        for model in source['models']:
            if model['regime'] == 'random' and model['group'] == 'F' and model['shuffle_seed'] is None:
                native = []
                for name, digest in model.get('booster_files', {}).items():
                    raw = payload(checkpoint/folder/model['booster_paths'][name])
                    assert sha(raw) == digest
                    native.append(base64.b64encode(raw).decode())
                models.append({'method': method, 'model': model, 'native': native})
    assert len(models) == 4 and all(len(x['model']['training_graph_ids']) == 300 for x in models)
    controls = json.loads(payload(reconciliation/'learning-controls.json'))['models']
    controls = [{k:v for k,v in m.items() if k != 'cv_folds'} for m in controls if m['method'] == 'size_degree_family']
    saved_predictions = pq.read_table(io.BytesIO(payload(reconciliation/'learning-predictions.parquet'))).to_pylist()
    checks = sorted({r['iso_class_id'] for r in saved_predictions})[:4]
    method_names = {'B4_Ridge_F':'Ridge_F', 'B5_XGBoost_F':'XGBoost_F',
                    'training_constant':'training_constant', 'size_degree_family':'size_degree_family'}
    replay = [{**r,'method':method_names[r['method']]} for r in saved_predictions
              if r['iso_class_id'] in checks and r['method'] in method_names]
    config = records.read_json(REPO/'configs/experiments-candidate.json')
    labels = pq.read_table(reconciliation/'labels-unified.parquet', columns=['p','optimizer_settings_json']).to_pylist()
    assert all(json.loads(r['optimizer_settings_json']) == config['optimizer'][str(r['p'])] for r in labels)
    protocol = records.read_json(HERE/'protocol.json')
    config = {k:config[k] for k in ('depths','reference','evaluation_restarts','max_attempts','optimizer')}
    config.update(protocol_version=protocol['version'], seed_namespace=protocol['version'],
                  seed=protocol['execution_seed'], success_metric=protocol['success_metric'],
                  tier1_restarts=1, gradient_samples=1, require_full_design=False, require_split_coverage=False,
                  expected_library={'graphs':128,'tier2':128,'training':0,'evaluation':128})
    data = {'version':protocol['version'], 'protocol':protocol, 'config':config,
            'exclusions':{'library_id':'all-historical-'+exp.digest(sorted(rows)), 'graphs':[rows[k] for k in sorted(rows)]},
            'models':models, 'controls':controls, 'replay_predictions':replay, 'source_sha256':source_hashes}
    data['input_id'] = exp.digest(data)
    raw = gzip.compress(json.dumps(data, sort_keys=True, allow_nan=False).encode(), mtime=0)
    with Path(output).open('xb') as stream:
        stream.write(raw)
    return {'input_id':data['input_id'], 'excluded_graphs':len(rows), 'models':len(models), 'bytes':len(raw)}


def predictions(data, library):
    features = [dict(b4_feature_row(graphs.graph_from_record(g)), iso_class_id=g['iso_class_id']) for g in library['graphs']]
    result = []
    for entry in data['models']:
        model = entry['model']
        native = learning.load_b5_boosters([base64.b64decode(x) for x in entry['native']]) if entry['native'] else None
        values = (learning.predict_b4_model(model, features) if native is None else
                  learning.predict_b5_model(model, native, features))
        for row in values:
            result.append({**row, 'p':model['p'], 'method':entry['method'], 'fit_id':model['fit_id']})
        if entry['method'] == 'Ridge_F':
            result.extend({'iso_class_id':g['iso_class_id'], 'p':model['p'], 'method':'training_constant',
                           'success_probability':model['training_mean']} for g in library['graphs'])
    matrix = np.array([[g['n'], 2*len(g['edges'])/g['n'], *[int(g['families'][0] == f) for f in FAMILIES]] for g in library['graphs']])
    for model in data['controls']:
        raw = ((matrix-np.array(model['preprocessing_mean']))/np.array(model['preprocessing_scale'])) @ np.array(model['coefficients']) + model['intercept']
        result.extend({'iso_class_id':g['iso_class_id'], 'p':model['p'], 'method':'size_degree_family',
                       'success_probability':float(np.clip(value,0,1))} for g,value in zip(library['graphs'],raw,strict=True))
    return result


def prepare(inputs, root, execute=False):
    data = load_inputs(inputs)
    if not execute:
        return {'dry_run':True, 'graphs_to_generate':128, 'required_tasks':25728, 'optimization_call_cap':4480000,
                'p1_analytic_grid_points':20971520, 'input_id':data['input_id']}
    root = Path(root)
    if root.exists():
        raise FileExistsError('Choose a fresh confirmation root.')
    preflight(inputs)
    root.mkdir(parents=True)
    records.write_once_json(root/'inputs.json', data)
    records.write_once_json(root/'source.json', {'entry_sha256':sha(Path(__file__).read_bytes()),'input_id':data['input_id']})
    library = graphs.generate_library(data['protocol']['graph_config'], excluded_libraries=[data['exclusions']])
    if len(library['graphs']) != 128 or any(c['shortfall'] for c in library['cells']):
        records.write_once_json(root/'incomplete-generation.json', library)
        raise ValueError('Graph generation shortfall; preserve this attempt and review before a new version.')
    library = records.annotate_library(library, exact_sizes=(12,16))
    records.save_library(root/'library', library)
    records.write_once_json(root/'predictions.json', {'input_id':data['input_id'], 'rows':predictions(data,library)})
    manifest = exp.save_batch(root/'batch', root/'library', data['config'])
    if manifest['issues']:
        raise ValueError(manifest['issues'])
    return status(root)


def observations(root):
    root = Path(root)
    if records.read_json(root/'source.json')['entry_sha256'] != sha(Path(__file__).read_bytes()):
        raise ValueError('Confirmation entry changed; do not resume with edited source.')
    data = records.read_json(root/'inputs.json')
    assert exp.digest({k:v for k,v in data.items() if k != 'input_id'}) == data['input_id']
    manifest, library, tasks = exp.read_batch(root/'batch')
    if manifest['config'] != data['config'] or records.read_json(root/'source.json')['input_id'] != data['input_id']:
        raise ValueError('Frozen confirmation inputs and batch no longer agree.')
    attempts = exp.load_attempts(manifest,tasks,root/'attempts',metadata_only=True)[0] if (root/'attempts/manifest.json').exists() else []
    return data, manifest, library, tasks, attempts, exp.select_attempts(attempts)


def status(root):
    _,_,_,tasks,_,selected = observations(root)
    wanted = [t for t in tasks if t['experiment_role'] in ROLES]
    valid = sum(t['task_id'] in selected and not records.execution_failed(selected[t['task_id']]) for t in wanted)
    faults = sum(t['task_id'] in selected and records.execution_failed(selected[t['task_id']]) for t in wanted)
    return {'planned':len(wanted),'valid':valid,'remaining':len(wanted)-valid,
            'unresolved_execution_faults':faults,'complete':valid==len(wanted)}


def preflight(inputs):

    data = load_inputs(inputs)
    ids = {r['iso_class_id'] for r in data['replay_predictions']}
    library = {'graphs':[g for g in data['exclusions']['graphs'] if g['iso_class_id'] in ids]}
    actual = {(r['iso_class_id'],r['p'],r['method']):r['success_probability'] for r in predictions(data,library)}
    error = max(abs(actual[r['iso_class_id'],r['p'],r['method']]-r['success_probability']) for r in data['replay_predictions'])
    if error > 1e-7:
        raise ValueError(f'Existing model replay differs: maximum probability error {error}.')
    return {'replayed_old_graphs':len(ids),'max_absolute_prediction_error':error,'new_graphs_generated':0}


def run(root, backend, workers, execute=False, max_tasks=None):
    observations(root)
    root=Path(root); stopped=[False]; previous={}; last=[None]
    def progress(report):
        counts = {k:report.get(k) for k in ['valid_completed','missing_tasks','unresolved_execution_faults']}
        if counts != last[0]:
            print(json.dumps(counts),flush=True)
            last[0] = counts
    with exp._writer_lock(root) if execute else nullcontext():
        if execute:
            (root/'stop.request').unlink(missing_ok=True)
            for number in (signal.SIGINT, signal.SIGTERM):
                previous[number]=signal.signal(number,lambda *_:stopped.__setitem__(0,True))
        try:
            return exp.run_worker(root/'batch',root/'attempts',backend=backend,roles=ROLES,execute=execute,
                parallel=ParallelSettings(workers=workers), max_tasks=max_tasks,
                should_stop=lambda:stopped[0] or (root/'stop.request').exists(),
                progress=progress)
        finally:
            for number,handler in previous.items(): signal.signal(number,handler)


def summarize(root, output):
    data, manifest, library, tasks, attempts, selected=observations(root)
    if not status(root)['complete']: raise ValueError('All reference and evaluation tasks must be valid before final analysis.')
    output=Path(output)
    if output.exists(): raise FileExistsError('Choose a fresh analysis directory.')
    references=exp.freeze_references(manifest,tasks,selected)
    if not all(r['complete'] for r in references.values()): raise ValueError('Incomplete reference grid/pool.')
    predictions_saved=records.read_json(Path(root)/'predictions.json')
    if predictions_saved != {'input_id':data['input_id'],'rows':predictions(data,library)}:
        raise ValueError('Predictions differ from frozen pre-evaluation models.')
    by_graph=defaultdict(list)
    for t in tasks:
        if t['experiment_role']=='evaluation': by_graph[t['iso_class_id'],t['p']].append(selected[t['task_id']]['C_final'])
    graphmap={g['iso_class_id']:g for g in library['graphs']}; rows=[]
    for pr in predictions_saved['rows']:
        key=pr['iso_class_id'],pr['p']; g=graphmap[key[0]]; values=by_graph[key]; ref=references[key]['C_ref']; q=pr['success_probability']
        successes=sum(c >= ref-.01*g['C_star'] for c in values); y=successes/len(values)
        rows.append({**pr,'cell':g['representative_cell'],'success_rate':y,'valid_restarts':len(values),
                     'successes':successes,'C_star':g['C_star'],'C_ref':ref,'normalized_tolerance':.01,
                     'optimizer':manifest['config']['optimizer'][str(key[1])],
                     'reference_id':references[key]['reference_id'],'rmse_squared':(q-y)**2,'absolute_error':abs(q-y),
                     'brier':q*q-2*q*y+y,'sensitivity_rates':{str(t):sum(c>=ref-t*g['C_star'] for c in values)/len(values) for t in [.005,.02]}})
    metrics=[]; paired=[]; bins=[]
    for p in [1,2]:
        ids=sorted(graphmap); groups={method:sorted([r for r in rows if r['p']==p and r['method']==method],key=lambda r:r['iso_class_id']) for method in data['protocol']['models']}
        cells=defaultdict(list)
        for i,gid in enumerate(ids): cells[graphmap[gid]['representative_cell']].append(i)
        rng=np.random.default_rng(data['protocol']['uncertainty']['seed']); draws=np.concatenate([rng.choice(ix,(data['protocol']['uncertainty']['replicates'],len(ix))) for _,ix in sorted(cells.items())],axis=1)
        boot={}
        for method, rs in groups.items():
            errors=np.array([r['rmse_squared'] for r in rs]); boot[method]=np.sqrt(errors[draws].mean(axis=1))
            metrics.append({'p':p,'method':method,'rmse':float(np.sqrt(errors.mean())), 'mae':float(np.mean([r['absolute_error'] for r in rs])), 'brier':float(np.mean([r['brier'] for r in rs]))})
            for b in range(10):
                chosen=[r for r in rs if min(int(10*r['success_probability']),9)==b]
                bins.append({'p':p,'method':method,'bin':b,'graphs':len(chosen),'mean_prediction':float(np.mean([r['success_probability'] for r in chosen])) if chosen else None,'observed':float(np.mean([r['success_rate'] for r in chosen])) if chosen else None})
        for method in ['Ridge_F','XGBoost_F']:
            for comparator in ['training_constant','size_degree_family']:
                point = {r['method']:r['rmse'] for r in metrics if r['p']==p}
                paired.append({'p':p,'method':method,'comparator':comparator,'metric':'RMSE difference',
                    'estimate':point[method]-point[comparator],
                    'interval95':np.quantile(boot[method]-boot[comparator],[.025,.975]).tolist(),
                    'primary':p==2 and method=='XGBoost_F' and comparator=='size_degree_family'})
    diagnostics=[]
    for (gid,p),values in sorted(by_graph.items()):
        ref=references[gid,p]; ref_tasks=sorted([t for t in tasks if t['experiment_role']=='reference' and t['iso_class_id']==gid and t['p']==p],key=lambda t:t['restart_id'])
        candidates=[selected[t['task_id']]['best_seen'] for t in ref_tasks] if p==2 else []
        half=len(candidates)//2
        diagnostics.append({'iso_class_id':gid,'p':p,'reference_id':ref['reference_id'],
            'endpoints_above_reference':sum(v>ref['C_ref']+1e-8 for v in values),
            'largest_endpoint_excess_normalized':max(0.,max(values)-ref['C_ref'])/graphmap[gid]['C_star'],
            'split_reference_gap_normalized':abs(max(candidates[:half])-max(candidates[half:]))/graphmap[gid]['C_star'] if half else None})
    output.mkdir(parents=True); exp.save_references(output/'references',references)
    records.write_once_json(output/'analysis.json',{'input_id':data['input_id'],'protocol':data['protocol'],'rows':rows,'metrics':metrics,'paired':paired,'reliability_bins':bins,'reference_diagnostics':diagnostics,'costs':exp.attempt_cost_totals(attempts)})
    return {'graphs':len(graphmap),'graph_depth_labels':len(by_graph),'metrics':metrics,'paired':paired}


def main():
    parser=argparse.ArgumentParser(description=__doc__); sub=parser.add_subparsers(dest='command',required=True)
    export=sub.add_parser('export'); export.add_argument('--output',required=True)
    check=sub.add_parser('preflight'); check.add_argument('--inputs',default=str(HERE/'inputs.json.gz'))
    for name in ('prepare','run','status','stop','summarize'):
        p=sub.add_parser(name);p.add_argument('--root',required=True)
        if name=='prepare':p.add_argument('--inputs',default=str(HERE/'inputs.json.gz'));p.add_argument('--execute',action='store_true')
        if name=='run':
            p.add_argument('--execute',action='store_true');p.add_argument('--backend',default='lightning.gpu');p.add_argument('--workers',type=int,default=4);p.add_argument('--max-tasks',type=int)
        if name=='summarize':p.add_argument('--output',required=True)
    a=parser.parse_args()
    if a.command=='export':result=export_inputs(a.output)
    elif a.command=='preflight':result=preflight(a.inputs)
    elif a.command=='prepare':result=prepare(a.inputs,a.root,a.execute)
    elif a.command=='run':result=run(a.root,a.backend,a.workers,a.execute,a.max_tasks)
    elif a.command=='status':result=status(a.root)
    elif a.command=='stop':observations(a.root);(Path(a.root)/'stop.request').touch();result={'stop_requested':True}
    else:result=summarize(a.root,a.output)
    print(json.dumps(result,indent=2,allow_nan=False))


if __name__=='__main__': main()

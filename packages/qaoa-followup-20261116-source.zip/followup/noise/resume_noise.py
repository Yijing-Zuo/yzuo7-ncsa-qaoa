import argparse
from collections import Counter
from datetime import datetime, timezone
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

for name in ('OMP_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[name] = '1'
HERE = Path(__file__).resolve().parent


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def load_inputs():
    data = json.loads(gzip.decompress((HERE / 'inputs.json.gz').read_bytes()))
    if digest({k: v for k, v in data.items() if k != 'input_id'}) != data['input_id']:
        raise ValueError('Prepared inputs changed.')
    for name, expected in data['runtime_files'].items():
        if hashlib.sha256((HERE / 'runtime' / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Frozen runtime changed: ' + name)
    return data


def write_once(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, allow_nan=False)
        f.write('\n')


def read_record(path):
    stored = json.loads(path.read_text())
    plain = {k: v for k, v in stored.items() if k not in ('_integrity', '_run_file_version')}
    if digest(plain) != stored.get('_integrity', {}).get('value') or not plain.get('run_completed'):
        raise ValueError('Incomplete or corrupt saved record: ' + str(path))
    return plain


def inherited(data):
    return {r['task']['task_id']: r for r in data['parent_records']}


def resolve_gpu(env, listing=None):

    placement = env['device_identity']
    inventory = placement['gpu_inventory'] or []
    visibility = placement['visibility']
    allocated = (visibility.get('NVIDIA_VISIBLE_DEVICES') or '').split(',')
    allocated = allocated if allocated[0].startswith(('GPU-', 'MIG-')) else []
    visible = visibility.get('CUDA_VISIBLE_DEVICES')
    tokens = visible.split(',') if visible is not None else allocated
    tokens = [allocated[int(t)] if t.isdecimal() and int(t) < len(allocated) else t.strip() for t in tokens]
    parents, profiles = {}, {}
    if any(t.startswith('MIG-') for t in tokens):
        if listing is None:
            listing = subprocess.run(['nvidia-smi', '-L'], capture_output=True, text=True,
                                     check=True, timeout=10).stdout
        parent = None
        for line in listing.splitlines():
            gpu = re.match(r'^GPU \d+:.*\(UUID: (GPU-[^)]+)\)', line)
            mig = re.match(r'^\s+MIG (.+?) Device \d+: \(UUID: (MIG-[^)]+)\)', line)
            if gpu:
                parent = gpu[1]
            elif mig and parent:
                profiles[mig[2]], parents[mig[2]] = mig[1].strip(), parent
    selected, mig_profiles = [], []
    for token in tokens:
        if token.startswith('MIG-'):
            if token not in parents:
                raise ValueError('Cannot identify allocated MIG device: ' + token)
            placement.setdefault('mig_parent_uuids', {})[token] = parents[token]
            mig_profiles.append(profiles[token])
            token = parents[token]
        matches = [row for row in inventory if row['index'] == token or row['uuid'] == token]
        if len(matches) != 1:
            raise ValueError('Cannot identify allocated GPU: ' + token)
        selected.extend(matches)
    kinds = {(row['name'], row['driver_version']) for row in (selected if tokens else inventory)}
    if len(kinds) != 1:
        raise ValueError('A single GPU model and driver must be identified.')
    model, driver = kinds.pop()
    env['gpu'].update(model=model, driver_version=driver, mig_profiles=sorted(set(mig_profiles)))
    env['gpu']['unknown'] = [x for x in env['gpu']['unknown'] if x != 'gpu_model_or_driver']
    return placement


def is_fault(record):
    return bool(record.get('error') or record.get('validation_error') or record.get('exact_audit_error') or
                record['stop_reason'] in ('numerical_error', 'evaluation_error', 'optimizer_failed', 'program_error'))


def next_attempt(data, root, key):
    attempt = 1 + sum((root / 'started' / f'{key}.attempt-{n}.json').exists()
                      for n in range(1, data['config']['max_attempts'] + 1))
    if attempt > data['config']['max_attempts']:
        raise ValueError('Execution-attempt limit reached: ' + key)
    return attempt


def inspect(data, root):
    old = inherited(data)
    execution = json.loads((root / 'execution.json').read_text()) if (root / 'execution.json').exists() else None
    if execution and (execution['input_id'] != data['input_id'] or
                      digest({k: v for k, v in execution.items() if k != 'execution_id'}) != execution['execution_id']):
        raise ValueError('Output belongs to different inputs.')
    records, faults, retained_faults, unfinished, exhausted = {}, [], [], [], []
    counts, elapsed, saved_attempts = Counter(), 0., 0
    result_paths = set((root / 'attempts').glob('*.json'))
    marker_paths = set((root / 'started').glob('*.json'))
    for task in data['tasks']:
        key = task['task_id']
        task_faults, started = [], 0
        for n in range(1, data['config']['max_attempts'] + 1):
            path = root / 'attempts' / f'{key}.attempt-{n}.json'
            marker = root / 'started' / f'{key}.attempt-{n}.json'
            if key in old and (path in result_paths or marker in marker_paths):
                raise ValueError('An inherited completed task was rerun: ' + key)
            if marker not in marker_paths:
                if path in result_paths:
                    raise ValueError('Completed attempt lacks its started receipt: ' + key)
                continue
            started += 1
            m = json.loads(marker.read_text())
            if (started != n or execution is None or m['execution_id'] != execution['execution_id'] or
                    m['task_id'] != key or m['attempt_number'] != n):
                raise ValueError('Started-attempt identity mismatch: ' + key)
            if path not in result_paths:
                unfinished.append({'task_id': key, 'attempt_number': n})
                continue
            r = read_record(path)
            if r['execution_id'] != execution['execution_id'] or r['task'] != task or r['attempt_number'] != n:
                raise ValueError('Task or execution identity mismatch: ' + key)
            counts.update(r['counts']); elapsed += r['elapsed_seconds']; saved_attempts += 1
            if is_fault(r):
                task_faults.append(n)
                retained_faults.append({'task_id': key, 'attempt_number': n})
            elif key not in records:
                records[key] = r
        if key in old:
            continue
        if key not in records and task_faults:
            faults.append(key)
        if key not in records and started == data['config']['max_attempts']:
            exhausted.append(key)
    done = len(old) + len(records)
    return {'graphs': len(data['graphs']), 'planned': len(data['tasks']), 'inherited_completed': len(old),
            'new_completed': len(records), 'completed': done, 'remaining': len(data['tasks']) - done,
            'faults': faults, 'complete': done == len(data['tasks']) and not faults,
            'retained_fault_attempts': retained_faults, 'started_without_result': unfinished,
            'attempt_limit_reached': exhausted, 'new_saved_attempts': saved_attempts,
            'all_new_saved_attempt_counts': dict(counts), 'all_new_saved_attempt_elapsed_seconds': elapsed,
            'stop_requested': (root / 'stop.request').exists()}, records


def run(data, root, max_tasks=None):
    if sys.platform != 'linux':
        raise ValueError('Research execution is user-triggered on Linux GPU only.')
    if root.exists() and any(root.iterdir()) and not (root / 'execution.json').exists():
        raise ValueError('Choose a new output directory; old results are not an output target.')
    sys.path.insert(0, str(HERE / 'runtime'))
    from qaoa_study import experiments as exp
    from qaoa_study.graphs import graph_from_record
    from qaoa_study.optimize import ShotOptimizerSettings, optimize_qaoa_shots
    from qaoa_study.records import save_run, write_once_json
    from local import run_b3_full as old_driver
    from local.verify_shot_backend import verify_backend
    if exp.source_identity() != data['parent']['source']:
        raise ValueError('Archived runtime source identity mismatch.')
    env = exp.environment('lightning.gpu')
    placement = resolve_gpu(env)
    env.pop('device_identity')
    env.update(shots='per-task fixed batches', interface=None, diff_method=None, device_vjp=False)
    execution = {'version': 'noise98-execution-overlay-v1', 'input_id': data['input_id'],
                 'parent_plan_id': data['parent']['plan_id'], 'parent_execution_id': data['parent']['execution']['execution_id'],
                 'source_id': data['parent']['source']['source_id'], 'environment': env,
                 'helper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    execution['execution_id'] = digest(execution)
    root.mkdir(parents=True, exist_ok=True)
    with old_driver.driver_lock(root):
        path = root / 'execution.json'
        if path.exists():
            if json.loads(path.read_text()) != execution:
                raise ValueError('Environment or helper changed; preserve this output and use a new version.')
        else:
            write_once_json(path, execution)
        (root / 'stop.request').unlink(missing_ok=True)
        receipt = root / 'backend-verification.json'
        if receipt.exists():
            saved = json.loads(receipt.read_text())
            if saved['execution_id'] != execution['execution_id'] or not saved['verification']['passed']:
                raise ValueError('Backend verification identity mismatch.')
        else:
            verification = verify_backend('lightning.gpu')
            if not verification['passed']:
                raise ValueError('GPU verification failed.')
            write_once_json(receipt, {'execution_id': execution['execution_id'], 'verification': verification,
                                     'device_identity': placement})
        status, records = inspect(data, root)
        if status['attempt_limit_reached']:
            raise ValueError('Attempt limit reached; preserve records and inspect: ' + ', '.join(status['attempt_limit_reached']))
        completed = set(records) | set(inherited(data))
        graphs = {g['iso_class_id']: g for g in data['graphs']}
        executed, valid = 0, 0
        for task in data['tasks']:
            key = task['task_id']
            if key in completed:
                continue
            if (root / 'stop.request').exists() or (max_tasks and executed >= max_tasks):
                break
            markers = root / 'started'
            attempt = next_attempt(data, root, key)
            write_once_json(markers / f'{key}.attempt-{attempt}.json', {'task_id': key, 'attempt_number': attempt,
                            'execution_id': execution['execution_id'], 'started_utc': datetime.now(timezone.utc).isoformat()})
            result = optimize_qaoa_shots(graph_from_record(graphs[task['iso_class_id']]), task['p'], task['theta0'],
                        ShotOptimizerSettings(**data['config']['optimizer']), method=task['method'],
                        evaluation_mode=task['evaluation_mode'], measurement_seed=task['seeds']['measurement'],
                        perturbation_seed=task['seeds']['perturbation'], validation_seed=task['seeds']['validation'],
                        backend='lightning.gpu', audit_exact=True)
            result.update(task=task, execution_id=execution['execution_id'], run_completed=True,
                          attempt_number=attempt, previous_attempts=attempt - 1, device_identity=placement)
            save_run(root / 'attempts' / f'{key}.attempt-{attempt}.json', result)
            executed += 1
            valid += int(not is_fault(result))
            print(json.dumps({'completed': len(completed) + valid, 'planned': len(data['tasks']), 'task_id': key}), flush=True)
            if is_fault(result):
                raise ValueError('Execution fault retained; rerun this command for the next permitted attempt: ' + key)
    return inspect(data, root)[0]


def summarize(data, root):
    status, new = inspect(data, root)
    if not status['complete']:
        raise ValueError('All 18,620 scoped tasks must be valid before final summary.')
    records = {**inherited(data), **new}
    refs = {(r['iso_class_id'], r['p']): r['C_ref'] for r in data['references']}
    stars = {g['iso_class_id']: g['C_star'] for g in data['graphs']}
    rows, counts = {}, Counter()
    for task in data['tasks']:
        r = records[task['task_id']]
        fields = {k: task[k] for k in ('iso_class_id', 'p', 'initialization', 'variant', 'method', 'evaluation_mode')}
        row = rows.setdefault(tuple(fields.values()), {**fields, 'repetitions': 0, 'quality_sum': 0., 'successes': 0})
        score = r['exact_audit']['C_final']; star = stars[task['iso_class_id']]
        row['repetitions'] += 1; row['quality_sum'] += score / star
        row['successes'] += int(score >= refs[task['iso_class_id'], task['p']] - .01 * star)
        counts.update(r['counts'])
    report = {**status, 'input_id': data['input_id'], 'parent_plan_id': data['parent']['plan_id'],
              'scope': '98 n22 RGG graph panels; 1 original A100 record plus 18,619 new-environment records',
              'cross_environment': True, 'counts_unique_tasks': dict(counts),
              'counts_including_saved_faults': dict(Counter(status['all_new_saved_attempt_counts']) +
                                                    sum((Counter(r['counts']) for r in inherited(data).values()), Counter())),
              'completed_new_elapsed_seconds': sum(r['elapsed_seconds'] for r in new.values()),
              'completed_parent_elapsed_seconds': sum(r['elapsed_seconds'] for r in inherited(data).values()),
              'interrupted_work_cost': 'Unknown; every started marker is retained.',
              'graph_conditions': [{**r, 'quality': r['quality_sum']/r['repetitions'], 'success': r['successes']/r['repetitions']} for r in rows.values()]}
    write_once(root / 'summary.json', report)
    return {k: report[k] for k in ('complete', 'completed', 'scope')}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command', choices=('check', 'run', 'status', 'stop', 'summarize'))
    parser.add_argument('--root', type=Path, default=Path('noise98-h200-v1'))
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--max-tasks', type=int)
    args = parser.parse_args()
    data, root = load_inputs(), args.root.resolve()
    if args.max_tasks is not None and args.max_tasks < 1:
        parser.error('--max-tasks must be positive')
    if args.command == 'run' and args.execute:
        result = run(data, root, args.max_tasks)
    elif args.command == 'stop':
        if not (root / 'execution.json').exists():
            raise ValueError('No recognized running output.')
        inspect(data, root)
        (root / 'stop.request').touch()
        result = {'stop_requested': True, 'note': 'Current task finishes and saves first.'}
    elif args.command == 'summarize':
        result = summarize(data, root)
    else:
        result = inspect(data, root)[0]
        result['execute_required'] = args.command == 'run'
    print(json.dumps(result, indent=2), flush=True)


if __name__ == '__main__':
    main()

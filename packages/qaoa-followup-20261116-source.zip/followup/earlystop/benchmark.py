import argparse
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
from time import perf_counter
import zipfile

RUNTIME = Path(os.environ.get("QAOA_RUNTIME", Path.cwd())).resolve()
sys.path.insert(0, str(RUNTIME))
import numpy as np
from scipy.optimize import minimize
from qaoa_study import experiments as exp
from qaoa_study.graphs import graph_from_record
from qaoa_study.optimize import OptimizerSettings
from qaoa_study.qaoa import make_qaoa, qaoa_loss_and_gradient
from qaoa_study.records import EXECUTION_FAILURES, read_json, write_once_json

SETTINGS = dict(max_evaluations=300, maxiter=225, maxls=20, ftol=1e-10, gtol=1e-7)
METHODS = ("B1", "B2_medoid", "B2_aligned_median", "B3")


def sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def sealed(value, key):
    return {**value, key: exp.digest(value)}


def verify(value, key):
    if value[key] != exp.digest({k: v for k, v in value.items() if k != key}):
        raise ValueError(f"Changed {key}.")
    return value


def archive_references(archive, prefix):
    manifest = json.loads(archive.read(prefix + "manifest.json"))
    if exp.digest(manifest["files"]) != manifest["reference_set_id"]:
        raise ValueError("Changed reference-set manifest.")
    refs = {}
    for name in manifest["files"]:
        ref = verify(json.loads(archive.read(prefix + name)), "reference_id")
        if name != ref["reference_id"] + ".json" or ref["iso_class_id"] in refs:
            raise ValueError("Duplicate or misnamed reference.")
        refs[ref["iso_class_id"]] = ref
    return refs, manifest["reference_set_id"]


def compact_reference(ref):
    if not ref["complete"] or ref["p"] != 3 or not np.isfinite(ref["C_ref"]):
        raise ValueError("Complete finite p3 references are required.")
    return {k: ref[k] for k in ("reference_id", "library_id", "iso_class_id", "p", "C_ref")}


def export_inputs(old_archive, reference_archive, output):

    with zipfile.ZipFile(reference_archive) as archive:
        inputs = verify(json.loads(archive.read("p3-reference-independent100-v1/inputs.json")), "input_id")
        prefixes = [n[:-len("manifest.json")] for n in archive.namelist()
                    if n.endswith("/union-references/manifest.json")]
        if len(prefixes) != 1:
            raise ValueError("Expected exactly one completed union-reference set.")
        refs, reference_set_id = archive_references(archive, prefixes[0])
    ids = set(inputs["evaluation_graph_ids"])
    graphs = {g["iso_class_id"]: {k: g[k] for k in ("iso_class_id", "n", "edges", "C_star", "representative_cell")}
              for g in inputs["library"]["graphs"] if g["iso_class_id"] in ids}
    if len(ids) != 96 or set(graphs) != ids or set(refs) != ids:
        raise ValueError("Expected the original 96 evaluation graphs and references.")
    starts, parents = [], {}
    with zipfile.ZipFile(old_archive) as archive:
        for batch in ("baseline", "b2", "b3"):
            prefix = f"p3-96-v1/{batch}/"
            manifest = json.loads(archive.read(prefix + "manifest.json"))
            identity = {k: manifest[k] for k in ("library_id", "config", "source_id", "tasks_sha256")}
            if exp.digest(identity) != manifest["batch_id"] or manifest["library_id"] != inputs["library"]["library_id"]:
                raise ValueError("Changed or mismatched original batch.")
            raw = archive.read(prefix + "tasks.jsonl")
            if hashlib.sha256(raw).hexdigest() != manifest["tasks_sha256"]:
                raise ValueError("Changed original tasks.")
            parents[batch] = identity | {"batch_id": manifest["batch_id"]}
            for line in raw.splitlines():
                task = verify(json.loads(line), "task_id")
                if task["graph_split"] != "evaluation" or task["p"] != 3 or task["restart_id"] != 0:
                    continue
                role = "evaluation" if batch == "baseline" else "warm_start"
                if task["experiment_role"] != role:
                    continue
                method = task["method"] + ("_" + task["variant"] if task["method"] == "B2" else "")
                if task["iso_class_id"] not in ids or task["budget"] != SETTINGS or method not in METHODS:
                    raise ValueError("Unexpected original starting task.")
                starts.append({k: task[k] for k in ("task_id", "iso_class_id", "theta0")} | {"method": method})
    if Counter((s["iso_class_id"], s["method"]) for s in starts) != Counter({(g, m): 1 for g in ids for m in METHODS}):
        raise ValueError("Expected four distinct original starts per graph.")
    value = sealed({"version": 1, "library_id": inputs["library"]["library_id"], "graphs": graphs,
                    "starts": sorted(starts, key=lambda s: (s["iso_class_id"], s["method"])),
                    "references": {g: compact_reference(r) for g, r in refs.items()},
                    "reference_set_id": reference_set_id, "parent_batches": parents,
                    "archives_sha256": {"original": sha(old_archive), "reference": sha(reference_archive)}}, "input_id")
    write_once_json(output, value)
    return {"graphs": len(graphs), "starts": len(starts), "input_id": value["input_id"]}


def prepare(inputs_path, root, updates=()):
    inputs = verify(read_json(inputs_path), "input_id")
    refs, update_sets, updated = dict(inputs["references"]), [], set()
    for directory in updates:
        manifest = read_json(Path(directory) / "manifest.json")
        for (graph_id, p), ref in exp.read_references(directory).items():
            old = refs.get(graph_id)
            if (old is None or graph_id in updated or p != 3 or ref["library_id"] != inputs["library_id"]
                    or old["reference_id"] not in ref.get("parent_reference_ids", []) or ref["C_ref"] < old["C_ref"]):
                raise ValueError("Update must be a nonoverlapping union descending from the frozen base reference.")
            refs[graph_id] = compact_reference(ref)
            updated.add(graph_id)
        update_sets.append(manifest["reference_set_id"])
    pairs = []
    for start in inputs["starts"]:
        base = int(exp.digest(["earlystop-order-v1", start["task_id"]])[:8], 16) % 2
        for replica in range(4):
            order = ["full", "early"] if (base + replica) % 2 == 0 else ["early", "full"]
            pairs.append(sealed({**start, "replica": replica, "order": order}, "pair_id"))
    plan = sealed({"version": 1, "input": inputs, "references": refs, "reference_update_sets": update_sets,
                   "settings": SETTINGS, "replicas": 4, "attempt_limit": 2, "pairs": pairs,
                   "source": exp.source_identity(RUNTIME), "helper_sha256": sha(__file__),
                   "policy": "offline_reference_aware_first_evaluated_hit", "tolerance": 0.01,
                   "cost_boundary": "device build and one warmup per pair measured separately; reference searches and initialization training excluded, not zero"}, "plan_id")
    root = Path(root)
    root.mkdir(parents=True, exist_ok=False)
    write_once_json(root / "plan.json", plan)
    return {"plan_id": plan["plan_id"], "pairs": len(pairs), "optimizations": 2 * len(pairs), "updated_graphs": len(updated)}


class Stopped(Exception):
    def __init__(self, reason):
        self.reason = reason


def optimize(objective, theta0, threshold, settings, early):

    start = perf_counter()
    trace, accepted, first_hit, iterations = [], None, None, 0
    error = None

    def evaluate(theta):
        nonlocal accepted, first_hit
        if len(trace) >= settings.max_evaluations:
            raise Stopped("budget_exhausted")
        row = {"call_id": len(trace) + 1, "theta": [float(x) if np.isfinite(x) else None for x in theta],
               "C": None, "gradient": None, "accepted": False, "valid": False}
        trace.append(row)
        if not np.all(np.isfinite(theta)):
            raise Stopped("numerical_error")
        try:
            loss, gradient = objective(theta)
        except Exception as exc:
            row["error"] = f"{type(exc).__name__}: {exc}"
            raise Stopped("evaluation_error") from exc
        gradient = np.asarray(gradient, dtype=float)
        if not np.isfinite(loss) or gradient.shape != np.shape(theta) or not np.all(np.isfinite(gradient)):
            raise Stopped("numerical_error")
        row.update(C=-float(loss), gradient=gradient.tolist(), valid=True)
        if len(trace) == 1:
            row["accepted"], accepted = True, row
        if first_hit is None and row["C"] >= threshold:
            first_hit = row
        if early and first_hit is not None:
            raise Stopped("threshold_hit")
        return float(loss), gradient

    def callback(theta):
        nonlocal accepted, iterations
        accepted = next(r for r in reversed(trace) if r["valid"] and np.array_equal(r["theta"], theta))
        accepted["accepted"] = True
        iterations += 1

    try:
        result = minimize(evaluate, np.asarray(theta0, dtype=float), method="L-BFGS-B", jac=True, bounds=None,
                          callback=callback, options={"maxfun": settings.max_evaluations, "maxiter": settings.maxiter,
                                                     "maxls": settings.maxls, "ftol": settings.ftol, "gtol": settings.gtol})
        if result.success:
            reason = "converged"
        elif result.status == 1 and iterations >= settings.maxiter:
            reason = "iteration_limit"
        elif result.status == 1 and len(trace) >= settings.max_evaluations:
            reason = "budget_exhausted"
        else:
            reason = "line_search_failed" if result.status == 2 else "optimizer_failed"
    except Stopped as exc:
        reason = exc.reason
    except Exception as exc:
        reason, error = "optimizer_failed", f"{type(exc).__name__}: {exc}"
    endpoint = first_hit if reason == "threshold_hit" else accepted
    return {"trace": trace, "objective_calls": len(trace), "gradient_requests": len(trace), "iterations": iterations,
            "C_final": endpoint["C"] if endpoint else None, "theta_final": endpoint["theta"] if endpoint else None,
            "final_call_id": endpoint["call_id"] if endpoint else None,
            "first_hit": first_hit["call_id"] if first_hit else None,
            "terminal_success": reason not in EXECUTION_FAILURES and endpoint is not None and endpoint["C"] >= threshold,
            "elapsed_seconds": perf_counter() - start, "stop_reason": reason, "error": error}


def execute_pair(pair, plan, backend):
    graph = plan["input"]["graphs"][pair["iso_class_id"]]
    threshold = plan["references"][pair["iso_class_id"]]["C_ref"] - plan["tolerance"] * graph["C_star"]
    result = {"arms": {}, "threshold": threshold, "device_build_seconds": None, "warmup_seconds": None,
              "warmup_objective_calls": 0, "valid": False, "error": None}
    started = perf_counter()
    stage_started, stage = started, "device_build_seconds"
    try:
        circuit = make_qaoa(graph_from_record(graph), 3, backend=backend)
        result["device_build_seconds"] = perf_counter() - started
        objective = lambda theta: qaoa_loss_and_gradient(theta, circuit)
        stage_started, stage = perf_counter(), "warmup_seconds"
        result["warmup_objective_calls"] = 1
        loss, gradient = objective(np.asarray(pair["theta0"], dtype=float))
        result["warmup_seconds"] = perf_counter() - stage_started
        stage = None
        if not np.isfinite(loss) or not np.all(np.isfinite(gradient)):
            raise ValueError("Nonfinite warmup.")
        for arm in pair["order"]:
            result["arms"][arm] = optimize(objective, pair["theta0"], threshold, OptimizerSettings(**plan["settings"]), arm == "early")
        result["valid"] = all(r["stop_reason"] not in EXECUTION_FAILURES for r in result["arms"].values())
    except Exception as exc:
        if stage is not None:
            result[stage] = perf_counter() - stage_started
        result["error"] = f"{type(exc).__name__}: {exc}"
    result["pair_elapsed_seconds"] = perf_counter() - started
    return result


def load_attempts(root, plan):
    attempts, receipts = defaultdict(list), defaultdict(list)
    known = {p["pair_id"] for p in plan["pairs"]}
    execution = read_json(root / "execution.json") if (root / "execution.json").exists() else None
    for path in sorted((root / "attempts").glob("*/*.json")):
        value = verify(read_json(path), "record_id")
        suffix = ".started.json" if path.name.endswith(".started.json") else ".json"
        if (value["plan_id"] != plan["plan_id"] or value["pair_id"] not in known
                or path.parent.name != value["pair_id"] or path.name != str(value["attempt"]) + suffix
                or value["attempt"] not in range(1, plan["attempt_limit"] + 1)
                or execution is None or value["execution_id"] != verify(execution, "execution_id")["execution_id"]):
            raise ValueError("Attempt belongs to another plan.")
        (receipts if path.name.endswith(".started.json") else attempts)[value["pair_id"]].append(value)
    for pair_id, rows in attempts.items():
        starts = {r["attempt"]: r for r in receipts[pair_id]}
        for row in rows:
            if row["attempt"] not in starts or row["start_record_id"] != starts[row["attempt"]]["record_id"]:
                raise ValueError("Completed attempt has no matching start receipt.")
    return attempts, receipts


def status(root):
    root = Path(root)
    plan = verify(read_json(root / "plan.json"), "plan_id")
    attempts, receipts = load_attempts(root, plan)
    valid = sum(any(a["valid"] for a in attempts[p["pair_id"]]) for p in plan["pairs"])
    orphaned = sum(len(rows) - len(attempts[k]) for k, rows in receipts.items())
    exhausted = sum(not any(a["valid"] for a in attempts[k]) and len(rows) >= plan["attempt_limit"] for k, rows in receipts.items())
    return {"planned_pairs": len(plan["pairs"]), "valid_pairs": valid, "remaining_pairs": len(plan["pairs"]) - valid,
            "complete": valid == len(plan["pairs"]), "attempts": sum(map(len, receipts.values())),
            "execution_faults": sum(not a["valid"] for rows in attempts.values() for a in rows),
            "interrupted_attempts_unknown_cost": orphaned, "exhausted_pairs": exhausted}


def run(root, backend, execute=False, max_pairs=None):
    if max_pairs is not None and max_pairs < 1:
        raise ValueError("max-pairs must be positive.")
    root = Path(root)
    with exp._writer_lock(root):
        plan = verify(read_json(root / "plan.json"), "plan_id")
        if plan["source"] != exp.source_identity(RUNTIME) or plan["helper_sha256"] != sha(__file__):
            raise ValueError("Source changed after prepare; use the frozen runtime/helper.")
        runtime = exp.environment(backend)
        device_identity = runtime.pop("device_identity")
        if backend == "lightning.gpu" and runtime["gpu"]["unknown"]:
            raise ValueError("GPU environment identity is unresolved.")
        execution = sealed({"plan_id": plan["plan_id"], "backend": backend, "environment": runtime}, "execution_id")
        path = root / "execution.json"
        if path.exists() and read_json(path) != execution:
            raise ValueError("Environment differs; prepare a new output directory.")
        if not execute:
            return status(root)
        if not path.exists():
            write_once_json(path, execution)
        (root / "STOP").unlink(missing_ok=True)
        attempts, receipts = load_attempts(root, plan)
        executed = 0
        for pair in plan["pairs"]:
            key = pair["pair_id"]
            if any(a["valid"] for a in attempts[key]):
                continue
            while len(receipts[key]) < plan["attempt_limit"]:
                if (root / "STOP").exists() or (max_pairs is not None and executed >= max_pairs):
                    return status(root) | {"executed": executed}
                number = len(receipts[key]) + 1
                receipt = sealed({"plan_id": plan["plan_id"], "execution_id": execution["execution_id"], "pair_id": key,
                                  "attempt": number, "device_identity": device_identity,
                                  "started_utc": datetime.now(timezone.utc).isoformat()}, "record_id")
                directory = root / "attempts" / key
                write_once_json(directory / f"{number}.started.json", receipt)
                receipts[key].append(receipt)
                result = sealed({"plan_id": plan["plan_id"], "execution_id": execution["execution_id"], "pair_id": key,
                                 "attempt": number, "start_record_id": receipt["record_id"],
                                 **execute_pair(pair, plan, backend)}, "record_id")
                write_once_json(directory / f"{number}.json", result)
                executed += 1
                print(json.dumps({"pair": key, "attempt": number, "valid": result["valid"], "executed": executed}), flush=True)
                if result["valid"]:
                    break
        return status(root) | {"executed": executed}


def summarize(root, output):
    root = Path(root)
    state = status(root)
    if not state["complete"]:
        raise ValueError("Finish every pair before final summary; status retains failures.")
    plan = verify(read_json(root / "plan.json"), "plan_id")
    attempts, receipts = load_attempts(root, plan)
    grouped, rows = defaultdict(list), []
    for pair in plan["pairs"]:
        result = next(a for a in attempts[pair["pair_id"]] if a["valid"])
        grouped[(pair["iso_class_id"], pair["method"])].append(result)
    for (graph_id, method), results in sorted(grouped.items()):
        graph = plan["input"]["graphs"][graph_id]
        row = {"graph_id": graph_id, "method": method, "cell": graph["representative_cell"]}
        for arm in ("full", "early"):
            values = [r["arms"][arm] for r in results]
            row[arm] = {"mean_seconds": float(np.mean([v["elapsed_seconds"] for v in values])),
                        "mean_calls": float(np.mean([v["objective_calls"] for v in values])),
                        "mean_quality": float(np.mean([v["C_final"] / graph["C_star"] for v in values])),
                        "terminal_success_fraction": float(np.mean([v["terminal_success"] for v in values])),
                        "first_hits": [v["first_hit"] for v in values]}
        rows.append(row)
    all_attempts = [a for values in attempts.values() for a in values]
    methods = {}
    for method in METHODS:
        selected = [r for r in rows if r["method"] == method]
        deltas = np.asarray([r["early"]["mean_seconds"] - r["full"]["mean_seconds"] for r in selected])

        rng = np.random.default_rng(20261116)
        cells = defaultdict(list)
        for index, row in enumerate(selected):
            cells[row["cell"]].append(index)
        draws = np.concatenate([rng.choice(indices, size=(2000, len(indices)), replace=True)
                                for _, indices in sorted(cells.items())], axis=1)
        boot = np.mean(deltas[draws], axis=1)
        methods[method] = {"graphs": len(selected), "early_minus_full_mean_seconds": float(deltas.mean()),
                           "paired_graph_bootstrap_95": np.quantile(boot, [.025, .975]).tolist()}
        methods[method]["paired_differences"] = {}
        for metric in ("mean_seconds", "mean_calls", "mean_quality", "terminal_success_fraction"):
            difference = np.asarray([r["early"][metric] - r["full"][metric] for r in selected])
            interval = np.quantile(np.mean(difference[draws], axis=1), [.025, .975]).tolist()
            methods[method]["paired_differences"][metric] = {"early_minus_full": float(difference.mean()), "bootstrap_95": interval}
        for arm in ("full", "early"):
            values = [r[arm] for r in selected]
            methods[method][arm] = {key: float(np.mean([v[key] for v in values])) for key in values[0] if key != "first_hits"}
            methods[method][arm]["graph_mean_seconds_quantiles_50_90_95"] = np.quantile([v["mean_seconds"] for v in values], [.5, .9, .95]).tolist()
            methods[method][arm]["graph_mean_calls_quantiles_50_90_95"] = np.quantile([v["mean_calls"] for v in values], [.5, .9, .95]).tolist()
    report = {"plan_id": plan["plan_id"], "status": state, "policy": plan["policy"], "weighting": "equal_graph",
              "uncertainty": "2000 paired graph bootstrap resamples within fixed cells, seed 20261116; four timing replicas remain together",
              "uncertainty_limit": "A degenerate bootstrap interval for observed all-success outcomes does not establish population success of 100%; report the graph count and frozen cohort.",
              "methods": methods, "graph_rows": rows, "cost_boundary": plan["cost_boundary"],
              "all_recorded_attempt_cost": {"pair_seconds": sum(a["pair_elapsed_seconds"] for a in all_attempts),
                  "optimizer_seconds": sum(v["elapsed_seconds"] for a in all_attempts for v in a["arms"].values()),
                  "objective_calls": sum(v["objective_calls"] for a in all_attempts for v in a["arms"].values()),
                  "warmup_calls": sum(a["warmup_objective_calls"] for a in all_attempts),
                  "device_build_seconds": sum(a["device_build_seconds"] or 0 for a in all_attempts),
                  "warmup_seconds": sum(a["warmup_seconds"] or 0 for a in all_attempts),
                  "interrupted_attempts_unknown_cost": state["interrupted_attempts_unknown_cost"],
                  "reference_construction_seconds": None, "initialization_training_seconds": None}}
    write_once_json(output, sealed(report, "summary_id"))
    return {"output": str(output), "methods": methods}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    export = commands.add_parser("export-inputs")
    for name in ("old-archive", "reference-archive", "output"):
        export.add_argument("--" + name, required=True)
    prep = commands.add_parser("prepare")
    prep.add_argument("--inputs", required=True)
    prep.add_argument("--root", required=True)
    prep.add_argument("--reference-update", action="append", default=[])
    for name in ("run", "status", "stop", "summarize"):
        command = commands.add_parser(name)
        command.add_argument("--root", required=True)
        if name == "run":
            command.add_argument("--backend", choices=("default.qubit", "lightning.gpu"), default="lightning.gpu")
            command.add_argument("--execute", action="store_true")
            command.add_argument("--max-pairs", type=int)
        if name == "summarize":
            command.add_argument("--output", required=True)
    args = parser.parse_args()
    if args.command == "export-inputs":
        result = export_inputs(args.old_archive, args.reference_archive, args.output)
    elif args.command == "prepare":
        result = prepare(args.inputs, args.root, args.reference_update)
    elif args.command == "run":
        result = run(args.root, args.backend, args.execute, args.max_pairs)
    elif args.command == "status":
        result = status(args.root)
    elif args.command == "summarize":
        result = summarize(args.root, args.output)
    else:
        verify(read_json(Path(args.root) / "plan.json"), "plan_id")
        (Path(args.root) / "STOP").touch(exist_ok=True)
        result = {"stop_requested": True, "behavior": "finish and save the current pair, then exit"}
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == "__main__":
    main()

import argparse
import json
from pathlib import Path
import sys
from time import perf_counter

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import networkx as nx
import numpy as np

from qaoa_study.optimize import ShotOptimizerSettings, optimize_qaoa_shots
from qaoa_study.qaoa import cut_sample_statistics, make_qaoa, make_qaoa_sampler, p1_expectation


def dense_cut_moments(graph, p, theta):

    n = len(graph)
    bits = (np.arange(2 ** n)[:, None] >> np.arange(n - 1, -1, -1)) & 1
    cuts = sum((bits[:, u] != bits[:, v]).astype(float) for u, v in graph.edges)
    state = np.ones(2 ** n, dtype=complex) / np.sqrt(2 ** n)
    for layer in range(p):
        state *= np.exp(-1j * theta[layer] * cuts)
        cosine, sine = np.cos(theta[p + layer]), np.sin(theta[p + layer])
        for wire in range(n):
            pairs = state.reshape(2 ** wire, 2, -1)
            zero, one = pairs[:, 0, :].copy(), pairs[:, 1, :].copy()
            pairs[:, 0, :] = cosine * zero - 1j * sine * one
            pairs[:, 1, :] = cosine * one - 1j * sine * zero
    probability = np.abs(state) ** 2
    mean = float(probability @ cuts)
    variance = float(probability @ (cuts - mean) ** 2)
    fourth = float(probability @ (cuts - mean) ** 4)
    return mean, variance, fourth


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def verify_backend(backend):


    started, cases = perf_counter(), []
    shots = 32768
    settings = ShotOptimizerSettings(shots_per_evaluation=256, total_shots=2048, validation_shots=512)
    isolation = None
    for n in (4, 6):
        graph = nx.cycle_graph(n)
        graph.add_edge(0, 2)
        for p, theta in ((1, [.37, .21]), (2, [.37, -.81, .21, .46])):
            seed = 2 ** 96 + 2026101700 + 10 * n + p
            oracle, variance, fourth = dense_cut_moments(graph, p, theta)
            exact = float(make_qaoa(graph, p, backend=backend)(theta))
            cpu = float(make_qaoa(graph, p, backend="default.qubit")(theta))
            errors = {"exact_oracle": abs(exact - oracle), "exact_default": abs(exact - cpu)}
            if p == 1:
                errors["exact_p1_formula"] = abs(exact - p1_expectation(graph, *theta))
            require(max(errors.values()) <= 1e-9, f"{backend}, n={n}, p={p}: exact errors {errors}")
            sample = make_qaoa_sampler(graph, p, shots=shots, seed=seed, backend=backend)
            replay = make_qaoa_sampler(graph, p, shots=shots, seed=seed, backend=backend)
            first, second = np.asarray(sample(theta)), np.asarray(sample(theta))
            repeatable = np.array_equal(first, replay(theta)) and np.array_equal(second, replay(theta))
            advances = not np.array_equal(first, second)
            require(repeatable and advances, f"{backend}, n={n}, p={p}: seed replay/advancement failed.")
            observed = cut_sample_statistics(graph, first)
            mean_bound = 6 * np.sqrt(variance / shots) + 1e-10
            variance_bound = 6 * np.sqrt(max(0., fourth - (shots - 3) / (shots - 1) * variance ** 2) / shots) + 1e-10
            errors.update(sample_mean=abs(observed["C_mean"] - oracle), sample_variance=abs(observed["sample_variance"] - variance))
            require(errors["sample_mean"] <= mean_bound and errors["sample_variance"] <= variance_bound,
                    f"{backend}, n={n}, p={p}: sampled errors {errors}, bounds {mean_bound}, {variance_bound}")
            smoke = []
            for method in ("COBYLA", "SPSA"):
                for mode in ("finite_shots", "exact_control"):
                    options = dict(method=method, evaluation_mode=mode, measurement_seed=seed + 1000,
                                   perturbation_seed=seed + 2000, validation_seed=seed + 3000, backend=backend)
                    result = optimize_qaoa_shots(graph, p, theta, settings, **options)
                    require(not any(result[k] for k in ("error", "validation_error", "exact_audit_error"))
                            and result["stop_reason"] in ("converged", "budget_exhausted"),
                            f"{backend}, n={n}, p={p}, {method}/{mode}: short optimizer check failed.")
                    require(result["audit_backend"] == result["exact_control_backend"] == backend,
                            "Exact evaluation used an unexpected backend.")
                    final_oracle = dense_cut_moments(graph, p, result["theta_final"])[0]
                    audit_error = abs(result["exact_audit"]["C_final"] - final_oracle)
                    require(audit_error <= 1e-9, f"Endpoint audit differs from the independent oracle: {audit_error}")
                    smoke.append({"method": method, "mode": mode, "audit_error": audit_error,
                                  "queries": result["counts"]["optimization_evaluations"], "stop_reason": result["stop_reason"]})
                    if n == 4 and p == 2 and method == "SPSA" and mode == "finite_shots":
                        altered = optimize_qaoa_shots(graph, p, theta, settings, **{**options, "validation_seed": seed + 3001})
                        trace = lambda run: [(row["theta"], row["statistics"]) for row in run["trace"]]
                        independent = make_qaoa_sampler(graph, p, shots=settings.validation_shots,
                                                       seed=options["validation_seed"], backend=backend)
                        terminal = cut_sample_statistics(graph, independent(result["theta_final"]))
                        require(not any(altered[k] for k in ("error", "validation_error", "exact_audit_error"))
                                and trace(result) == trace(altered) and result["theta_final"] == altered["theta_final"]
                                and result["validation"] == terminal, "Terminal-validation RNG isolation failed.")
                        isolation = {"unchanged_optimization": True, "independent_validation_replay": True}
            cases.append({"n": n, "p": p, "errors": errors, "mean_bound": mean_bound,
                          "variance_bound": variance_bound, "seed_replay": repeatable,
                          "rng_advances": advances, "optimizer_checks": smoke})
    return {"verification_version": 1, "passed": True, "backend": backend, "shots_per_moment_check": shots,
            "cases": cases, "validation_rng_isolation": isolation, "elapsed_seconds": perf_counter() - started,
            "max_exact_error": max(max(value for key, value in row["errors"].items() if key.startswith("exact")) for row in cases),
            "max_endpoint_error": max(check["audit_error"] for row in cases for check in row["optimizer_checks"]),
            "scope": "Fixed n=4/6, p=1/2 numerical/device acceptance; no research pool or large-run timing claim."}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--backend", choices=("default.qubit", "lightning.qubit", "lightning.gpu"), required=True)
    args = parser.parse_args()
    print(json.dumps(verify_backend(args.backend), indent=2))

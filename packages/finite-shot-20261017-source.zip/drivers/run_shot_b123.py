import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SCRIPT = Path(__file__).resolve()
CODE = SCRIPT.parents[1]
sys.path.insert(0, str(CODE))
from drivers import run_b3_full as runtime

DEFAULT_ROOT = "data/manual/shot-b123-v1"
SETTINGS = {"shots_per_evaluation": 1024, "total_shots": 131072, "validation_shots": 8192}
REPETITIONS = 5
BACKEND = "lightning.gpu"
read, require = runtime.read, runtime.require


def stamp(root, **values):
    path = root / "status.json"
    state = read(path) if path.exists() else {}
    state.update(values, updated_utc=runtime.now())
    runtime.atomic_json(path, state)
    return state


def identity():
    return {name: runtime.file_hash(CODE / name) for name in (
        "drivers/run_shot_b123.py", "drivers/run_b3_full.py",
        "drivers/verify_shot_backend.py", "drivers/shot-b123-selection.json")}


def prepare(repo, root):

    from qaoa_study import experiments as exp
    from qaoa_study.records import write_once_json
    from scripts import shot_benchmark as shot
    from qaoa_study.optimize import ShotOptimizerSettings

    binding = root / "launcher.json"
    current = {"files": identity(), "source": exp.source_identity(), "settings": SETTINGS,
               "repetitions": REPETITIONS, "backend": BACKEND}
    if binding.exists():
        require(read(binding) == current, "Noise runtime/settings changed; keep the frozen runtime directory.")
    else:
        write_once_json(binding, current)
    plan_path = root / "plan.json"
    if plan_path.exists():
        plan = shot._read_plan(plan_path)
        require(plan["source"] == current["source"], "Plan source changed.")
        return plan
    selection = read(CODE / "drivers/shot-b123-selection.json")
    require(selection["selection_id"] == exp.digest({k: v for k, v in selection.items() if k != "selection_id"}),
            "Graph selection identity changed.")
    for library in selection["libraries"]:
        for name, sha in library["payload_sha256"].items():
            path = repo / ("data/manual/b1-full-a100-v1/" + name.removeprefix("run/")
                           if name.startswith("run/") else name)
            require(runtime.file_hash(path) == sha, f"Input differs from the archived graph selection: {path}")
    selected = selection["graph_ids"]
    require(len(selected) == len(set(selected)) == 1273, "Expected exactly 1273 frozen evaluation graphs.")
    base = repo / "data/manual"
    old, ws, rgg, tail = [base / name for name in (
        "new-families-full-v1", "size-ws-v2", "size-rgg35-v2", "size-rgg35-v2-platform-tail-v1")]
    require(read(ws / "complete.json")["complete"] and read(tail / "complete.json")["complete"],
            "WS and the RGG union must be complete before noise execution.")
    old_index = read(base / "size-revision-launcher-v1/old-ws-progress-index.json")
    ids = set(old_index["graph_ids"])
    require(len(ids) == 278 and ids <= set(selected), "Old WS selection differs.")

    def references(destination):
        manifest, _, tasks = exp.read_batch(old / "batch")
        refs = {}
        for group, attempts, _ in exp.iter_attempt_groups(manifest, tasks, old / "attempts", graph_ids=ids):
            refs.update(exp.freeze_references(manifest, group, exp.select_attempts(attempts)))
        require(set(refs) == {(g, p) for g in ids for p in (1, 2)} and all(r["complete"] for r in refs.values()),
                "Existing old-WS reference records are incomplete.")
        exp.save_references(destination, refs)

    stamp(root, phase="read-existing-references")
    runtime.staged(root, "old-ws-references", references, exp.read_references)
    stamp(root, phase="freeze-plan")
    plan = shot.plan_benchmark(base / "b1-full-a100-v1/batch",
        [base / "b2-full-a100-v1/cases/random/fit.json"], None, None, plan_path,
        libraries=[old / "library", ws / "library", rgg / "library"],
        references=[base / "b1-full-a100-v1/references", root / "old-ws-references",
                    ws / "references", tail / "references"],
        depths=(1, 2), repetitions=REPETITIONS, settings=ShotOptimizerSettings(**SETTINGS),
        backend=BACKEND, seed=20261017, graph_ids=selected, initializations=("B1", "B2", "B3"))
    require(plan["budget"]["tasks"] == 241870, "Unexpected task count; inspect the frozen plan.")
    print(json.dumps(plan["budget"], indent=2), flush=True)
    return plan


def work(repo, root, lock_fd=None):
    runtime.setup(CODE)
    from qaoa_study import experiments as exp
    from qaoa_study.records import write_once_json
    from scripts import shot_benchmark as shot
    from drivers.verify_shot_backend import verify_backend

    with (os.fdopen(lock_fd, "a+b") if lock_fd is not None else runtime.driver_lock(root)):
        stamp(root, state="running", phase="prepare", pid=os.getpid(), started_utc=runtime.now(), error=None)
        try:
            plan = prepare(repo, root)
            if (root / "stop.request").exists():
                stamp(root, state="paused", phase="prepared")
                return
            receipt = root / "backend-verification.json"
            environment = exp.environment(BACKEND)
            placement = environment.pop("device_identity", None)
            expected = {"source": plan["source"], "environment": environment,
                        "verification_code_sha256": identity()["drivers/verify_shot_backend.py"]}
            if receipt.exists():
                saved = read(receipt)
                require(all(saved[k] == v for k, v in expected.items()),
                        "Backend environment changed since verification; keep the frozen environment.")
                require(saved["verification"]["passed"] is True, "Backend verification did not pass.")
            else:
                stamp(root, phase="verify-gpu-sampling")
                report = verify_backend(BACKEND)
                require(report["passed"] is True, "GPU sampling verification failed.")
                write_once_json(receipt, {**expected, "device_identity": placement, "verification": report})

            def progress(report):
                stamp(root, phase="work", **report)

            result = shot.run_benchmark(root / "plan.json", root / "attempts", execute=True,
                retry_interrupted=True, progress=progress, should_stop=lambda: (root / "stop.request").exists())
            if result["stopped"]:
                stamp(root, state="paused", phase="work", **result)
                return
            require(result["complete"] and not result["execution_failures"],
                    "Some tasks are missing or faulted; retained records are available for diagnosis.")
            stamp(root, phase="summarize")
            summary = shot.summarize_benchmark(root / "plan.json", root / "attempts")
            require(summary["assessments_complete"], "Independent endpoint assessments are incomplete.")
            for name, value in (("summary.json", summary), ("complete.json", {
                    "complete": True, "plan_id": plan["plan_id"], "tasks": result["completed"],
                    "summary_digest": exp.digest(summary)})):
                if (root / name).exists():
                    require(read(root / name) == value, "Existing completion artifact differs.")
                else:
                    write_once_json(root / name, value)
            stamp(root, state="complete", phase="complete", **result)
        except BaseException as error:
            stamp(root, state="paused", error=f"{type(error).__name__}: {error}")
            raise


def status(root):
    state = read(root / "status.json") if (root / "status.json").exists() else {"state": "not_started"}
    state["active_lock"] = runtime.locked(root)
    if not state["active_lock"] and state["state"] == "running":
        state["state"] = "interrupted"
    return state


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("start", "status", "stop", "_run"))
    parser.add_argument("--repo", type=Path, default=CODE.parent)
    parser.add_argument("--root", type=Path)
    parser.add_argument("--watch", type=float, default=0)
    parser.add_argument("--json", action="store_true")
    parser.add_argument("--lock-fd", type=int, help=argparse.SUPPRESS)
    args = parser.parse_args(argv)
    repo = args.repo.resolve()
    root = (args.root or repo / DEFAULT_ROOT).resolve()
    if args.command == "status":
        while True:
            s = status(root)
            print(json.dumps(s, indent=2) if args.json else
                  f'{s.get("completed", 0)}/{s.get("planned", 241870)}  '
                  f'{s["state"]}  {s.get("phase", "")}  faults={s.get("execution_failures", 0)}'
                  + (f'  {s["error"]}' if s.get("error") else ""), flush=True)
            if args.watch <= 0:
                return
            time.sleep(args.watch)
    require(sys.platform == "linux", "Use start/stop on ICRN Linux; local tests do not launch research work.")
    root.mkdir(parents=True, exist_ok=True)
    if args.command == "stop":
        if runtime.locked(root):
            (root / "stop.request").touch()
            print("Stop requested; the current task will be saved before pausing.")
        else:
            print("Already stopped.")
        return
    if args.command == "_run":
        return work(repo, root, args.lock_fd)
    if runtime.locked(root):
        print(json.dumps(status(root), indent=2))
        return
    if (root / "complete.json").exists():
        print(json.dumps(read(root / "complete.json"), indent=2))
        return
    for name in ("size-revision-launcher-v1", "size-rgg35-v2-platform-tail-v1"):
        require(not runtime.locked(repo / "data/manual" / name), f"Existing run is active: {name}")
    log_path = root / "console.log"
    with runtime.driver_lock(root) as guard, log_path.open("ab", buffering=0) as log:
        (root / "stop.request").unlink(missing_ok=True)
        process = subprocess.Popen([sys.executable, "-B", "-u", str(SCRIPT), "_run",
            "--repo", str(repo), "--root", str(root), "--lock-fd", str(guard.fileno())],
            cwd=CODE, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
            start_new_session=True, pass_fds=(guard.fileno(),))
    print(json.dumps({"pid": process.pid, "log": str(log_path),
                      "note": "Launch requested; status reports preparation, verification and work."}))


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        raise SystemExit(130)
